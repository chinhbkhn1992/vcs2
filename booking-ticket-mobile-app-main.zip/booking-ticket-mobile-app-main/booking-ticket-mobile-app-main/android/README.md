执行命令：
gradle assembleRelease  生成release版本
gradle assembleDebug    生成debug版本