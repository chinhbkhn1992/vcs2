package com.dl7.recycler.listener;

/**
 * Created by long on 2016/9/1.
 *
 */
public interface OnRemoveDataListener {

    /**
     * 移除列表项
     * @param position 索引
     */
    void onRemove(int position);
}
