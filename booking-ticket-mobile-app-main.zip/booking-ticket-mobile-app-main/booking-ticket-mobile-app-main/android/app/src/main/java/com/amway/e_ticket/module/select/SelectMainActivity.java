package com.amway.e_ticket.module.select;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.amway.e_ticket.R;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ScreenUtils;
import com.isoft.frame.base.BaseActivity;
import com.isoft.frame.model.enums.ModalDirection;
import com.isoft.frame.utils.LanguageUtils;
import com.jaeger.library.StatusBarUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 区域 or 语言选择。
 *
 * @author rlshao
 */
public class SelectMainActivity extends BaseActivity implements OnItemSelectCallBack {

    @BindView(R.id.ivLeft)
    ImageView ivLeft;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivTitle)
    ImageView ivTitle;
    @BindView(R.id.ivRight)
    ImageView ivRight;
    @BindView(R.id.title_ll)
    LinearLayout titleLl;
    @BindView(R.id.top_view)
    View topView;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.area_ll)
    LinearLayout areaLl;
    @BindView(R.id.tv_area)
    TextView areaTv;

    @BindView(R.id.language_ll)
    LinearLayout languageLl;
    @BindView(R.id.tv_language)
    TextView languageTv;

    @BindView(R.id.tv_repeat_scan)
    TextView tvRepeatScan;
    @BindView(R.id.repeat_scan_ll)
    LinearLayout repeatScanLl;


    public static final String TAG = "SelectMainActivity";

    public static void launch(BaseActivity activity) {
        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeCustomAnimation(activity, R.anim.fade_in_anim, R.anim.fade_out_anim);
        Intent intent = new Intent(activity, SelectMainActivity.class);
        ActivityCompat.startActivity(activity, intent, optionsCompat.toBundle());
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.activity_language_area;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
//        initToolBarView(titleLl, topView);
        StatusBarUtil.setTranslucent(this, 0);
        StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary));
        tvTitle.setText(getText(R.string.text_language_area_title));
        initData();
    }

    /**
     * 设置显示值。
     */
    private void initData() {
        Resources res = getResources();
        String[] languagesList = res.getStringArray(R.array.languages_list);
        String[] areaList = res.getStringArray(R.array.area_list);
        String[] scanList = res.getStringArray(R.array.repeat_scan_list);
        //设置语言
        if(LanguageUtils.getLanguageType() == 4){
            languageTv.setText(languagesList[0]);
        }else{
            languageTv.setText(languagesList[LanguageUtils.getLanguageType()]);
        }

        //设置区域
        areaTv.setText(areaList[SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 0)]);
        //设置扫描
        tvRepeatScan.setText(scanList[SPUtils.getInstance().getInt(CommonStringUtil.REPEAT_SCAN_TAG, 0)]);
    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    /*@Override
    protected void onResume() {
        super.onResume();
        //回来页面要重新设置显示已经选择的值
        initData();
    }*/

    @OnClick({R.id.ivLeft, R.id.area_ll, R.id.language_ll, R.id.repeat_scan_ll})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivLeft:
                //点击返回按钮
                finish();
                break;
            case R.id.area_ll:
                //选择区域，暂不开启
                pushModalFragment(ModalDirection.BOTTOM, ScreenUtils.getScreenHeight() * 2 / 5,
                        SelectWheelFragment.newInstance(SelectWheelFragment.AREA_SELECT));
                break;
            case R.id.language_ll:
                //选择语言
                pushModalFragment(ModalDirection.BOTTOM, ScreenUtils.getScreenHeight() * 2 / 5,
                        SelectWheelFragment.newInstance(SelectWheelFragment.LANGUAGE_SELECT));

                break;
            case R.id.repeat_scan_ll:
                //选择语言
                pushModalFragment(ModalDirection.BOTTOM, ScreenUtils.getScreenHeight() * 2 / 5,
                        SelectWheelFragment.newInstance(SelectWheelFragment.SCAN_SELECT));
                break;

        }
    }

    @Override
    public void OnItemSelect(int type, int selectedItemPosition) {
        //选择器
        initData();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //按下物理返回键
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
