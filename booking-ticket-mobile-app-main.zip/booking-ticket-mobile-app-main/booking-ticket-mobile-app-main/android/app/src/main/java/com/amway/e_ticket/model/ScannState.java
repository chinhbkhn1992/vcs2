package com.amway.e_ticket.model;

/**
 * 扫码状态，state 0，watting，1网络错误，2扫描成功，3扫描成功,非本场活动，4扫描成功，票可以通过.
 */
public interface ScannState {
    // state 0，watting，1网络错误，2扫描成功，3扫描成功,非本场活动，4扫描成功，票可以通过
    int WATTING = 0;
    int NET_ERROR = 1;
    int SCANN_SUCCESS = 2;
    int TICKTT_ERROR = 3;
    int TICKTT_SUCCESS = 4;
    int TICKTT_REPEAT = 5;

}
