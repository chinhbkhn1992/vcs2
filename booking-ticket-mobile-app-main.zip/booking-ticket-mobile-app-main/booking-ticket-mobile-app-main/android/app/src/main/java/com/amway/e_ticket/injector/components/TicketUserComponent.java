package com.amway.e_ticket.injector.components;


import com.amway.e_ticket.injector.modules.UserListModule;
import com.amway.e_ticket.module.ticket.TicketUserFragment;
import com.isoft.frame.injector.PerFragment;
import com.isoft.frame.injector.components.ApplicationComponent;

import dagger.Component;

/**
 * Created by shaorulong on 2018/6/14.
 * City TicketUserComponent
 */
@PerFragment
@Component(dependencies = ApplicationComponent.class, modules = UserListModule.class)
public interface TicketUserComponent {

    void inject(TicketUserFragment fragment);
}
