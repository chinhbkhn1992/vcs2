package com.amway.e_ticket.injector.components;

import com.isoft.frame.injector.PerActivity;
import com.isoft.frame.injector.components.ApplicationComponent;
import com.amway.e_ticket.MainActivity;
import com.amway.e_ticket.injector.modules.MainActivityModule;

import dagger.Component;

/**
 * Created by long on 2016/8/19.
 * Application Component
 */
@PerActivity
@Component(dependencies = ApplicationComponent.class, modules = MainActivityModule.class)
public interface MainActivityComponent {

    void inject(MainActivity activity);
}
