package com.amway.e_ticket.model;

import java.io.Serializable;

/**
 * 用户信息实体bean
 */
public class UserInfo implements Serializable {

    /** token */
    private String token;

    /** 用户名，用于登录 */
    private String name;

    /** 手机 */
    private String phone;

    /** 用户id */
    private long userId;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

}
