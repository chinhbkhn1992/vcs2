package com.amway.e_ticket.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;

import com.amway.e_ticket.R;
import com.amway.e_ticket.model.UserBaseInfo;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.TimeUtils;
import com.dl7.recycler.adapter.BaseQuickAdapter;
import com.dl7.recycler.adapter.BaseViewHolder;
import com.google.gson.Gson;
import com.isoft.frame.utils.LanguageUtils;
import com.orhanobut.logger.Logger;

import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by long on 2016/8/31.
 * 管理界面适配器
 */
public class UserListAdapter extends BaseQuickAdapter<UserBaseInfo.UserModel> {

    public UserListAdapter(Context context) {
        super(context);
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.item_ticket_user;
    }

    @Override
    protected void convert(BaseViewHolder holder, UserBaseInfo.UserModel item) {
        //if(item.isAbo()){
        if(!TextUtils.isEmpty(item.getAda())){
            holder.setText(R.id.user_type_tv,item.getAda());
            holder.setVisible(R.id.user_type_tv,View.VISIBLE);
        }else {
            holder.setVisible(R.id.user_type_tv,View.GONE);
        }
        holder.setText(R.id.user_name_tv,item.getName());

        System.out.println("TUNG 81" + SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11));
        System.out.println("TUNG 81" + item.getCheckinTime());
        if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 0) {
            if(!TextUtils.isEmpty(item.getCheckinTime())){
                Calendar calendar = Calendar.getInstance();
                //calendar.setTime(TimeUtils.string2Date(item.getCheckinTime(), new SimpleDateFormat("yyyy/MM/dd HH:mm")));
                calendar.setTime(TimeUtils.string2Date(item.getCheckTime(), new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")));
                calendar.add(Calendar.HOUR, 8);
                holder.setText(R.id.user_time_tv, TimeUtils.date2String(calendar.getTime(), new SimpleDateFormat("MM-dd HH:mm")));
            }else{
                holder.setText(R.id.user_time_tv, "");
            }
        } else if (SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 5) {
            if(!TextUtils.isEmpty(item.getCheckinTime())){
                Calendar calendar = Calendar.getInstance();
                //calendar.setTime(TimeUtils.string2Date(item.getCheckinTime(), new SimpleDateFormat("yyyy/MM/dd HH:mm")));
                calendar.setTime(TimeUtils.string2Date(item.getCheckTime(), new SimpleDateFormat("yyyy-MM-dd'T'HH:mm")));
                calendar.add(Calendar.HOUR, 5);
                calendar.add(Calendar.MINUTE, 30);
                holder.setText(R.id.user_time_tv, TimeUtils.date2String(calendar.getTime(), new SimpleDateFormat("dd/MM/yyyy HH:mm")));
            }else{
                holder.setText(R.id.user_time_tv, "");
            }
        } else {
            if (!TextUtils.isEmpty(item.getCheckinTime())){
                Logger.json(new Gson().toJson(item));
                holder.setText(R.id.user_time_tv, com.isoft.frame.utils.TimeUtils.GetZoneTime(
                        item.getCheckinTime(),
                        "dd/MM/yyyy HH:mm",
                        "dd/MM/yyyy HH:mm"));
            }else {
                holder.setText(R.id.user_time_tv,"");
            }
        }
        if(true){
            return;
        }
        //乱七八糟的
        if (item.getCheckinstatus() == 1) {
            //已经到场
//            holder.setVisible(R.id.user_state_iv, View.VISIBLE);
            if (!TextUtils.isEmpty(item.getCheckinTime())) {
                //显示时间+8小时
//                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm");
                SimpleDateFormat format1 = new SimpleDateFormat("MM-dd HH:mm");
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(TimeUtils.string2Date(item.getCheckinTime(), format));
                calendar.add(Calendar.HOUR, 8);
                holder.setText(R.id.user_time_tv, TimeUtils.date2String(calendar.getTime(), format1));
            } else {
                holder.setText(R.id.user_time_tv, "");
            }
        } else {
            //未到场
//            holder.setVisible(R.id.user_state_iv, View.INVISIBLE);
            holder.setText(R.id.user_time_tv, "");
        }
        /*存在ada则显示ada，不存在就显示名字，名字需要脱敏显示*/
        if (!TextUtils.isEmpty(item.getAda())) {
            holder.setText(R.id.user_type_tv, item.getAda());
        } else if (!TextUtils.isEmpty(item.getName())) {
            StringBuffer nameBuffer = new StringBuffer(item.getName());
            if (item.getName().length() == 2) {
                holder.setText(R.id.user_type_tv, nameBuffer.replace(1, 2, "*"));
            } else if (item.getName().length() > 2) {
                nameBuffer.replace(1, item.getName().length() - 1, "*");
                if (item.getName().length() != nameBuffer.length()) {
                    int length = item.getName().length() - nameBuffer.length();
                    for (int i = 0; i < length; i++) {
                        nameBuffer.insert(1,"*");
                    }
                }
                holder.setText(R.id.user_type_tv, nameBuffer.toString());
            } else {
                holder.setText(R.id.user_type_tv, item.getName());
            }
        } else {
            holder.setText(R.id.user_type_tv, "");
        }
        /*holder.getConvertView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });*/
    }
}
