package com.amway.e_ticket.module.ticket;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.amway.e_ticket.R;
import com.amway.e_ticket.injector.components.DaggerTicketUserComponent;
import com.amway.e_ticket.injector.modules.UserListModule;
import com.amway.e_ticket.model.EventDetailInfo;
import com.amway.e_ticket.model.UserBaseInfo;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.amway.e_ticket.utils.LoadingUtil;
import com.blankj.utilcode.util.SPUtils;
import com.dl7.recycler.adapter.BaseQuickAdapter;
import com.dl7.recycler.helper.RecyclerViewHelper;
import com.dl7.recycler.listener.OnRequestDataListener;
import com.isoft.frame.base.BaseFragment;
import com.isoft.frame.base.ILoadDataView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInRightAnimationAdapter;

import static com.isoft.frame.base.BaseApplication.getAppComponent;

/**
 * 获取人员
 */
public class TicketUserFragment extends BaseFragment<TicketUserPresenter> implements ILoadDataView<List<UserBaseInfo.UserModel>>, View.OnClickListener {

    @BindView(R.id.rv_user_info_list)
    RecyclerView mRvNewsList;

    @Inject
    BaseQuickAdapter mAdapter;

    @BindView(R.id.applicant_tv)
    TextView applicantTv;
    @BindView(R.id.applicant_hint_tv)
    TextView applicantHintTv;

    @BindView(R.id.enter_tv)
    TextView enterTv;
    @BindView(R.id.enter_hint_tv)
    TextView enterHintTv;

    @BindView(R.id.no_enter_tv)
    TextView noEnterTv;
    @BindView(R.id.no_enter_hint_tv)
    TextView noEnterHintTv;

    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.progress_bar_tv)
    TextView progressBarTv;
    @BindView(R.id.user_type_tv)
    TextView userTypeTv;
    @BindView(R.id.user_name_tv)
    TextView userNameTv;
    @BindView(R.id.time_tv)
    TextView timeTv;
    @BindView(R.id.rb_user_abo)
    RadioButton rbUserAbo;
    @BindView(R.id.rb_main_people)
    RadioButton rbMainPeople;
    @BindView(R.id.main_rg)
    RadioGroup mainRg;
    @BindView(R.id.rb_abo_view)
    View rbAboView;
    @BindView(R.id.rb_foa_view)
    View rbFoaView;
    @BindView(R.id.edit_search)
    EditText searchEdt;
    @BindView(R.id.search_btn)
    TextView searchBtn;

    @BindView(R.id.sort_id_iv)
    ImageView sortIdBtn;
    @BindView(R.id.sort_name_iv)
    ImageView sortNameBtn;
    @BindView(R.id.sort_time_iv)
    ImageView sortTimeBtn;

    @BindView(R.id.layout_user_id)
    LinearLayout layoutUserId;
    @BindView(R.id.layout_user_name)
    LinearLayout layoutUserName;
    @BindView(R.id.layout_user_time)
    LinearLayout layoutUserTime;

    @BindView(R.id.layout_all)
    LinearLayout layoutAll;
    @BindView(R.id.layout_attendance)
    LinearLayout layoutAttendance;
    @BindView(R.id.layout_unregistered)
    LinearLayout layoutUnregistered;


//    @BindView(R.id.swipe_refresh)
//    SwipeRefreshLayout swipeRefresh;

    private EventDetailInfo eventDetailInfo;
    private final static String TAG = "TicketUserFragment";
    public final static String EVENT_ID = "eventID";

    public static TicketUserFragment newInstance(EventDetailInfo eventDetailInfo) {

        Bundle args = new Bundle();
        args.putParcelable(EVENT_ID, eventDetailInfo);
        TicketUserFragment fragment = new TicketUserFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.fragment_ticket_user;
    }

    @Override
    protected void initInjector() {
        eventDetailInfo = getArguments().getParcelable(EVENT_ID);

        DaggerTicketUserComponent.builder()
                .applicationComponent(getAppComponent())
                .userListModule(new UserListModule(this, eventDetailInfo.getEventID()))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
        changeTextColor(1);
        layoutUserId.setOnClickListener(this);
        layoutUserName.setOnClickListener(this);
        layoutUserTime.setOnClickListener(this);
        searchBtn.setOnClickListener(this);

        layoutAll.setOnClickListener(this);
        layoutAttendance.setOnClickListener(this);
        layoutUnregistered.setOnClickListener(this);


        mPresenter.setRole(1);
        //入场门票数量
        applicantTv.setText(eventDetailInfo.getTicketsTotal());
        enterTv.setText(eventDetailInfo.getCheckinTotal());
        noEnterTv.setText(eventDetailInfo.getUncheckinTotal());
        //进度条
        progressBar.setProgress(Double.valueOf(eventDetailInfo.getCheckinRate()).intValue());
        progressBarTv.setText(String.format(getString(R.string.text_progress_bar_info), Double.valueOf(eventDetailInfo.getCheckinRate()).intValue(), eventDetailInfo.getCheckinTotal(), eventDetailInfo.getTicketsTotal()));


        SlideInRightAnimationAdapter animAdapter = new SlideInRightAnimationAdapter(mAdapter);
        RecyclerViewHelper.initRecyclerViewV(getActivity(), mRvNewsList, false, new AlphaInAnimationAdapter(animAdapter));
        mAdapter.setRequestDataListener(new OnRequestDataListener() {
            @Override
            public void onLoadMore() {
                mPresenter.getMoreData();
            }
        });

        mainRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_user_abo) {
                    //选中了abo
//                    userTypeTv.setText(R.string.text_ticket_user_list_item_title_amway_id);
                    rbAboView.setVisibility(View.VISIBLE);
                    rbFoaView.setVisibility(View.INVISIBLE);
                    mPresenter.setRole(1);
                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "Y");
                    updateViews(true);
                } else {
                    //选中了顾客
//                    userTypeTv.setText(R.string.text_ticket_user_list_item_title_name);
                    mPresenter.setRole(2);
                    rbAboView.setVisibility(View.INVISIBLE);
                    rbFoaView.setVisibility(View.VISIBLE);
                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "Y");
                    updateViews(true);
                }
                sortTimeBtn.setBackgroundResource(R.mipmap.down);
                sortTimeBtn.setVisibility(View.VISIBLE);
                sortNameBtn.setVisibility(View.INVISIBLE);
                sortIdBtn.setVisibility(View.INVISIBLE);
                LoadingUtil.showLoading(getActivity());

            }
        });

//        updateViews(true);
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void update(EventDetailInfo eventDetailInfo){
        this.eventDetailInfo = eventDetailInfo;
        //入场门票数量
        applicantTv.setText(eventDetailInfo.getTicketsTotal());
        enterTv.setText(eventDetailInfo.getCheckinTotal());
        noEnterTv.setText(eventDetailInfo.getUncheckinTotal());
        //进度条
        progressBar.setProgress(Double.valueOf(eventDetailInfo.getCheckinRate()).intValue());
        progressBarTv.setText(String.format(getString(R.string.text_progress_bar_info), Double.valueOf(eventDetailInfo.getCheckinRate()).intValue(), eventDetailInfo.getCheckinTotal(), eventDetailInfo.getTicketsTotal()));
    }
    private TicketUserFragment.SearchOrderBy orderBy = SearchOrderBy.CHECK_TIME;
    private String searchKey = "";
    private boolean isDesc = true;
    @Override
    protected void updateViews(boolean isRefresh) {
        mPresenter.getData(isRefresh,orderBy,searchKey,isDesc);
    }

    private List<UserBaseInfo.UserModel> filterData(List<UserBaseInfo.UserModel> data){
        System.out.println("TicketUserFragment: filterData");

        if (data != null) {
            if (data.size() < TicketUserPresenter.DATA_PAGE_SIZE) {
                System.out.println("data.size() < DATA_PAGE_SIZE");
                mAdapter.noMoreData();
            } else {
                mAdapter.enableLoadMore(true);
            }
        }
        if(tabStatu == -1  || data == null) {
            System.out.println("TicketUserFragment: Return data");
            return data;
        }
        List<UserBaseInfo.UserModel> list = new ArrayList<>();
        for (UserBaseInfo.UserModel model : data){
            if(model.getCheckinstatus() == tabStatu)
                list.add(model);
        }
        System.out.println("list "+list.size());
        return list;
    }
    private List<UserBaseInfo.UserModel> dataList = new ArrayList<>();
    @Override
    public void loadData(List<UserBaseInfo.UserModel> data) {
        System.out.println("loadData ");
        //dataList.clear();
        if(data != null) {
            dataList.clear();
            dataList.addAll(data);
            mAdapter.cleanItems();
        }
        LoadingUtil.hideLoading();
        finishRefresh();
        //mAdapter.cleanItems();
        if (data != null) {
            mAdapter.updateItems(filterData(data));
            System.out.println("TicketUserFragment: loadData "+ data.size());
            if(data.size() < TicketUserPresenter.DATA_PAGE_SIZE) {
                System.out.println("loadData data.size() < DATA_PAGE_SIZE");
                mAdapter.noMoreData();
            } else {
                mAdapter.enableLoadMore(true);
            }
        }else{
            System.out.println("TicketUserFragment: data = null ");
            mAdapter.addItems(filterData(data));
            mAdapter.loadAbnormal();
        }
    }

    public void loadDataData(List<UserBaseInfo.UserModel> data) {
        System.out.println("loadData ");
        dataList.clear();
        if(data != null) {
            dataList.addAll(data);
        }
        LoadingUtil.hideLoading();
        finishRefresh();
        mAdapter.cleanItems();
        if (data != null) {
            mAdapter.updateItems(filterData(data));
            System.out.println("TicketUserFragment: loadData "+ data.size());
            if(data.size() < TicketUserPresenter.DATA_PAGE_SIZE) {
                System.out.println("loadData data.size() < DATA_PAGE_SIZE");
                mAdapter.noMoreData();
            } else {
                mAdapter.enableLoadMore(true);
            }
        }else{
            System.out.println("TicketUserFragment: data = null ");
            mAdapter.addItems(filterData(data));
            mAdapter.loadAbnormal();
        }
    }

    @Override
    public void loadMoreData(List<UserBaseInfo.UserModel> data) {
        LoadingUtil.hideLoading();
        mAdapter.loadComplete();
        Log.w(TAG, "loadMoreData 完毕");
        if (data != null) {
            dataList.addAll(data);
            mAdapter.addItems(filterData(data));
        } else {
            mAdapter.noMoreData();
        }
    }

    @Override
    public void loadNoData() {

    }

    private void changeTextColor(int index){
        applicantTv.setTextColor(index == 1?getResources().getColor(R.color.colorPrimary):getResources().getColor(R.color.colorGray));
        applicantHintTv.setTextColor(index ==1?getResources().getColor(R.color.c_black1):getResources().getColor(R.color.colorGray));
        enterTv.setTextColor(index == 2?getResources().getColor(R.color.colorPrimary):getResources().getColor(R.color.colorGray));
        enterHintTv.setTextColor(index ==2?getResources().getColor(R.color.c_black1):getResources().getColor(R.color.colorGray));
        noEnterTv.setTextColor(index == 3?getResources().getColor(R.color.colorPrimary):getResources().getColor(R.color.colorGray));
        noEnterHintTv.setTextColor(index ==3?getResources().getColor(R.color.c_black1):getResources().getColor(R.color.colorGray));
    }

    private int tabStatu = -1;//0 unregistered ,  1 attendance , -1 ALL
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.layout_all:
                changeTextColor(1);
                tabStatu = -1;
                mAdapter.updateItems(filterData(dataList));
                break;
            case R.id.layout_attendance:
                changeTextColor(2);
                tabStatu = 1;
                mAdapter.updateItems(filterData(dataList));
                break;
            case R.id.layout_unregistered:
                changeTextColor(3);
                tabStatu = 0;
                mAdapter.updateItems(filterData(dataList));
                break;
            case R.id.layout_user_id:
                searchKey = "";
                if(orderBy == SearchOrderBy.ADA){
                    isDesc = !isDesc;
                }else {
                    isDesc = true;
                    orderBy = SearchOrderBy.ADA;
                }
                sortIdBtn.setBackgroundResource(isDesc?R.mipmap.down:R.mipmap.up);
                sortNameBtn.setVisibility(View.INVISIBLE);
                sortTimeBtn.setVisibility(View.INVISIBLE);
                sortIdBtn.setVisibility(View.VISIBLE);
                mPresenter.getData(true,orderBy,searchKey,isDesc);
                LoadingUtil.showLoading(getActivity());
                break;
            case R.id.layout_user_name:
                searchKey = "";
                if(orderBy == SearchOrderBy.NAME){
                    isDesc = !isDesc;
                }else {
                    isDesc = true;
                    orderBy = SearchOrderBy.NAME;
                }
                sortNameBtn.setBackgroundResource(isDesc?R.mipmap.down:R.mipmap.up);
                sortNameBtn.setVisibility(View.VISIBLE);
                sortTimeBtn.setVisibility(View.INVISIBLE);
                sortIdBtn.setVisibility(View.INVISIBLE);
                mPresenter.getData(true,orderBy,searchKey,isDesc);
                LoadingUtil.showLoading(getActivity());
                break;
            case R.id.layout_user_time:
                searchKey = "";
                if(orderBy == SearchOrderBy.CHECK_TIME){
                    isDesc = !isDesc;
                }else {
                    isDesc = true;
                    orderBy = SearchOrderBy.CHECK_TIME;
                }
                sortTimeBtn.setBackgroundResource(isDesc?R.mipmap.down:R.mipmap.up);
                sortTimeBtn.setVisibility(View.VISIBLE);
                sortNameBtn.setVisibility(View.INVISIBLE);
                sortIdBtn.setVisibility(View.INVISIBLE);
                mPresenter.getData(true,orderBy,searchKey,isDesc);
                LoadingUtil.showLoading(getActivity());
                break;
            case R.id.search_btn:
                searchKey = searchEdt.getText().toString();
                orderBy = SearchOrderBy.CHECK_TIME;
                isDesc = true;
                sortTimeBtn.setBackgroundResource(R.mipmap.down);
                sortTimeBtn.setVisibility(View.VISIBLE);
                sortNameBtn.setVisibility(View.INVISIBLE);
                sortIdBtn.setVisibility(View.INVISIBLE);
                mPresenter.getData(true,orderBy,searchKey,isDesc);
                LoadingUtil.showLoading(getActivity());
                break;
        }
    }

    public enum SearchOrderBy{
         ADA("ada"), CHECK_TIME("checkTime"), NAME("name");
         String orderBy;

        SearchOrderBy(String orderBy) {
            this.orderBy = orderBy;
        }
    }
}
