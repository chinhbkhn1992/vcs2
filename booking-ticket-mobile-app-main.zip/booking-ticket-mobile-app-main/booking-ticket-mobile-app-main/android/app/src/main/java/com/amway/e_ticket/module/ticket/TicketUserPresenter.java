package com.amway.e_ticket.module.ticket;

import android.content.Context;
import android.util.Log;

import com.amway.e_ticket.api.TicketApi;
import com.amway.e_ticket.model.UrlModule;
import com.amway.e_ticket.model.UserBaseInfo;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.amway.e_ticket.utils.UserAgentUtil;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.StringUtils;
import com.google.gson.Gson;
import com.isoft.frame.base.IBasePresenter;
import com.isoft.frame.network.http.MyErrcodeEnum;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by shaorulong on 2018/8/23.
 * 获取用户数据 Presenter
 */
public class TicketUserPresenter implements IBasePresenter {

    private TicketUserFragment mView;
    private Context mContext;
    private final static String TAG = "TicketUserPresenter";
    private String eventID;
//    role 1: ABO, 2:普通customer, 0:全部查询
    private int role;

    public TicketUserPresenter(Context context, TicketUserFragment view, String eventID) {
        this.mContext = context;
        this.mView = view;
        this.eventID = eventID;
    }

    private int mPage = 0;
    //每页条数
    public static final int DATA_PAGE_SIZE = 15;

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }



    public void getData(boolean isRefresh, TicketUserFragment.SearchOrderBy orderBy,String searchKey,boolean isDesc) {
        this.orderBy = orderBy;
        this.searchKey = searchKey;
        this.isDesc = isDesc;
        Log.w(TAG, "getData-->" + isRefresh);
        if (isRefresh) {
            mPage = 1;
//            mView.showLoading();
        } else {
            mPage++ ;
        }
        getUserList(mContext, eventID, role, mPage, DATA_PAGE_SIZE);

    }
    private TicketUserFragment.SearchOrderBy orderBy;
    private String searchKey;
    private boolean isDesc;

    @Override
    public void getData(boolean isRefresh) {

    }

    public void getMoreData() {
        Log.w(TAG, "getMoreData");
        mPage++;
        getUserList(mContext, eventID, role, mPage, DATA_PAGE_SIZE);

        /*if (!isFromMyFindCar) {
            mModel.getFindCarList(mPage, CommonStringUtil.REQUEST_PER_PAGE_NUM)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .compose(TransformUtils.defaultSchedulers())
                .subscribe(new HttpResultSubscriber<List<FindCarItem>>() {

                    @Override
                    public void onSuccess(List<FindCarItem> findCarResponse) {
                        mView.loadMoreData(findCarResponse);
                    }

                    @Override
                    public void _onError(int status, String msg) {
                        mView.loadNoData();
                        if ("无数据".equals(msg)) {
                            ToastUtils.showToast("没有更多数据");
                        } else {
                            ToastUtils.showToast(msg);
                        }
                    }
                });
        }*/
    }

    /**
     * 获取活动人员列表
     * @param context 上下文
     * @param eventID 二维码Id
     * @param role 1: ABO,2:普通customer,0:全部查询
     * @param currentPage 当前页
     * @param totalPerPage 每页笔数
     */
    public void getUserList(Context context, String eventID, final int role, final int currentPage, int totalPerPage) {
        Map<String, Object> parammMap = new HashMap<>();
        parammMap.put("eventID", eventID);
        if (role == 1) {
            parammMap.put("role", "ABO");
        } else if (role == 2) {
            parammMap.put("role", "CUS");
        } else {
            parammMap.put("role", "ALL");
        }
        parammMap.put("currentPage", currentPage);
        parammMap.put("totalPerPage", totalPerPage);
        parammMap.put("orderBy", this.orderBy.orderBy);//ada/name/checkTime
        parammMap.put("isDesc", this.isDesc);//true false
        parammMap.put("search", this.searchKey);//true false


        String url = UrlModule.getInstance().url + TicketApi.CHECKIN_EVENT_GETATTENDEELIST_URL;
        OkHttpUtils
            .postString()
            .url(url)
            .content(new Gson().toJson(parammMap))
            .mediaType(MediaType.parse("application/json; charset=utf-8"))
            .addHeader("User-Agent", UserAgentUtil.getUserAgent(context))
            .build()
            .execute(new StringCallback() {
                @Override
                public void onError(Call call, Exception e, int id) {
                    if (currentPage == 1) {
                        mView.finishRefresh();
                    } else {
                        mView.hideLoading();
                    }
                    String code = MyErrcodeEnum.FAIL.getVal().toString();
                    mPage--;
                    if(SPUtils.getInstance().getString(CommonStringUtil.CHECKED_CHANGED_TAG, "") == ""){
                        mView.loadData(null);
                    }else{
                        mView.loadDataData(null);
                    }
                    mView.loadData(null);
                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                }

                @Override
                public void onResponse(String response, int id) {
                    if (currentPage == 1) {
                        mView.finishRefresh();
                    } else {
                        mView.hideLoading();
                    }
                    String code = MyErrcodeEnum.SUCCESS.getVal().toString();
                    if (!StringUtils.isEmpty(response)) {
                        Log.w(TAG, response);
                        //成功
                        UserBaseInfo userInfo = new Gson().fromJson(response, UserBaseInfo.class);
                        /*LoginHttpResult<EventDetailInfo> loginInfo = new Gson().fromJson(response,
                                new TypeToken<EventDetailInfo>() {
                                }.getType());*/
                        if (code.equals(userInfo.getResultCode() + "")) {
                            //成功
                            if (currentPage == 1) {
                                //刷新回来
                                if (userInfo.getAttendees() != null && userInfo.getAttendees().size() > 0) {
                                    mView.loadData(userInfo.getAttendees());
                                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                                } else {
                                    mPage--;
                                    mView.loadData(null);
                                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                                }

                            } else {
                                //加载更多
                                if (userInfo.getAttendees() != null && userInfo.getAttendees().size() > 0) {
                                    mView.loadMoreData(userInfo.getAttendees());
                                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                                } else {
                                    mView.loadMoreData(null);
                                    mPage --;
                                    SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                                }
                            }
                        } else {
                            //业务失败鸟
                            mPage--;
                            mView.loadDataData(null);
                            SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                        }

                    } else {
                        mPage--;
                        mView.loadData(null);
                        SPUtils.getInstance().put(CommonStringUtil.CHECKED_CHANGED_TAG, "");
                    }
                }
            });
    }
}
