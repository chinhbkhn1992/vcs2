package com.amway.e_ticket.api.service;


import com.isoft.frame.network.http.HttpResult;
import com.isoft.frame.network.service.RetrofitService;
import com.amway.e_ticket.api.UserApi;
import com.amway.e_ticket.model.UserInfo;

import rx.Observable;

/**
 * 用户相关相关Service。
 */
public class UsreService {

    public UsreService() {

    }

    /**
     *
     *
     * @return
     */
    public Observable<HttpResult<String>> getCodeToken() {
        return RetrofitService.obtainRetrofitService(UserApi.class).getCodeToken();
    }

    /**
     *
     * 登录
     * @param phone  手机号码
     * @param password 密码
     * @return
     */
    public Observable<HttpResult<UserInfo>> login(String phone, String password) {
        return RetrofitService.obtainRetrofitService(UserApi.class).login(phone, password);
    }

    /**
     *
     * 发送短信验证码
     * @param phone  手机号码
     * @return
     */
    public Observable<HttpResult<Object>> getAuthcode(String phone) {
        return RetrofitService.obtainRetrofitService(UserApi.class).getRegistCode(phone);
    }
    /**
     *
     * 注册
     * @param idCard  身份证号码
     * @param phone  手机号码
     * @param password 密码
     * @param name 用户名
     * @param code 验证码
     * @return
     */
    public Observable<HttpResult<Object>> registe(String idCard, String phone, String password, String name, String code) {
        return RetrofitService.obtainRetrofitService(UserApi.class).registe(idCard, phone, password, name, code);
    }


    /**
     *
     * 检查密码
     * @param token 用户token
     * @param password 密码
     * @return
     */
    public Observable<HttpResult<Object>> checkPassword(String token, String password) {
        return RetrofitService.obtainRetrofitService(UserApi.class).checkPassword(token, password);
    }

    /**
     *
     * 修改密码
     * @param token 用户token
     * @param password 密码
     * @return
     */
    public Observable<HttpResult<Object>> updatePassword(String token, String password) {
        return RetrofitService.obtainRetrofitService(UserApi.class).updatePassword(token, password);
    }
    /**
     *
     * 通过验证码修改密码
     * @param phone 用户token
     * @param password 密码
     * @return
     */
    public Observable<HttpResult<Object>> changePswByAuthcode(String phone, String password) {
        return RetrofitService.obtainRetrofitService(UserApi.class).changePswByAuthcode(phone, password);
    }


}
