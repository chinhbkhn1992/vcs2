package com.amway.e_ticket.api;


import com.isoft.frame.network.http.HttpResult;
import com.amway.e_ticket.model.UserInfo;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import rx.Observable;

/**
 * @date: 2018/8/22$ 13:43$
 * @author: shaorulong
 * @org: kkucar
 * @package: com.amway.e_ticket.api$
 * @fileName: AuthApi$
 * @changer: shaorulong //TODO 不同修改后填上
 * @description: //用户相关api
 */
public interface UserApi {

    /**
     *  获取登录验证码
     * @return
     */
    @GET("student/codeToken")
    Observable<HttpResult<String>> getCodeToken();

    /**
     *  登录
     * @param phone  手机号码
     * @param password 输入密码
     * @return
     */
    @GET("student/loginapp")
    Observable<HttpResult<UserInfo>> login(@Query("phone") String phone, @Query("password") String password);

    /**
     *  发送短信验证码
     * @param phone  手机号码
     * @return
     */
    @GET("student/getRegistCode")
    Observable<HttpResult<Object>> getRegistCode(@Query("phone") String phone);

    /**
     *  注册
     * @param idCard  身份证号码
     * @param phone  手机号码
     * @param password 输入密码
     * @param name 用户名
     * @param code 验证码
     * @return
     */
    @GET("student/regist")
    Observable<HttpResult<Object>> registe(@Query("idCard") String idCard, @Query("phone") String phone, @Query("password") String password, @Query("name") String name, @Query("code") String code);

    /**
     * 检查密码
     * @param token  用户token
     * @param password  用户密码
     * @return
     */
    @FormUrlEncoded
    @POST("uc/member/pswCheck")
    Observable<HttpResult<Object>> checkPassword(@Field("token") String token, @Field("password") String password);

    /**
     * 修改密码
     * @param token  用户token
     * @param password  新密码
     * @return
     */
    @FormUrlEncoded
    @POST("uc/member/pswChange")
    Observable<HttpResult<Object>> updatePassword(@Field("token") String token, @Field("password") String password);
    /**
     * 修改密码
     * @param phone  用户手机号码
     * @param password  新密码
     * @return
     */
    @FormUrlEncoded
    @POST("uc/member/changePswByAuthcode")
    Observable<HttpResult<Object>> changePswByAuthcode(@Field("phone") String phone, @Field("password") String password);

}
