package com.amway.e_ticket;

import android.content.Context;
import android.support.multidex.MultiDex;

import com.amway.e_ticket.model.AreaInfo;
import com.amway.e_ticket.model.UrlModule;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.blankj.utilcode.util.SPUtils;
import com.isoft.frame.base.BaseApplication;
import com.isoft.frame.injector.components.DaggerApplicationComponent;
import com.isoft.frame.injector.modules.ApplicationModule;
import com.isoft.frame.utils.AssetsHelper;
import com.isoft.frame.utils.GsonHelper;
import com.isoft.frame.utils.LanguageUtils;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.https.HttpsUtils;
import com.zhy.http.okhttp.log.LoggerInterceptor;

import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

/**
 * Created by shaorulong on 2018/8/28.
 */
public class MyApplication extends BaseApplication {

    //数据库名称
    /*private static final String DB_NAME = "ticket-db";
    private static DaoSession daoSession;*/
    //请求超时时间
    private final static long TIME_OUT_DATA = 15 * 1000;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        _initInjector();
        _initWebConfig();
        //  设置本地化语言
        LanguageUtils.setLocale(this);
        mainActivityName = MainActivity.class.getName();
        Logger.d("mainActivityName:" + mainActivityName, "");
//        _initDatabase();
    }


    /**
     * 初始化注射器
     */
    private void _initInjector() {
        // 这里不做注入操作，只提供一些全局单例数据
        sAppComponent = DaggerApplicationComponent.builder()
                .applicationModule(new ApplicationModule(this, mRxBus))
                .build();

    }
    /**
     * 根据缓存的区域数据，
     * 初始化网络请求配置。
     * 若果为设置过，则默认选中第一条（台湾）作为项目入口.
     */
    public void _initWebConfig() {
        //List<AreaInfo> sAllAreaInfos = GsonHelper.convertEntities(AssetsHelper.readData(this, "AreaAndLanguageData"), AreaInfo.class);
        List<AreaInfo> sAllAreaInfos = GsonHelper.convertEntities(AssetsHelper.readData(this, "AreaData"), AreaInfo.class);
        int selectedItemPosition = SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 3);
        final AreaInfo areaInfo = sAllAreaInfos.get(selectedItemPosition);
        //记录区域码
        UrlModule.getInstance().regionCode = areaInfo.getRegionCode();

        if (BuildConfig.DEBUG) {
//            LeakCanary.install(this);
            Logger.init("LogTAG");
            UrlModule.getInstance().url = areaInfo.getDebugUrl();
            /*CommonDataUtil.BASE_URL = areaInfo.getDebugUrl();
            CommonDataUtil.BASE_IMAGE_URL = areaInfo.getDebugUrl();*/
        } else {
            UrlModule.getInstance().url = areaInfo.getReleaseUrl();

            /*CommonDataUtil.BASE_URL = areaInfo.getReleaseUrl();
            CommonDataUtil.BASE_IMAGE_URL = areaInfo.getReleaseUrl();*/
        }


        //初始化网络请求；第一步支持https，设置可访问所有的https网站
        HttpsUtils.SSLParams sslParams = HttpsUtils.getSslSocketFactory(null, null, null);
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .sslSocketFactory(sslParams.sSLSocketFactory, sslParams.trustManager)
                .addInterceptor(new LoggerInterceptor("NET"))
                .connectTimeout(TIME_OUT_DATA, TimeUnit.MILLISECONDS)
                .readTimeout(TIME_OUT_DATA, TimeUnit.MILLISECONDS)
                //其他配置
                .build();

        OkHttpUtils.initClient(okHttpClient);
        super._initConfig();
    }

    /**
     * 配置数据库
     */
    /*private void _initDatabase() {
        //创建数据库shop.db
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, DB_NAME, null);
        //获取可写数据库
        SQLiteDatabase db = helper.getWritableDatabase();
        //获取数据库对象
        DaoMaster daoMaster = new DaoMaster(db);
        //获取dao对象管理者
        daoSession = daoMaster.newSession();
    }

    //返回可操作对象
    public static DaoSession getDaoInstant() {
        return daoSession;
    }*/
}
