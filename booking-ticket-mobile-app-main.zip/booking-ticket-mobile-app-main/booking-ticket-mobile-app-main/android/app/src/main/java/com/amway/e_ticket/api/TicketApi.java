package com.amway.e_ticket.api;


import com.isoft.frame.network.http.HttpResult;

import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

/**
 * @date: 2019/8/8$ 13:43$
 * @author: shaorulong
 * @description: //Ticket相关api
 */
public interface TicketApi {
	
	


   /* //获取活动详情地址
    String CHECKIN_EVENT_DETAIL_URL = "events/checkinEventDetail";
    //10测试机接口地址
//    String CHECKIN_EVENT_DETAIL_URL = "Ticket/checkinEventDetail";

    //验票进入会场
    String CHECKIN_EVENT_TICKET_URL = "events/checkin";
    //获取进入会场人员
    String CHECKIN_EVENT_GETATTENDEELIST_URL = "events/getAttendeeList";    */

   //越南版
    //获取活动详情地址
    String CHECKIN_EVENT_DETAIL_URL = "ticket/checkinEventDetail";
    //验票进入会场
    String CHECKIN_EVENT_TICKET_URL = "ticket/checkin";
    //获取进入会场人员
    String CHECKIN_EVENT_GETATTENDEELIST_URL = "ticket/getAttendeeList";
    //获取语言
    String CHECKIN_EVENT_REGIONLANGUAGE_URL = "/master/openservice/login/v1/getLanguageInfo";
    //获取区域
    String CHECKIN_EVENT_REGION_URL = "/master/openservice/login/v1/getApplicationInfosForApp";
    /**
     *  获取活动详情数据
     * @param fieldMap 参数集合
     * @return
     */
    @POST(CHECKIN_EVENT_DETAIL_URL)
    Observable<HttpResult<String>> checkinEventDetail(@Body Map<String, String> fieldMap);


}
