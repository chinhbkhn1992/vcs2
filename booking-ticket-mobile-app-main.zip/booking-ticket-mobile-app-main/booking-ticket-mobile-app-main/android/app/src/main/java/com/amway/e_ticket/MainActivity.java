package com.amway.e_ticket;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.amway.e_ticket.api.TicketApi;
import com.amway.e_ticket.injector.components.DaggerMainActivityComponent;
import com.amway.e_ticket.injector.modules.MainActivityModule;
import com.amway.e_ticket.model.EventDetailInfo;
import com.amway.e_ticket.model.RegionBaseInfo;
import com.amway.e_ticket.model.RegionLanguageBaseInfo;
import com.amway.e_ticket.model.UrlModule;
import com.amway.e_ticket.module.capture.MainCaptureActivity;
import com.amway.e_ticket.module.select.SelectMainActivity;
import com.amway.e_ticket.module.select.SelectLanguageRegionActivity;
import com.amway.e_ticket.module.ticket.MainTicketActivity;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.amway.e_ticket.utils.TinyDB;
import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.StringUtils;
import com.google.gson.Gson;
import com.isoft.frame.base.BaseActivity;
import com.isoft.frame.base.ILoadDataView;
import com.isoft.frame.network.http.MyErrcodeEnum;
import com.isoft.frame.utils.SnackbarUtils;
import com.jaeger.library.StatusBarUtil;
import com.king.zxing.Intents;
import com.tbruyelle.rxpermissions.RxPermissions;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Credentials;
import okhttp3.MediaType;
import rx.functions.Action1;

/**
 * 程序入口
 */
public class MainActivity extends BaseActivity<MainPresenter> implements ILoadDataView<EventDetailInfo> {

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.title_ll)
    LinearLayout titleLl;
    @BindView(R.id.top_view)
    View topView;
    @BindView(R.id.ivLeft)
    ImageView ivLeft;
    @BindView(R.id.ivRight)
    ImageView ivRight;

    @BindView(R.id.ivTitle)
    ImageView ivTitle;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    @BindView(R.id.error_ll)
    LinearLayout errorLl;
    @BindView(R.id.enter_et)
    EditText enterEt;
    @BindView(R.id.query_bt)
    Button queryBtn;

    @BindView(R.id.action_num_tv)
    TextView actionNumTv;
    @BindView(R.id.action_applicant_tv)
    TextView actionApplicantNumTv;
    @BindView(R.id.action_name_tv)
    TextView actionNameTv;
    @BindView(R.id.action_city_tv)
    TextView actionCityTv;
    @BindView(R.id.applicant_tv)
    TextView applicantTv;
    @BindView(R.id.no_enter_tv)
    TextView noEnterTv;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.progress_bar_tv)
    TextView progressBarTv;
    @BindView(R.id.start_ticket_bt)
    Button startTicketBt;

    @BindView(R.id.app_version_tv)
    TextView tvVersion;
    @BindView(R.id.date_tv)
    TextView dateTv;
    @BindView(R.id.timeslot_tv)
    TextView timeslotTv;
    @BindView(R.id.address_tv)
    TextView addressTv;
    @BindView(R.id.long_name_tv)
    TextView longNameTv;
    @BindView(R.id.registered_tv)
    TextView registeredTv;

    @BindView(R.id.long_name_ll)
    LinearLayout longNameLl;

    @BindView(R.id.language_tv)
    TextView languageTv;
    @BindView(R.id.layout_timeslot)
    LinearLayout timeslotLayout;
    @BindView(R.id.layout_venue)
    LinearLayout venueLayout;
    @BindView(R.id.layout_language)
    LinearLayout languageLayout;

    //获取到的活动数据，传递给下一个页面使用
    private EventDetailInfo eventDetailInfo;
    //Received region & language data, pass to next view
    //private RegionLanguageBaseInfo regionLanguageInfo;

    private long mExitTime = 0L;
    public static final int REQUEST_CODE_SCAN = 0X01;

    public static final String TAG = "MainActivity";

    @Override
    protected int attachLayoutRes() {

        return R.layout.activity_main;
    }

    @Override
    protected void initInjector() {
        DaggerMainActivityComponent.builder()
                .applicationComponent(getAppComponent())
                .mainActivityModule(new MainActivityModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initViews() {
//        StatusBarUtil.setTransparent(this);
        StatusBarUtil.setTranslucent(this, 0);
        StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary));
//        initToolBarView(titleLl, topView);
        ivLeft.setVisibility(View.INVISIBLE);
        tvTitle.setVisibility(View.GONE);
        ivTitle.setVisibility(View.VISIBLE);
        ivRight.setVisibility(View.VISIBLE);

        if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) != 0){
            longNameLl.setVisibility(View.GONE);
        }else{
            longNameLl.setVisibility(View.VISIBLE);
        }

        if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 2 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 3 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 4){
            languageLayout.setVisibility(View.VISIBLE);
        }else{
            languageLayout.setVisibility(View.GONE);
        }

        if (BuildConfig.DEBUG) {
            tvVersion.setText(String.format(getString(R.string.text_main_version_qa), AppUtils.getAppVersionName()));
        } else {
            tvVersion.setText(String.format(getString(R.string.text_main_version_pd), AppUtils.getAppVersionName()));
        }
        //测试数据
//        enterEt.setText("E02200602683");

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.w(TAG, "onNewIntent");
        if (intent != null) {

        }
    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }


    @Override
    public void onBackPressed() {
        // 如果剩一个说明在主页，提示按两次退出app
        _exit();
    }

    @Override
    public void loadData(EventDetailInfo eventDetailInfo) {
        hideLoading();
        this.eventDetailInfo = eventDetailInfo;
        if (eventDetailInfo != null) {
            errorLl.setVisibility(View.GONE);
            actionNumTv.setText(eventDetailInfo.getEventID());
//            actionApplicantNumTv.setText(eventDetailInfo.getApplicant());
//            actionApplicantNumTv.setText(eventDetailInfo.getContactInfo());
            actionNameTv.setText(eventDetailInfo.getEventName());
            //场地
            //actionCityTv.setText(eventDetailInfo.getSessionVenueName());
            applicantTv.setText(eventDetailInfo.getTicketsTotal());
            noEnterTv.setText(eventDetailInfo.getUncheckinTotal());
            progressBar.setProgress(Double.valueOf(eventDetailInfo.getCheckinRate()).intValue());
            progressBarTv.setText(String.format(getString(R.string.text_progress_bar_info), Double.valueOf(eventDetailInfo.getCheckinRate()).intValue(), eventDetailInfo.getCheckinTotal(), eventDetailInfo.getTicketsTotal()));
            dateTv.setText(eventDetailInfo.getDateValue());
            //timeslotTv.setText(eventDetailInfo.getTimeslotValue());
            addressTv.setText(eventDetailInfo.getAddressValue());
            startTicketBt.setEnabled(true);
            longNameTv.setText(eventDetailInfo.getEventLongName());
            registeredTv.setText(eventDetailInfo.getCheckinTotal());

            if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 2 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 3 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 4 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 5){
                languageLayout.setVisibility(View.VISIBLE);
                languageTv.setText(eventDetailInfo.getLanguage());
            }else{
                languageLayout.setVisibility(View.GONE);
            }

            if(activityCode.contains("-") && SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) != 5){
                venueLayout.setVisibility(View.VISIBLE);
                timeslotLayout.setVisibility(View.VISIBLE);
                //场地
//            actionCityTv.setText(eventDetailInfo.getVenue());
                actionCityTv.setText(eventDetailInfo.getSessionVenueName());
//            timeslotTv.setText(eventDetailInfo.getTimeslot());
                timeslotTv.setText(eventDetailInfo.getTimeslotValue());
            }else {
                venueLayout.setVisibility(View.GONE);
                timeslotLayout.setVisibility(View.GONE);
            }
        } else {
            Log.e(TAG, "失败");
            errorLl.setVisibility(View.VISIBLE);

            actionNumTv.setText("");
            actionNameTv.setText("");
            applicantTv.setText("");
            noEnterTv.setText("");
            progressBar.setProgress(0);
            progressBarTv.setText("");
            dateTv.setText("");
            addressTv.setText("");
            startTicketBt.setEnabled(false);
            longNameTv.setText("");
            registeredTv.setText("");

            if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 2 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 3 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 4){
                languageLayout.setVisibility(View.VISIBLE);
                languageTv.setText("");
            }else{
                languageLayout.setVisibility(View.GONE);
            }

            venueLayout.setVisibility(View.VISIBLE);
            timeslotLayout.setVisibility(View.VISIBLE);
            actionCityTv.setText("");
            timeslotTv.setText("");
        }
    }

    /**
     * 退出
     */
    private void _exit() {
        if (System.currentTimeMillis() - mExitTime > 2000) {
            Toast.makeText(this, getText(R.string.text_exit_app), Toast.LENGTH_SHORT).show();
            mExitTime = System.currentTimeMillis();
        } else {
            finish();
        }
    }

    @Override
    public void loadMoreData(EventDetailInfo data) {

    }

    @Override
    public void loadNoData() {

    }

    public void loadRegionLanguageData(List<RegionLanguageBaseInfo.RegionLanguageModel> data) {
        System.out.println("loadRegionLanguageData");
        //this.regionLanguageInfo = regionLanguageInfo;
        if (data != null) {
            Log.e(TAG, "Retrieve region & language success");
            ArrayList<String> vietnamLanglist = new ArrayList<String>();
            ArrayList<String> japanLanglist = new ArrayList<String>();
            ArrayList<String> bruneiLanglist = new ArrayList<String>();
            ArrayList<String> singaporeLanglist = new ArrayList<String>();
            ArrayList<String> malaysiaLanglist = new ArrayList<String>();
            ArrayList<String> indiaLanglist = new ArrayList<String>();
            ArrayList<String> othersLanglist = new ArrayList<String>();
            ArrayList<Integer> vietnamDefaultCodelist = new ArrayList<Integer>();
            ArrayList<Integer> japanDefaultCodelist = new ArrayList<Integer>();
            ArrayList<Integer> bruneiDefaultCodelist = new ArrayList<Integer>();
            ArrayList<Integer> singaporeDefaultCodelist = new ArrayList<Integer>();
            ArrayList<Integer> malaysiaDefaultCodelist = new ArrayList<Integer>();
            ArrayList<Integer> indiaDefaultCodelist = new ArrayList<Integer>();
            ArrayList<Integer> othersDefaultCodelist = new ArrayList<Integer>();

            ArrayList<String> regionlist = new ArrayList<String>();

            for(int i = 0; i < data.size(); i++) {
                RegionLanguageBaseInfo.RegionLanguageModel currentX = data.get(i);
                // Do something with the value

                if(!regionlist.contains(currentX.getApplicationCode())){
                    if(!currentX.getApplicationCode().equals("") && currentX.getApplicationCode() != null){
                        regionlist.add(currentX.getApplicationCode());
                    }
                }

                if(!currentX.getApplicationCode().equals("") && currentX.getApplicationCode() != null){
                    switch(currentX.getApplicationCode()){
                        case "VN":
                            vietnamLanglist.add(currentX.getLangCode());
                            vietnamDefaultCodelist.add(currentX.getIsDefault());
                            break;
                        case "SG":
                            singaporeLanglist.add(currentX.getLangCode());
                            singaporeDefaultCodelist.add(currentX.getIsDefault());
                            break;
                        case "MY":
                            malaysiaLanglist.add(currentX.getLangCode());
                            malaysiaDefaultCodelist.add(currentX.getIsDefault());
                            break;
                        case "BN":
                            bruneiLanglist.add(currentX.getLangCode());
                            bruneiDefaultCodelist.add(currentX.getIsDefault());
                            break;
                        case "JP":
                            japanLanglist.add(currentX.getLangCode());
                            japanDefaultCodelist.add(currentX.getIsDefault());
                            break;
                        case "IN":
                            indiaLanglist.add(currentX.getLangCode());
                            indiaDefaultCodelist.add(currentX.getIsDefault());
                            break;
                        default:
                            othersLanglist.add(currentX.getLangCode());
                            othersDefaultCodelist.add(currentX.getIsDefault());
                            break;
                    }
                }

                //Display data item of region list
                /*
                for(int j = 0; j < regionlist.size(); j++) {
                    String regionName = regionlist.get(j);
                    // Do something with the value

                    System.out.println(regionName);
                }
                System.out.println(regionlist.size());
                */

                //Gson gson = new Gson();
                //String json = gson.toJson(vietnamLanglist);
                //Log.d(TAG, "saved json is "+ vietnamLanglist);
                //SPUtils.getInstance().put(CommonStringUtil.VIETNAM_LANG_LIST_TAG, json);

                TinyDB tinydb = new TinyDB(getApplicationContext());

                tinydb.putListString(CommonStringUtil.VIETNAM_LANG_LIST_TAG, vietnamLanglist);
                tinydb.putListString(CommonStringUtil.JAPAN_LANG_LIST_TAG, japanLanglist);
                tinydb.putListString(CommonStringUtil.BRUNEI_LANG_LIST_TAG, bruneiLanglist);
                tinydb.putListString(CommonStringUtil.SINGAPORE_LANG_LIST_TAG, singaporeLanglist);
                tinydb.putListString(CommonStringUtil.MALAYSIA_LANG_LIST_TAG, malaysiaLanglist);
                tinydb.putListString(CommonStringUtil.INDIA_LANG_LIST_TAG, indiaLanglist);
                tinydb.putListString(CommonStringUtil.OTHERS_LANG_LIST_TAG, othersLanglist);
                tinydb.putListInt(CommonStringUtil.VIETNAM_DEFAULT_CODE_LIST_TAG, vietnamDefaultCodelist);
                tinydb.putListInt(CommonStringUtil.JAPAN_DEFAULT_CODE_LIST_TAG, japanDefaultCodelist);
                tinydb.putListInt(CommonStringUtil.BRUNEI_DEFAULT_CODE_LIST_TAG, bruneiDefaultCodelist);
                tinydb.putListInt(CommonStringUtil.SINGAPORE_DEFAULT_CODE_LIST_TAG, singaporeDefaultCodelist);
                tinydb.putListInt(CommonStringUtil.MALAYSIA_DEFAULT_CODE_LIST_TAG, malaysiaDefaultCodelist);
                tinydb.putListInt(CommonStringUtil.INDIA_DEFAULT_CODE_LIST_TAG, indiaDefaultCodelist);
                tinydb.putListInt(CommonStringUtil.OTHERS_DEFAULT_CODE_LIST_TAG, othersDefaultCodelist);
                tinydb.putListString(CommonStringUtil.REGION_LIST_TAG, regionlist);

                //System.out.println("========");
                //for(int j = 0; j < tinydb.getListString(CommonStringUtil.REGION_LIST_TAG).size(); j++) {
                //    String regionName1 = tinydb.getListString(CommonStringUtil.REGION_LIST_TAG).get(j);
                //    // Do something with the value

                //    System.out.println(regionName1);
                //}
                //System.out.println("========");
            }
        } else {
            Log.e(TAG, "Retrieve region & language fail");
        }
    }

    public void loadRegionData(List<RegionBaseInfo.RegionModel> data) {
        System.out.println("loadRegionData");

        if (data != null) {
            Log.e(TAG, "Retrieve region code & region name success");

            ArrayList<String> regionnamelist = new ArrayList<String>();
            ArrayList<String> applicationinforegionlist = new ArrayList<String>();

            for(int i = 0; i < data.size(); i++) {
                RegionBaseInfo.RegionModel currentX = data.get(i);
                // Do something with the value

                if(!applicationinforegionlist.contains(currentX.getApplicationCode())){
                    if(!currentX.getApplicationCode().equals("") && currentX.getApplicationCode() != null){
                        if(currentX.getIsWorkflow() == 1){
                            applicationinforegionlist.add(currentX.getApplicationCode());
                            regionnamelist.add(currentX.getApplicationNameEn());
                        }
                    }
                }

                TinyDB tinydb = new TinyDB(getApplicationContext());
                tinydb.putListString(CommonStringUtil.APPLICATION_INFO_REGION_LIST_TAG, applicationinforegionlist);
                tinydb.putListString(CommonStringUtil.REGION_NAME_LIST_TAG, regionnamelist);
            }
        } else {
            Log.e(TAG, "Retrieve region code & region name fail");
        }

    }

    /**
     * 打开扫码页面
     */
    private void startScan() {
        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeCustomAnimation(this, R.anim.fade_in_anim, R.anim.fade_out_anim);
        Intent intent = new Intent(this, MainCaptureActivity.class);
        ActivityCompat.startActivityForResult(this, intent, REQUEST_CODE_SCAN, optionsCompat.toBundle());
    }

    /**
     * 打开验票页面
     *
     * @param eventDetailInfo 活动信息
     */
    private void startTicket(EventDetailInfo eventDetailInfo) {
        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeCustomAnimation(this, R.anim.fade_in_anim, R.anim.fade_out_anim);
        Intent intent = new Intent(this, MainTicketActivity.class);
        intent.putExtra(MainTicketActivity.ACTION_DETAIL, eventDetailInfo);
        ActivityCompat.startActivity(this, intent, optionsCompat.toBundle());
    }

    private void checkCameraPermissions() {
        new RxPermissions(this)
                .request(Manifest.permission.CAMERA)
                .subscribe(new Action1<Boolean>() {
                               @Override
                               public void call(Boolean granted) {
                                   if (granted) {
                                       startScan();
                                   } else {
                                       SnackbarUtils.showSnackbar(MainActivity.this, getString(R.string.permission_camera), true);
                                   }
                               }
                           }
                );
    }

    private void checkeventcheckCameraPermissions() {
        new RxPermissions(this)
                .request(Manifest.permission.CAMERA)
                .subscribe(new Action1<Boolean>() {
                               @Override
                               public void call(Boolean granted) {
                                   if (granted) {
                                       startTicket(eventDetailInfo);
                                   } else {
                                       SnackbarUtils.showSnackbar(MainActivity.this, getString(R.string.permission_camera), true);
                                   }
                               }
                           }
                );
    }

    @OnClick({R.id.scan_iv, R.id.query_bt, R.id.start_ticket_bt, R.id.ivRight})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.scan_iv:
                //点击扫描页面
                checkCameraPermissions();
                break;
            case R.id.start_ticket_bt:
                //点击验票页面8b4a2399-8f73-4bf0-b27f-729e3dd23fa6
                //startTicket(eventDetailInfo);
                checkeventcheckCameraPermissions();
                break;
            case R.id.query_bt:
                //查询
                if (!StringUtils.isEmpty(enterEt.getText().toString())) {
                    showLoading();
                    activityCode = enterEt.getText().toString();
                    UrlModule.getInstance().eventID = activityCode;
                    mPresenter.getEventDetail(mContext, UrlModule.getInstance().regionCode, activityCode);
                }
//                ToastUtils.showToast(UrlModule.getInstance().url);

                break;
            case R.id.ivRight:
                //語言和區域選擇頁面
                SelectMainActivity.launch(this);
                //SelectLanguageRegionActivity.launch(this);
                break;

        }
    }

    private String activityCode = "";
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            switch (requestCode) {
                case REQUEST_CODE_SCAN:
                    String result = data.getStringExtra(Intents.Scan.RESULT);
                    if (result.contains("#;")) {
                        String code = result.substring(result.indexOf("#;") + 2, result.length());
                        enterEt.setText(code);
                    } else {
//                        ToastUtils.showToast(getString(R.string.text_main_code_invalid));
//                        String code = result.substring(result.indexOf("#;") + 2, result.length());
                        enterEt.setText(result);
                        if (!StringUtils.isEmpty(enterEt.getText().toString())) {
                            showLoading();
                            activityCode = enterEt.getText().toString();
                            UrlModule.getInstance().eventID = activityCode;
                            mPresenter.getEventDetail(mContext, UrlModule.getInstance().regionCode, activityCode);
                        }
                    }
//                    Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
                    break;
            }

        }
    }

    /**
     * Get region and language list
     */
    public void getRegionLanguageDetail() {
        Map<String, String> parammMap = new HashMap<>();
        //parammMap.put("regionCode", regionCode);
        //parammMap.put("eventID", eventID);

        final String login ="event";
        final String password ="event123";
        String credential = Credentials.basic(login, password);

        String urlHeader;
        if (BuildConfig.DEBUG) {
            urlHeader = "https://bookingapi-qa.amway.com";
        }else{
            urlHeader = "https://bookingapi.amway.com";
        }

        String url = urlHeader + TicketApi.CHECKIN_EVENT_REGIONLANGUAGE_URL;
        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(parammMap))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                //.addHeader("User-Agent", UserAgentUtil.getUserAgent(context))
                .addHeader("Authorization", credential)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        String code = MyErrcodeEnum.FAIL.getVal().toString();
                        Log.w(TAG, "Retrieved region & language failed，Code：" + code);
                        loadRegionLanguageData(null);
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        String code = MyErrcodeEnum.SUCCESS.getVal().toString();
                        if (!StringUtils.isEmpty(response)) {
                            Log.w(TAG, response);
                            //成功
                            RegionLanguageBaseInfo regionLanguageInfo = new Gson().fromJson(response, RegionLanguageBaseInfo.class);
                            /*LoginHttpResult<EventDetailInfo> loginInfo = new Gson().fromJson(response,
                                    new TypeToken<EventDetailInfo>() {
                                    }.getType());*/

                            if (code.equals(regionLanguageInfo.getResultCode() + "")) {
                                //成功
                                
                                Log.w(TAG, "Retrieved region & language success，Code：" + code);
                                loadRegionLanguageData(regionLanguageInfo.getData());
                            } else {
                                //业务失败鸟
                                loadRegionLanguageData(null);
                            }

                        } else {
                            loadRegionLanguageData(null);
                        }
                    }
                });
    }

    /**
     * Get region list
     */
    public void getRegionDetail() {
        Map<String, String> parammMap = new HashMap<>();
        //parammMap.put("regionCode", regionCode);
        //parammMap.put("eventID", eventID);

        final String login ="event";
        final String password ="event123";
        String credential = Credentials.basic(login, password);

        String urlHeader;
        if (BuildConfig.DEBUG) {
            urlHeader = "https://bookingapi-qa.amway.com";
        }else{
            urlHeader = "https://bookingapi.amway.com";
        }

        String url = urlHeader + TicketApi.CHECKIN_EVENT_REGION_URL;
        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(parammMap))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                //.addHeader("User-Agent", UserAgentUtil.getUserAgent(context))
                .addHeader("Authorization", credential)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        String code = MyErrcodeEnum.FAIL.getVal().toString();
                        Log.w(TAG, "Retrieved region code & region name failed，Code：" + code);
                        loadRegionData(null);
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        String code = MyErrcodeEnum.SUCCESS.getVal().toString();
                        if (!StringUtils.isEmpty(response)) {
                            Log.w(TAG, response);
                            //成功
                            RegionBaseInfo regionInfo = new Gson().fromJson(response, RegionBaseInfo.class);
                            /*LoginHttpResult<EventDetailInfo> loginInfo = new Gson().fromJson(response,
                                    new TypeToken<EventDetailInfo>() {
                                    }.getType());*/

                            if (code.equals(regionInfo.getResultCode() + "")) {
                                //成功

                                Log.w(TAG, "Retrieved region code & region name success，Code：" + code);
                                loadRegionData(regionInfo.getData());
                            } else {
                                //业务失败鸟
                                loadRegionData(null);
                            }

                        } else {
                            loadRegionData(null);
                        }
                    }
                });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);

        //int DOUBLE_CLICK_DELAY_TIME = 500;
        //long currentTime = System.currentTimeMillis();
        //if ((currentTime - (SPUtils.getInstance().getLong(CommonStringUtil.MIN_API_DELAY_TAG, 0))) > DOUBLE_CLICK_DELAY_TIME) {
        //    SPUtils.getInstance().put(CommonStringUtil.MIN_API_DELAY_TAG, currentTime);
        //    getRegionLanguageDetail();
        //}

        getRegionLanguageDetail();
        getRegionDetail();
        if (SPUtils.getInstance().getString(CommonStringUtil.FIRST_TIME_TAG, "") == "") {
            SelectLanguageRegionActivity.launch(this);
            finish();
        }
    }
}
