package com.amway.e_ticket.data;

/**
 * 用户数据模型.<br>
 *
 * @author Administrator <br>
 * @version 1.0.0 2018年8月28日<br>
 * @see
 * @since JDK 1.5.0
 */
public class UserModule {
    private static UserModule instance = null;

    private UserModule() {
    }

    public static UserModule getInstance() {
        if (instance == null) {
            instance = new UserModule();
        }
        return instance;
    }

    //登录时的账号
    public String loginPhone = "";
    //name
    public String name = "";
    //token
    public String token = "";

    /**
     * 用户头像路径
     */
    public String headPhotoPath = "";

    public long userId;

    /**
     * 清除缓存信息
     */
    public void cleanInfo() {
        loginPhone = "";
        token = "";
        userId = -1;
        headPhotoPath = "";
    }
}
