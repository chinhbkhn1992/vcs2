package com.amway.e_ticket.model;

import java.io.Serializable;

/**
 * 公共数据模型
 * Created by shaorulong on 2019/8/5.
 */
public class CheckTicketInfo implements Serializable {

    private int resultCode;
    private String resultMsg;
    private String errorCode;
    private String errorParams;
    //票码
    private String ticketCode;
    //验票次数
    private int checkCount;
    //门票类型
    private String ticketTypeName;
    //门票类型码
    private String ticketTypeCode;
    //
    private String seat;
    //状态
    private int status;
    private String ada;
    private String kanjiName;
    private String aboInput;
    private boolean isAbo;

    private String formatString(String str){
        return str == null?"":str;
    }

    public String getAda() {
        return formatString(ada);
    }

    public void setAda(String ada) {
        this.ada = ada;
    }

    public String getKanjiName() {
        return formatString(kanjiName);
    }

    public void setKanjiName(String kanjiName) {
        this.kanjiName = kanjiName;
    }

    public String getAboInput() {
        return formatString(aboInput);
    }

    public void setAboInput(String aboInput) {
        this.aboInput = aboInput;
    }

    public boolean isAbo() {
        return isAbo;
    }

    public void setAbo(boolean abo) {
        isAbo = abo;
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorParams() {
        return errorParams;
    }

    public void setErrorParams(String errorParams) {
        this.errorParams = errorParams;
    }

    public String getTicketCode() {
        return formatString(ticketCode);
    }

    public void setTicketCode(String ticketCode) {
        this.ticketCode = ticketCode;
    }

    public int getCheckCount() {
        return checkCount;
    }

    public void setCheckCount(int checkCount) {
        this.checkCount = checkCount;
    }

    public String getTicketTypeName() {
        return formatString(ticketTypeName);
    }

    public void setTicketTypeName(String ticketTypeName) {
        this.ticketTypeName = ticketTypeName;
    }

    public String getTicketTypeCode() {
        return ticketTypeCode;
    }

    public void setTicketTypeCode(String ticketTypeCode) {
        this.ticketTypeCode = ticketTypeCode;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
