package com.amway.e_ticket.module.ticket;

import android.content.Context;
import android.util.Log;

import com.amway.e_ticket.api.TicketApi;
import com.amway.e_ticket.model.CheckTicketInfo;
import com.amway.e_ticket.model.EventDetailInfo;
import com.amway.e_ticket.model.UrlModule;
import com.amway.e_ticket.utils.UserAgentUtil;
import com.blankj.utilcode.util.StringUtils;
import com.google.gson.Gson;
import com.isoft.frame.base.IBasePresenter;
import com.isoft.frame.base.ILoadDataView;
import com.isoft.frame.network.http.MyErrcodeEnum;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;

import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by shaorulong on 2018/8/23.
 * 获取用户数据 Presenter
 */
public class MainTicketPresenter implements IBasePresenter {

    private ILoadDataView mView;
//    private UsreService mUsreService;
    private String TAG = "";

    public MainTicketPresenter(ILoadDataView view) {
        this.mView = view;
//        mUsreService = new UsreService();
    }

    /**
     * 获取活动详情
     * @param context 上下文
     * @param eventID 活动id
     * @param qrCode 二维码内容
     */
    public void getEventDetail(Context context, String eventID, String qrCode) {
        Map<String, String> parammMap = new HashMap<>();
        parammMap.put("eventID", eventID);
        parammMap.put("qrCode", qrCode);

        String url = UrlModule.getInstance().url + TicketApi.CHECKIN_EVENT_TICKET_URL;
        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(parammMap))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .addHeader("User-Agent", UserAgentUtil.getUserAgent(context))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        e.printStackTrace();
                        String code = MyErrcodeEnum.FAIL.getVal().toString();
                        Log.w(TAG, "失败，Code：" + code);
                        mView.loadData(null);
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.w(TAG, "成功："+response);
                        String code = MyErrcodeEnum.SUCCESS.getVal().toString();
                        if (!StringUtils.isEmpty(response)) {
                            Log.w(TAG, response);
                            //成功
                            CheckTicketInfo checkTicketInfo = new Gson().fromJson(response, CheckTicketInfo.class);
                            /*LoginHttpResult<EventDetailInfo> loginInfo = new Gson().fromJson(response,
                                    new TypeToken<EventDetailInfo>() {
                                    }.getType());*/
                            mView.loadData(checkTicketInfo);
                           /* if (code.equals(checkTicketInfo.getResultCode() + "")) {
                                //成功
                                mView.loadData(checkTicketInfo);
                            } else {
                                //业务失败鸟
                                mView.loadData(MainTicketActivity.SCANNE_STATE_FAIL);
                            }*/

                        } else {
                            mView.loadData(null);
                        }
                    }
                });
    }
    /**
     * 获取活动详情
     */
    public void getCheckinEventDetail(Context context) {
        Map<String, String> parammMap = new HashMap<>();
        parammMap.put("regionCode", UrlModule.getInstance().regionCode);
        parammMap.put("eventID", UrlModule.getInstance().eventID);

        String url = UrlModule.getInstance().url + TicketApi.CHECKIN_EVENT_DETAIL_URL;
        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(parammMap))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .addHeader("User-Agent", UserAgentUtil.getUserAgent(context))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        String code = MyErrcodeEnum.SUCCESS.getVal().toString();
                        if (!StringUtils.isEmpty(response)) {
                            EventDetailInfo eventDetailInfo = new Gson().fromJson(response, EventDetailInfo.class);
                            if (code.equals(eventDetailInfo.getResultCode() + "")) {
                                //成功
                                EventBus.getDefault().post(eventDetailInfo);
                            }
                        }
                    }
                });
    }

    @Override
    public void getData(boolean isRefresh) {


    }

    @Override
    public void getMoreData() {

    }
}
