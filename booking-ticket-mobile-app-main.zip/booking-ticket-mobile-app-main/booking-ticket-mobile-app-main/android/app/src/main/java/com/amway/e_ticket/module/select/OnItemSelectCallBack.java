package com.amway.e_ticket.module.select;

/**
 * 区域and语言选择回调接口.
 */
public interface OnItemSelectCallBack {

    /**
     * 回调触发接口.
     * @param type 选择语言还是选择区域，0：语言，1区域
     * @param selectedItemPosition 选择了第几项
     */
    void OnItemSelect(int type, int selectedItemPosition);
}
