package com.amway.e_ticket.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.zyyoona7.wheel.IWheelEntity;

import java.io.Serializable;

/**
 * 区域码数据模型.
 * @author rlshao
 */
public class AreaInfo implements IWheelEntity, Serializable {

    /**
     * area : 安麗（台灣）
     * regionCode : 130
     * language : 繁體中文
     * releaseUrl :
     * debugUrl : 130
     */
    private String area;
    private String regionCode;
    private String language;
    private String data;
    private String releaseUrl;
    private String debugUrl;

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getReleaseUrl() {
        return releaseUrl;
    }

    public void setReleaseUrl(String releaseUrl) {
        this.releaseUrl = releaseUrl;
    }

    public String getDebugUrl() {
        return debugUrl;
    }

    public void setDebugUrl(String debugUrl) {
        this.debugUrl = debugUrl;
    }

    /**
     * 重点：重写此方法，返回 WheelView 显示的文字
     * @return
     */
    @Override
    public String getWheelText() {
        return area == null ? "" : area;
    }
}
