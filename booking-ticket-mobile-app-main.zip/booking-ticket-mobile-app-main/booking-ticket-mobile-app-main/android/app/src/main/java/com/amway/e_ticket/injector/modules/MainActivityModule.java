package com.amway.e_ticket.injector.modules;

import com.amway.e_ticket.MainPresenter;
import com.isoft.frame.base.ILoadDataView;

import dagger.Module;
import dagger.Provides;

/**
 * Created by shaorulong on 2018/6/14.
 * 管理
 */
@Module
public class MainActivityModule {

    private final ILoadDataView mView;

    public MainActivityModule(ILoadDataView view) {
        mView = view;
    }

    @Provides
    public MainPresenter provideManagePresenter() {
        return new MainPresenter(mView);
    }

}
