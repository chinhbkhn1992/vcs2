package com.amway.e_ticket.model;

/**
 * 请求地址数据模型.<br>
 *
 * @author rlshao <br>
 * @version 1.0.0 2019年8月20日<br>
 * @see
 * @since JDK 1.5.0
 */
public class UrlModule {

    private static UrlModule instance = null;

    private UrlModule() {
    }

    public static UrlModule getInstance() {
        if (instance == null) {
            instance = new UrlModule();
        }
        return instance;
    }

    //对外请求地址
    public String url = "";
    //区域code
    public String regionCode = "";
    public String eventID = "";
}
