package com.amway.e_ticket.module.ticket;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.amway.e_ticket.R;
import com.amway.e_ticket.model.CheckTicketInfo;
import com.amway.e_ticket.model.EventDetailInfo;
import com.amway.e_ticket.model.ScannState;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.blankj.utilcode.util.SPUtils;
import com.isoft.frame.base.BaseActivity;
import com.isoft.frame.base.ILoadDataView;
import com.isoft.frame.network.http.MyErrcodeEnum;
import com.isoft.frame.utils.NetUtil;
import com.isoft.frame.widget.TipsDialog;
import com.jaeger.library.StatusBarUtil;
import com.jakewharton.rxbinding.view.RxView;
import com.king.zxing.Intents;
import com.king.zxing.OnCaptureCustomCallback;
import com.orhanobut.logger.Logger;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.OnClick;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;

/**
 * 活动首页扫码。
 */
public class MainTicketActivity extends BaseActivity<MainTicketPresenter> implements ILoadDataView<CheckTicketInfo>, OnCaptureCustomCallback {

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.title_ll)
    LinearLayout titleLl;
    @BindView(R.id.top_view)
    View topView;
    @BindView(R.id.ivLeft)
    ImageView ivLeft;

    @BindView(R.id.ivTitle)
    ImageView ivTitle;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    TicketScannFragment captureFragment;
    TicketUserFragment userFragment;

    @BindView(R.id.rb_main_scan)
    RadioButton rbMainScan;
    @BindView(R.id.rb_main_people)
    RadioButton rbMainPeople;
    @BindView(R.id.main_rg)
    RadioGroup mainRg;

    //返回结果标识
    public static final String CAPTURE_RESULT = Intents.Scan.RESULT;
    //活动id
    public static final String ACTION_DETAIL = "ACTION_DETAIL";
    //日志tag
    private static final String TAG = "MainTicketActivity";
    //活动信息
    private EventDetailInfo eventDetailInfo;

    //扫码成功
    public static final String SCANNE_STATE_SUCCESS = "0";

    //扫码失败
    public static final String SCANNE_STATE_FAIL = "1";

    //扫描返回的二维码
//    private String rqCode;
    private Subscriber<? super String> msubscriber;



    @Override
    protected int attachLayoutRes() {
        return R.layout.activity_ticket_main;
    }

    @Override
    protected void initInjector() {
        mPresenter = new MainTicketPresenter(this);
    }
    private TipsDialog tipsDialog;
    @Override
    protected void initViews() {
//        initToolBarView(titleLl, topView);
        StatusBarUtil.setTranslucent(this,0);
        StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary));
        tvTitle.setText(getString(R.string.text_capture_main_title));

        eventDetailInfo = getIntent().getParcelableExtra(ACTION_DETAIL);
        initFragment();

        mainRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == rbMainScan.getId()){
                    //扫码页面
                    changeFragment(0);
                    tvTitle.setText(getString(R.string.text_capture_main_title));
                } else {
                    //人员页面
                    changeFragment(1);
                    tvTitle.setText("");
                }
            }
        });

        //扫码结果，2s内只响应一次点击
        Observable.create(new Observable.OnSubscribe<String>() {

            @Override
            public void call(Subscriber<? super String> subscriber) {
                msubscriber = subscriber;

            }
        })
        //2s只响应一次点击
        .throttleFirst(5, TimeUnit.SECONDS)
        .subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                if(isOnNet)//在请求中，防止重复连续扫描
                    return;
                if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) != 5) {
                    if (TextUtils.isEmpty(s) || s.length() < 30 || s.length() > 65 || !s.contains("#")) {
                        if (tipsDialog == null) {
                            tipsDialog = new TipsDialog(MainTicketActivity.this);
                        }
                        String dialogContent = getString(R.string.invalid_code);
                        tipsDialog.setContent(dialogContent);
                        if (tipsDialog.isShowing())
                            return;
                        tipsDialog.show();
                        captureFragment.initWattingView();
                        return;
                    }
                } else {
                    if (TextUtils.isEmpty(s) || s.length() < 10 || s.length() > 65) {
                        if (tipsDialog == null) {
                            tipsDialog = new TipsDialog(MainTicketActivity.this);
                        }
                        String dialogContent = getString(R.string.invalid_code);
                        tipsDialog.setContent(dialogContent);
                        if (tipsDialog.isShowing())
                            return;
                        tipsDialog.show();
                        captureFragment.initWattingView();
                        return;
                    }
                }
                //判断网络是否可用
                if (!NetUtil.isNetworkAvailable(getApplication())) {
                    captureFragment.setTipState(ScannState.NET_ERROR, null);
                    return;
                }
                //扫码成功
                captureFragment.setTipState(ScannState.SCANN_SUCCESS, null);
                isOnNet = true;
                mPresenter.getEventDetail(mContext, eventDetailInfo.getEventID(), s);
//                //测试数据
//                mPresenter.getEventDetail(mContext, "E03200521931", "3345752f-ead3-4d3f-a815-37de0a0349cd");
            }
        });

    }



    @Override
    protected void updateViews(boolean isRefresh) {

    }

    @OnClick({R.id.ivLeft})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivLeft:
                //点击返回按钮
                onBackPressed();
                break;
        }
    }

    /**
     * 接收扫码结果回调
     *
     * @param result 扫码结果
     * @return 返回true表示拦截，将不自动执行后续逻辑，为false表示不拦截，默认不拦截
     */
    @Override
    public void onResultCallback(final String result) {
        Logger.d("扫码返回：" + result);

        //控制两s之内只进行一次网络请求
//        rqCode = result;
        msubscriber.onNext(result);

        /*new CountDownTimer(1 * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                //多少秒后重试
            }

            @Override
            public void onFinish() {

                mPresenter.getEventDetail(eventDetailInfo.getEventID(), result);

                *//*Intent intent = new Intent();
                intent.putExtra(CAPTURE_RESULT, result);
                setResult(Activity.RESULT_OK, intent);
                finish();*//*
            }
        }.start();*/
    }

    /**
     * 初始化页面.
     */
    private void initFragment() {

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        captureFragment = TicketScannFragment.newInstance();
        userFragment = TicketUserFragment.newInstance(eventDetailInfo);
        ft.add(R.id.center_view_main_rl, userFragment);
        ft.add(R.id.center_view_main_rl, captureFragment);

        //提交   一定一定要提交
        ft.commit();

        captureFragment.setCallBack(this);
    }

    /**
     * 切换Fragment.
     * @param index 0是选择扫码页，其他是人员页
     */
    public void changeFragment(int index) {

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        if (index == 0) {
            ft.hide(userFragment);
            ft.show(captureFragment);
//            loginByAdaFragment.clearFocus();
        } else {
            ft.hide(captureFragment);
            ft.show(userFragment);
            mPresenter.getCheckinEventDetail(getApplicationContext());
//            loginByPhoneFragment.clearFocus();
        }

        ft.commit();
    }
    private boolean isOnNet = false;
    @Override
    public void loadData(CheckTicketInfo data) {
        isOnNet = false;
        String code = MyErrcodeEnum.SUCCESS.getVal().toString();
        if (data != null && code.equals(data.getResultCode() + "")) {
            captureFragment.setTipState(ScannState.TICKTT_SUCCESS, data);
        } else {
            captureFragment.setTipState(ScannState.TICKTT_ERROR, null);
        }
    }


    @Override
    public void loadMoreData(CheckTicketInfo data) {
        Log.w(TAG, "loadMoreData");
    }

    @Override
    public void loadNoData() {

    }
}
