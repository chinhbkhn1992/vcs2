package com.amway.e_ticket.module.capture;

import android.app.Activity;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.amway.e_ticket.R;
import com.isoft.frame.base.BaseActivity;
import com.jaeger.library.StatusBarUtil;
import com.king.zxing.CaptureFragment;
import com.king.zxing.Intents;
import com.king.zxing.OnCaptureCustomCallback;
import com.orhanobut.logger.Logger;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 活动首页扫码。
 */
public class MainCaptureActivity extends BaseActivity implements OnCaptureCustomCallback {

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.ivLeft)
    ImageView ivLeft;

    @BindView(R.id.ivTitle)
    ImageView ivTitle;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

//    成功提示语
    @BindView(R.id.success_tip_ll)
    LinearLayout successTipLl;

    public static final String TAG = "MainCaptureActivity";
    //返回结果标识
    public static final String CAPTURE_RESULT = Intents.Scan.RESULT;


    @Override
    protected int attachLayoutRes() {
        return R.layout.activity_capture_main;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        StatusBarUtil.setTranslucent(this,0);
        StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary));
        tvTitle.setText(getString(R.string.text_capture_main_title));

        replaceFragment(CaptureFragment.newInstance());
    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    @OnClick({R.id.ivLeft})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivLeft:
                //点击返回按钮
                onBackPressed();
                break;
        }
    }

    /**
     * 接收扫码结果回调
     *
     * @param result 扫码结果
     * @return 返回true表示拦截，将不自动执行后续逻辑，为false表示不拦截，默认不拦截
     */
    @Override
    public void onResultCallback(final String result) {
        Log.d(TAG,"扫码返回：" + result);
        successTipLl.setVisibility(View.VISIBLE);
        new CountDownTimer(1 * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                //多少秒后重试
                Log.w(TAG, "millisUntilFinished:" + millisUntilFinished);
            }

            @Override
            public void onFinish() {
                Intent intent = new Intent();
                intent.putExtra(CAPTURE_RESULT, result);
                setResult(Activity.RESULT_OK, intent);
                finish();
            }
        }.start();
    }

    public void replaceFragment(Fragment fragment) {
        replaceFragment(R.id.fragmentContent, fragment);
    }

    public void replaceFragment(@IdRes int id, Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(id, fragment).commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CaptureFragment.newInstance().onDestroy();
    }
}
