package com.amway.e_ticket.module.ticket;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.amway.e_ticket.R;
import com.amway.e_ticket.model.CheckTicketInfo;
import com.amway.e_ticket.model.ScannState;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.blankj.utilcode.util.ConvertUtils;
import com.blankj.utilcode.util.SPUtils;
import com.isoft.frame.widget.TipsDialog;
import com.king.zxing.CaptureHelper;
import com.king.zxing.Intents;
import com.king.zxing.OnCaptureCallback;
import com.king.zxing.OnCaptureCustomCallback;
import com.king.zxing.ViewfinderView;
import com.king.zxing.camera.CameraManager;

import java.io.IOException;

/**
 * 验票扫码页面,只负责识别二维码，把识别到的码发送给MainTicketActivity处理
 * @author shaorulong
 */
public class TicketScannFragment extends Fragment implements OnCaptureCallback, View.OnClickListener {

    public static final String KEY_RESULT = Intents.Scan.RESULT;

    private View mRootView;

    private Button testBtn;
    //提示語
    private TextView tipTv;

    private SurfaceView surfaceView;
    private ViewfinderView viewfinderView;

    private CaptureHelper mCaptureHelper;
    //自定义接收参数
    private OnCaptureCustomCallback callBack;


    private LinearLayout scannTipLl;

    private LinearLayout resultWattingLl;
    private LinearLayout resultFailLl;
    private LinearLayout resultSuccessLl;
    private RelativeLayout resultContainerRl;

    //票码
    private TextView ticketNumberTv;
    //验票次数
    private TextView ticketCheckCountTv;
    //门票类型
    private TextView ticketTypeTv;
    private TextView ticketAboIdTv;
    private TextView ticketKanJiNameTv;
    private TextView ticketAboInputTv;

    //重新扫描后的图片和文字
    private ImageView resultSuccesssImg;
    private  TextView resultSuccessTv;

    public static TicketScannFragment newInstance() {

        Bundle args = new Bundle();

        TicketScannFragment fragment = new TicketScannFragment();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        int layoutId = getLayoutId();
        if(isContentView(layoutId)){
            mRootView = inflater.inflate(getLayoutId(),container,false);
        }
        initUI();
        return mRootView;
    }

    @Override
    public void onStart() {
        super.onStart();

//         CheckTicketInfo info = new CheckTicketInfo();
//         info.setCheckCount(2);
//         info.setErrorCode("123456789");
//         info.setTicketTypeName("VIP");
//         setTipState(ScannState.TICKTT_SUCCESS, info);
    }

    /**
     * 初始化
     */
    public void initUI(){
        surfaceView = mRootView.findViewById(getSurfaceViewId());
        viewfinderView = mRootView.findViewById(getViewfinderViewId());

        scannTipLl = mRootView.findViewById(R.id.scann_tip_ll);
        resultWattingLl = mRootView.findViewById(R.id.state_result_watting_ll);
        resultFailLl = mRootView.findViewById(R.id.state_result_fail_ll);
        resultSuccessLl = mRootView.findViewById(R.id.state_result_success_ll);
        resultContainerRl = mRootView.findViewById(R.id.result_container_rl);

        resultSuccessTv=mRootView.findViewById(R.id.state_result_success_tv);
        resultSuccesssImg=mRootView.findViewById(R.id.state_result_success_img);
        ticketNumberTv = mRootView.findViewById(R.id.ticket_num_tv);
        ticketCheckCountTv = mRootView.findViewById(R.id.ticket_count_tv);
        ticketTypeTv = mRootView.findViewById(R.id.ticket_type_tv);
        ticketAboIdTv = mRootView.findViewById(R.id.ticket_abo_id_tv);
        ticketKanJiNameTv = mRootView.findViewById(R.id.ticket_kanji_name_tv);
        ticketAboInputTv = mRootView.findViewById(R.id.ticket_abo_input_tv);



        mCaptureHelper = new CaptureHelper(this,surfaceView,viewfinderView);
        mCaptureHelper.continuousScan(true);//是否连扫
        mCaptureHelper.setOnCaptureCallback(this);

        tipTv = mRootView.findViewById(R.id.tip_tv);
        testBtn = mRootView.findViewById(R.id.test_btn);
        testBtn.setOnClickListener(this);
    }

    /**
     * 3秒后重新显示等待扫描
     * CountDownTimer timer = new CountDownTimer(2000, 1000)中，
     * 第一个参数表示总时间，第二个参数表示间隔时间。
     * 意思就是每隔一秒会回调一次方法onTick，然后1秒之后会回调onFinish方法。
     */
    CountDownTimer timer = new CountDownTimer(3000, 1000) {
        public void onTick(long millisUntilFinished) {
//                txt.setText("倒计时" + millisUntilFinished / 1000 + "秒");
        }

        public void onFinish() {
//            if(getActivity().isFinishing())
//                return;
//            tipTv.setText(R.string.text_scann_watting);
//            scannTipLl.setBackgroundResource(R.drawable.bg_shap_gray1);
//            resultWattingLl.setVisibility(View.VISIBLE);
//            resultFailLl.setVisibility(View.GONE);
//            resultSuccessLl.setVisibility(View.GONE);

        }
    };

    public void initWattingView(){
        tipTv.setText(R.string.text_scann_watting);
        scannTipLl.setBackgroundResource(R.drawable.bg_shap_gray1);
        resultWattingLl.setVisibility(View.VISIBLE);
        resultFailLl.setVisibility(View.GONE);
        resultSuccessLl.setVisibility(View.GONE);
        resultSuccessTv.setTextColor(getResources().getColor(R.color.pass_green));
    }


    /**
     * 設置提示語狀態
     * @param state 0，watting，1网络错误，2扫描成功，3扫描成功,非本场活动，4扫描成功，票可以通过
     * @param checkTicketInfo 只有state = 4（扫描成功，票可以通过）才有值
     */
    public void setTipState(int state, CheckTicketInfo checkTicketInfo) {
        if(diaLogIsShow)return;
        if (state == ScannState.NET_ERROR) {
            playVoiceAndVibrate(ScannState.TICKTT_ERROR);
            //网络错误
            tipTv.setText(R.string.text_error_network);
//            scannTipLl.setBackgroundResource(R.drawable.bg_shap_blue_btn);
            scannTipLl.setBackgroundResource(R.drawable.bg_shap_gray1);
            resultWattingLl.setVisibility(View.VISIBLE);
            resultFailLl.setVisibility(View.GONE);
            resultSuccessLl.setVisibility(View.GONE);
            //调用 CountDownTimer 对象的 start() 方法开始倒计时，也不涉及到线程处理
            timer.start();
        } else if (state == ScannState.SCANN_SUCCESS) {
            // 扫描成功
            tipTv.setText(R.string.text_capture_scann_success_tip);
            scannTipLl.setBackgroundResource(R.drawable.bg_shap_blue_btn);
//            scannTipLl.setBackgroundResource(R.drawable.bg_shap_gray1);
            resultWattingLl.setVisibility(View.VISIBLE);
            resultFailLl.setVisibility(View.GONE);
            resultSuccessLl.setVisibility(View.GONE);
            //调用 CountDownTimer 对象的 start() 方法开始倒计时，也不涉及到线程处理
            timer.start();
        } else if (state == ScannState.TICKTT_ERROR) {
            playVoiceAndVibrate(ScannState.TICKTT_ERROR);
            //不是本场活动
            tipTv.setText(R.string.text_capture_scann_success_tip);
            scannTipLl.setBackgroundResource(R.drawable.bg_shap_blue_btn);
//            scannTipLl.setBackgroundResource(R.drawable.bg_shap_gray1);
            resultWattingLl.setVisibility(View.GONE);
            resultFailLl.setVisibility(View.VISIBLE);
            resultSuccessLl.setVisibility(View.GONE);
            //调用 CountDownTimer 对象的 start() 方法开始倒计时，也不涉及到线程处理
            timer.start();
        } else if (state == ScannState.TICKTT_SUCCESS) {
            //扫描成功，是本场活动
            tipTv.setText(R.string.text_capture_scann_success_tip);
            scannTipLl.setBackgroundResource(R.drawable.bg_shap_blue_btn);
            resultWattingLl.setVisibility(View.GONE);
            resultFailLl.setVisibility(View.GONE);
            resultSuccessLl.setVisibility(View.VISIBLE);

            ticketNumberTv.setText(String.format(getString(R.string.text_ticket_scann_result_success), checkTicketInfo.getTicketCode()));
            ticketCheckCountTv.setText(String.format(getString(R.string.text_ticket_scann_count), checkTicketInfo.getCheckCount()));
            ticketTypeTv.setText(String.format(getString(R.string.text_ticket_type), checkTicketInfo.getTicketTypeName()));
            if(checkTicketInfo.isAbo()){
                ticketAboIdTv.setText(String.format(getString(R.string.text_ticket_abo_id), checkTicketInfo.getAda()));
                ticketKanJiNameTv.setText(String.format(getString(R.string.text_ticket_kanji_name), checkTicketInfo.getKanjiName()));
                if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 2 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 3 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 4) {
                    ticketAboInputTv.setText(String.format(getString(R.string.text_ticket_abo_input), checkTicketInfo.getAboInput()));
                }
            }
            ticketAboIdTv.setVisibility(checkTicketInfo.isAbo()?View.VISIBLE:View.GONE);
            ticketKanJiNameTv.setVisibility(checkTicketInfo.isAbo()?View.VISIBLE:View.GONE);
            ticketAboInputTv.setVisibility(checkTicketInfo.isAbo() && (SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 2 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 3 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 4) ? View.VISIBLE : View.GONE);

            if (checkTicketInfo.isAbo() && (SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 2 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 3 || SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) == 4)) {
                ViewGroup.LayoutParams params =  resultContainerRl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_242);

                params =  resultWattingLl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_210);

                params =  resultFailLl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_210);

                params =  resultSuccessLl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_210);

            } else {
                ViewGroup.LayoutParams params =  resultContainerRl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_210);

                params =  resultWattingLl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_178);

                params =  resultFailLl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_178);

                params =  resultSuccessLl.getLayoutParams();
                params.height = (int) getResources().getDimension(com.amway.e_ticket.R.dimen.dp_178);

            }

            switch (checkTicketInfo.getCheckCount()) {
                case 1:
                    playVoiceAndVibrate(ScannState.TICKTT_SUCCESS);
                    resultSuccesssImg.setImageResource(R.mipmap.icon_pass);
                    resultSuccessTv.setText(R.string.text_ticket_scann_state_pass);
                    resultSuccessTv.setTextColor(getResources().getColor(R.color.pass_green));
                    resultSuccessLl.setBackgroundResource(R.drawable.bg_pass_green);
                    break;
                default:
                    playVoiceAndVibrate(ScannState.TICKTT_REPEAT);
                    int repeatScan = SPUtils.getInstance().getInt(CommonStringUtil.REPEAT_SCAN_TAG, 0);
                    if (repeatScan != 0) {
                        if (!diaLogIsShow) {
                            TipsDialog dialog = new TipsDialog(getContext());
                            dialog.setListener(new TipsDialog.ExitClickListener() {
                                @Override
                                public void click(int state) {
                                    //隐藏按钮
                                    diaLogIsShow = false;
                                    timer.start();
                                }
                            });
                            dialog.show();
                            diaLogIsShow = true;
                        }
                    }
                    //不弹框提示重复扫描
                    resultSuccesssImg.setImageResource(R.mipmap.icon_error);
                    resultSuccessTv.setText(R.string.text_ticket_scann_state_error);
                    resultSuccessTv.setTextColor(getResources().getColor(R.color.repeat_scan_orange));
                    resultSuccessLl.setBackgroundResource(R.drawable.bg_repeat_scan_orange);
                    break;
            }

        }

    }
    //弹框是否正在显示
    boolean diaLogIsShow = false;

    /**
     * 手机是否静音
     * @return
     */
    private boolean isSilentMode() {
        AudioManager mAudioManager = (AudioManager)getActivity().getSystemService(Context.AUDIO_SERVICE);
        return mAudioManager.getRingerMode() != AudioManager.RINGER_MODE_NORMAL;
    }
    /**
     * 声音和震动
     */
    private MediaPlayer mediaPlayer;
    private void playVoiceAndVibrate(int state){
//        //系统提示音
//        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//        Ringtone r = RingtoneManager.getRingtone(MainTicketActivity.this, notification);
//        r.play();
        if(!isSilentMode()){
            try {
                String mediaName = "scan_success.ogg";
                switch (state){
                    case ScannState.TICKTT_REPEAT://重复扫描
                        mediaName = "scan_repeat.ogg";
                        break;
                    case ScannState.TICKTT_ERROR://扫描错误
                        mediaName = "scan_error.ogg";
                        break;
                    case ScannState.TICKTT_SUCCESS://扫描成功
                        mediaName = "scan_success.ogg";
                        break;
                }
                AssetFileDescriptor fd = getActivity().getAssets().openFd("notifications/"+mediaName);
                if(mediaPlayer == null){
                    mediaPlayer = new MediaPlayer();
                }
                mediaPlayer.reset();
                mediaPlayer.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
                mediaPlayer.prepare();
                mediaPlayer.start();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println(e.toString());
            }
        }
        Vibrator v = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) {
            // 设置手机振动的毫秒数
            v.vibrate(300);
        }
    }


    /**
     * 返回true时会自动初始化{@link #mRootView}，返回为false时需自己去通过{@link #setRootView(View)}初始化{@link #mRootView}
     * @param layoutId
     * @return 默认返回true
     */
    public boolean isContentView(@LayoutRes int layoutId){
        return true;
    }

    /**
     * 布局id
     * @return
     */
    public int getLayoutId(){
        return R.layout.fragment_ticket_scann;
    }

    /**
     * {@link ViewfinderView} 的 id
     * @return
     */
    public int getViewfinderViewId(){
        return com.king.zxing.R.id.viewfinderView;
    }


    /**
     * 预览界面{@link #surfaceView} 的id
     * @return
     */
    public int getSurfaceViewId(){
        return com.king.zxing.R.id.surfaceView;
    }

    /**
     * Get {@link CaptureHelper}
     * @return {@link #mCaptureHelper}
     */
    public CaptureHelper getCaptureHelper(){
        return mCaptureHelper;
    }

    /**
     * Get {@link CameraManager}
     * @return {@link #mCaptureHelper#getCameraManager()}
     */
    public CameraManager getCameraManager(){
        return mCaptureHelper.getCameraManager();
    }

    //--------------------------------------------

    public View getRootView() {
        return mRootView;
    }

    public void setRootView(View rootView) {
        this.mRootView = rootView;
    }


    //--------------------------------------------

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mCaptureHelper.onCreate();
    }

    @Override
    public void onResume() {
        super.onResume();
        mCaptureHelper.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mCaptureHelper.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mCaptureHelper != null){
            mCaptureHelper.onDestroy();
        }

    }

    public OnCaptureCustomCallback getCallBack() {
        return callBack;
    }

    public void setCallBack(OnCaptureCustomCallback callBack) {
        this.callBack = callBack;
    }

    /**
     * 接收扫码结果回调
     * @param result 扫码结果
     * @return 返回true表示拦截，将不自动执行后续逻辑，为false表示不拦截，默认不拦截
     */
    @Override
    public boolean onResultCallback(String result) {

        if (callBack != null) {
            callBack.onResultCallback(result);
            return true;
        }
        return false;
    }

    @Override
    public void onClick(View v) {
        callBack.onResultCallback("190809000001");
    }
}
