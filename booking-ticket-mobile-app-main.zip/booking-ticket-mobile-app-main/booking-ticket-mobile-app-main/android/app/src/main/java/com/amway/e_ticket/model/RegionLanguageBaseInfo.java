package com.amway.e_ticket.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 区域语言数据模型
 * Created by Tung Giim Horng - iss Malaysia on 2021/07/07.
 */
public class RegionLanguageBaseInfo implements Serializable {

    private int resultCode;
    private String resultMsg;
    private String errorCode;
    private String errorParams;

    private List<RegionLanguageModel> data = new ArrayList<RegionLanguageModel>();

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorParams() {
        return errorParams;
    }

    public void setErrorParams(String errorParams) {
        this.errorParams = errorParams;
    }

    public List<RegionLanguageModel> getData() {
        return data;
    }

    public void setData(List<RegionLanguageModel> language) {
        this.data = language;
    }

    /**
     *
     */
    public class RegionLanguageModel implements Serializable{
        private String applicationCode;
        private String langCode;
        private String langName;
        private int isDefault;//1 default language  0 non-default language

        public String getApplicationCode() {
            return applicationCode;
        }

        public void setApplicationCode(String applicationCode) {
            this.applicationCode = applicationCode;
        }

        public String getLangCode() {
            return langCode;
        }

        public void setLangCode(String langCode) {
            this.langCode = langCode;
        }

        public String getLangName() {
            return langName;
        }

        public void setLangName(String langName) {
            this.langName = langName;
        }

        public int getIsDefault() {
            return isDefault;
        }

        public void setIsDefault(int isDefault) {
            this.isDefault = isDefault;
        }

    }

}