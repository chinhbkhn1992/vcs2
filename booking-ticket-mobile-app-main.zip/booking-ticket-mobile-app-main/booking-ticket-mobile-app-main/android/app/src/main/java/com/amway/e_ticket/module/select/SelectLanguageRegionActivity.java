package com.amway.e_ticket.module.select;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amway.e_ticket.MainActivity;
import com.amway.e_ticket.MyApplication;
import com.amway.e_ticket.R;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.amway.e_ticket.utils.TinyDB;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ScreenUtils;
import com.isoft.frame.base.BaseActivity;
import com.isoft.frame.model.enums.ModalDirection;
import com.isoft.frame.utils.LanguageUtils;
import com.isoft.frame.widget.TipsDialog;
import com.jaeger.library.StatusBarUtil;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 区域 or 语言选择。
 *
 * @author Tung Giim Horng - iss Malaysia
 */
public class SelectLanguageRegionActivity extends BaseActivity implements OnItemSelectCallBack {

    @BindView(R.id.ivLeft)
    ImageView ivLeft;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivTitle)
    ImageView ivTitle;
    @BindView(R.id.ivRight)
    ImageView ivRight;
    @BindView(R.id.title_ll)
    LinearLayout titleLl;
    @BindView(R.id.top_view)
    View topView;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.area_ll)
    LinearLayout areaLl;
    @BindView(R.id.tv_area)
    TextView areaTv;

    @BindView(R.id.language_ll)
    LinearLayout languageLl;
    @BindView(R.id.tv_language)
    TextView languageTv;

    public static final String TAG = "FirstTimeActivity";
    private long mExitTime = 0L;

    boolean diaLogIsShow = false;

    public static void launch(BaseActivity activity) {
        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeCustomAnimation(activity, R.anim.hold, R.anim.zoom_in_exit);
        Intent intent = new Intent(activity, SelectLanguageRegionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        ActivityCompat.startActivity(activity, intent, optionsCompat.toBundle());
        //ActivityCompat.startActivity(activity, intent, null);
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.activity_language_region;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        //initToolBarView(titleLl, topView);
        ivLeft.setVisibility(View.INVISIBLE);
        tvTitle.setVisibility(View.GONE);
        ivTitle.setVisibility(View.VISIBLE);

        StatusBarUtil.setTranslucent(this, 0);
        StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary));
        tvTitle.setText(getText(R.string.text_language_area_title));
        initData();
    }

    /**
     * 设置显示值。
     */
    private void initData() {
        Resources res = getResources();
        String[] languagesList = res.getStringArray(R.array.languages_list);
        String[] areaList = res.getStringArray(R.array.area_list);

        //设置语言
        if(LanguageUtils.getLanguageType() == 4){
            languageTv.setText(languagesList[0]);
        }else{
            languageTv.setText(languagesList[LanguageUtils.getLanguageType()]);
        }

        //设置区域
        if(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 11){
            areaTv.setText("");
        }else{
            areaTv.setText(areaList[SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 0)]);
        }

    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    /*@Override
    protected void onResume() {
        super.onResume();
        //回来页面要重新设置显示已经选择的值
        initData();
    }*/

    @OnClick({R.id.ivLeft, R.id.area_ll, R.id.language_ll, R.id.select_btn})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivLeft:
                //点击返回按钮
                finish();
                break;
            case R.id.area_ll:
                //选择区域，暂不开启
                pushModalFragment(ModalDirection.BOTTOM, ScreenUtils.getScreenHeight() * 2 / 5,
                        SelectWheelFragment.newInstance(SelectWheelFragment.AREA_SELECT));
                break;
            case R.id.language_ll:
                //选择语言
                TinyDB tinydb = new TinyDB(getApplicationContext());
                ArrayList<String> regionArray = tinydb.getListString(CommonStringUtil.REGION_LIST_TAG);

                if (SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 11 || regionArray.size() == 0){
                    /*
                    final Context context = SelectLanguageRegionActivity.this;
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle(R.string.please_select_region_first);
                    //点击对话框以外的区域是否让对话框消失
                    builder.setCancelable(false);
                    //设置正面按钮
                    builder.setPositiveButton(R.string.text_confirm, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    AlertDialog dialog = builder.create();
                    //对话框显示的监听事件
                    dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                        @Override
                        public void onShow(DialogInterface dialog) {
                            Log.e(TAG,"Dialog Appear");
                        }
                    });
                    //对话框消失的监听事件
                    dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            Log.e(TAG,"Dialog Disappear");
                        }
                    });
                    //显示对话框
                    dialog.show();
                    */
                    if (!diaLogIsShow) {
                        final Context context = SelectLanguageRegionActivity.this;
                        TipsDialog dialog = new TipsDialog(context, 0);
                        dialog.setListener(new TipsDialog.ExitClickListener() {
                            @Override
                            public void click(int state) {
                                //隐藏按钮
                                diaLogIsShow = false;
                                timer.start();
                            }
                        });
                        dialog.show();
                        diaLogIsShow = true;
                    }
                }else{
                    pushModalFragment(ModalDirection.BOTTOM, ScreenUtils.getScreenHeight() * 2 / 5,
                            SelectWheelFragment.newInstance(SelectWheelFragment.LANGUAGE_SELECT));
                }

                break;
            case R.id.select_btn:
                //点击确定按钮
                //SPUtils.getInstance().getString(CommonStringUtil.FIRST_TIME_TAG, "") == ""
                Log.e(TAG, String.valueOf(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11)));

                if (SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11) == 11) {
                    //Toast.makeText(this, getText(R.string.please_select_region_and_language), Toast.LENGTH_LONG).show();
                    /*
                    final Context context = SelectLanguageRegionActivity.this;
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle(R.string.please_select_region_and_language);
                    //点击对话框以外的区域是否让对话框消失
                    builder.setCancelable(false);
                    //设置正面按钮
                    builder.setPositiveButton(R.string.text_confirm, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    AlertDialog dialog = builder.create();
                    //对话框显示的监听事件
                    dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                        @Override
                        public void onShow(DialogInterface dialog) {
                            Log.e(TAG,"Dialog Appear");
                        }
                    });
                    //对话框消失的监听事件
                    dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            Log.e(TAG,"Dialog Disappear");
                        }
                    });
                    //显示对话框
                    dialog.show();
                    */
                    if (!diaLogIsShow) {
                        final Context context = SelectLanguageRegionActivity.this;
                        TipsDialog dialog = new TipsDialog(context, 1);
                        dialog.setListener(new TipsDialog.ExitClickListener() {
                            @Override
                            public void click(int state) {
                                //隐藏按钮
                                diaLogIsShow = false;
                                timer.start();
                            }
                        });
                        dialog.show();
                        diaLogIsShow = true;
                    }
                }else{
                    TinyDB tinylocaldb = new TinyDB(getApplicationContext());
                    ArrayList<String> regionArrayList = tinylocaldb.getListString(CommonStringUtil.REGION_LIST_TAG);

                    if (regionArrayList.size() != 0) {
                        SPUtils.getInstance().put(CommonStringUtil.FIRST_TIME_TAG, "Y");
                        Intent mainIntent = new Intent(SelectLanguageRegionActivity.this, MainActivity.class);
                        SelectLanguageRegionActivity.this.startActivity(mainIntent);

                        ((MyApplication)this.getApplication())._initWebConfig();
                        finish();
                        overridePendingTransition(0, 0);
                    }else{
                        //Toast.makeText(this, getText(R.string.text_error_network), Toast.LENGTH_LONG).show();
                        /*
                        final Context context = SelectLanguageRegionActivity.this;
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle(R.string.text_error_network);
                        //点击对话框以外的区域是否让对话框消失
                        builder.setCancelable(false);
                        //设置正面按钮
                        builder.setPositiveButton(R.string.text_confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                        AlertDialog dialog = builder.create();
                        //对话框显示的监听事件
                        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                            @Override
                            public void onShow(DialogInterface dialog) {
                                Log.e(TAG,"Dialog Appear");
                            }
                        });
                        //对话框消失的监听事件
                        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialog) {
                                Log.e(TAG,"Dialog Disappear");
                            }
                        });
                        //显示对话框
                        dialog.show();
                        */
                        if (!diaLogIsShow) {
                            final Context context = SelectLanguageRegionActivity.this;
                            TipsDialog dialog = new TipsDialog(context, 2);
                            dialog.setListener(new TipsDialog.ExitClickListener() {
                                @Override
                                public void click(int state) {
                                    //隐藏按钮
                                    diaLogIsShow = false;
                                    timer.start();
                                }
                            });
                            dialog.show();
                            diaLogIsShow = true;
                        }
                    }

                }
                break;
        }
    }

    @Override
    public void OnItemSelect(int type, int selectedItemPosition) {
        //选择器
        initData();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //按下物理返回键
            //finish();
            //return true;

            if (System.currentTimeMillis() - mExitTime > 2000) {
                Toast.makeText(this, getText(R.string.text_exit_app), Toast.LENGTH_SHORT).show();
                mExitTime = System.currentTimeMillis();
                return true;
            } else {
                //finish();
                android.os.Process.killProcess(android.os.Process.myPid());
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    CountDownTimer timer = new CountDownTimer(3000, 1000) {
        public void onTick(long millisUntilFinished) {
//                txt.setText("倒计时" + millisUntilFinished / 1000 + "秒");
        }

        public void onFinish() {
//            if(getActivity().isFinishing())
//                return;
//            tipTv.setText(R.string.text_scann_watting);
//            scannTipLl.setBackgroundResource(R.drawable.bg_shap_gray1);
//            resultWattingLl.setVisibility(View.VISIBLE);
//            resultFailLl.setVisibility(View.GONE);
//            resultSuccessLl.setVisibility(View.GONE);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
