package com.amway.e_ticket.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 人员用户数据模型
 * Created by shaorulong on 2019/8/5.
 */
public class UserBaseInfo implements Serializable {

    private int resultCode;
    private int currentpage;
    private int totalPages;
    private String resultMsg;
    private String errorCode;
    private String errorParams;

    private List<UserModel> attendees = new ArrayList<UserModel>();

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public int getCurrentpage() {
        return currentpage;
    }

    public void setCurrentpage(int currentpage) {
        this.currentpage = currentpage;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorParams() {
        return errorParams;
    }

    public void setErrorParams(String errorParams) {
        this.errorParams = errorParams;
    }

    public List<UserModel> getAttendees() {
        return attendees;
    }

    public void setAttendees(List<UserModel> attendees) {
        this.attendees = attendees;
    }

    /**
     *
     */
    public class UserModel implements Serializable{
        private String ada;
        private String name;
        private String phone;
        private int checkinstatus;//1 已验  0 未验
        private String checkinTime;
        private String checkTime;
        private boolean isAbo;

        public String getCheckTime() {
            return checkTime;
        }

        public void setCheckTime(String checkTime) {
            this.checkTime = checkTime;
        }

        public boolean isAbo() {
            return isAbo;
        }

        public void setAbo(boolean abo) {
            isAbo = abo;
        }

        public String getAda() {
            return ada;
        }

        public void setAda(String ada) {
            this.ada = ada;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public int getCheckinstatus() {
            return checkinstatus;
        }

        public void setCheckinstatus(int checkinstatus) {
            this.checkinstatus = checkinstatus;
        }

        public String getCheckinTime() {
            return checkinTime;
        }

        public void setCheckinTime(String checkinTime) {
            this.checkinTime = checkinTime;
        }
    }

}
