package com.amway.e_ticket.module.select;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.amway.e_ticket.MyApplication;
import com.amway.e_ticket.R;
import com.amway.e_ticket.model.AreaInfo;
import com.amway.e_ticket.model.LanguageInfo;
import com.amway.e_ticket.utils.CommonStringUtil;
import com.amway.e_ticket.utils.TinyDB;
import com.blankj.utilcode.util.SPUtils;
import com.isoft.frame.base.AppConstants;
import com.isoft.frame.base.BaseFragment;
import com.isoft.frame.utils.AssetsHelper;
import com.isoft.frame.utils.GsonHelper;
import com.isoft.frame.utils.LanguageUtils;
import com.zyyoona7.wheel.WheelView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * 选择区域与语言界面,根据selectType进行区分.
 * @author rlshao
 */
public class SelectWheelFragment extends BaseFragment {
    //区域选择
    public static final int AREA_SELECT = 0;
    //语言选择
    public static final int LANGUAGE_SELECT = 1;
    //重复扫描选择
    public static final int SCAN_SELECT = 2;


    public static final String TAG = "SelectWheelFragment";

    private final static String SELECE_TYPE = "selece_type";
    @BindView(R.id.fragment_wheel_dialog_cancel)
    TextView fragmentWheelDialogCancel;
    @BindView(R.id.fragment_select_wheel_title)
    TextView fragmentSelectWheelTitle;
    @BindView(R.id.fragment_select_wheel_close)
    ImageView fragmentSelectWheelClose;
    @BindView(R.id.fragment_wheel_dialog_top)
    RelativeLayout fragmentWheelDialogTop;
    @BindView(R.id.wheelView)
    WheelView wheelView;
    @BindView(R.id.select_btn)
    Button selectBtn;
    //选择语言还是选择区域，0：语言，1区域 2:重复扫描
    private int selectType;
    //所有区域数据，当selectType = 0时候有值
    private List<AreaInfo> sAllAreaInfos;
    //所有语言数据，当selectType = 1时候有值
    private List<LanguageInfo> sAllLanguageInfos;
    /**
     * 选择回调器。
     */
    private OnItemSelectCallBack mOnItemSelectCallBack;

    ArrayList<String> regionList = new ArrayList<String>();
    ArrayList<String> languageList = new ArrayList<String>();

    /**
     * @param type 0区域，1语言
     * @return
     */
    public static SelectWheelFragment newInstance(int type) {
        Bundle args = new Bundle();
        args.putInt(SELECE_TYPE, type);
        SelectWheelFragment fragment = new SelectWheelFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity != null) {
            mOnItemSelectCallBack = (OnItemSelectCallBack) activity;
        }
    }

    @Override
    protected int attachLayoutRes() {
        return R.layout.fragment_select_wheel;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {
        TinyDB tinydb = new TinyDB(activity.getApplicationContext());
        ArrayList<String> regionArray = tinydb.getListString(CommonStringUtil.REGION_LIST_TAG);
        ArrayList<String> applicationInfoRegionArray = tinydb.getListString(CommonStringUtil.APPLICATION_INFO_REGION_LIST_TAG);
        ArrayList<String> regionNameArray = tinydb.getListString(CommonStringUtil.REGION_NAME_LIST_TAG);

        //需要选择语言还是选择区域
        selectType = getArguments().getInt(SELECE_TYPE);
        //缓存选中的第几条数据
        int selectedItemPosition = 0;
        if (selectType == AREA_SELECT) {
            //选择的是区域
            fragmentSelectWheelTitle.setText(getText(R.string.text_select_area_title));
            //sAllAreaInfos = GsonHelper.convertEntities(AssetsHelper.readData(getActivity(), "AreaData"), AreaInfo.class);

            regionList.clear();
            //regionList.add("Japan");
            //regionList.add("Việt Nam");
            //regionList.add("Malaysia");
            //regionList.add("Singapore");
            //regionList.add("Brunei");

            if (regionArray.contains("JP") && applicationInfoRegionArray.contains("JP")){
                regionList.add(regionNameArray.get(applicationInfoRegionArray.indexOf("JP")));
            }
            if (regionArray.contains("VN") && applicationInfoRegionArray.contains("VN")){
                regionList.add(regionNameArray.get(applicationInfoRegionArray.indexOf("VN")));
            }
            if (regionArray.contains("MY") && applicationInfoRegionArray.contains("MY")){
                regionList.add(regionNameArray.get(applicationInfoRegionArray.indexOf("MY")));
            }
            if (regionArray.contains("SG") && applicationInfoRegionArray.contains("SG")){
                regionList.add(regionNameArray.get(applicationInfoRegionArray.indexOf("SG")));
            }
            if (regionArray.contains("BN") && applicationInfoRegionArray.contains("BN")){
                regionList.add(regionNameArray.get(applicationInfoRegionArray.indexOf("BN")));
            }
            if (regionArray.contains("IN") && applicationInfoRegionArray.contains("IN")){
                regionList.add(regionNameArray.get(applicationInfoRegionArray.indexOf("IN")));
            }

            //设置数据
            //wheelView.setData(sAllAreaInfos);
            wheelView.setData(regionList);
//            wheelView.setVisibleItems(sAllAreaInfos.size());

            //缓存的区域选项
            //selectedItemPosition = SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 0);
            switch(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 0)) {
                case 0:
                    selectedItemPosition = regionList.indexOf(regionNameArray.get(applicationInfoRegionArray.indexOf("JP")));
                    break;
                case 1:
                    selectedItemPosition = regionList.indexOf(regionNameArray.get(applicationInfoRegionArray.indexOf("VN")));
                    break;
                case 2:
                    selectedItemPosition = regionList.indexOf(regionNameArray.get(applicationInfoRegionArray.indexOf("MY")));
                    break;
                case 3:
                    selectedItemPosition = regionList.indexOf(regionNameArray.get(applicationInfoRegionArray.indexOf("SG")));
                    break;
                case 4:
                    selectedItemPosition = regionList.indexOf(regionNameArray.get(applicationInfoRegionArray.indexOf("BN")));
                    break;
                case 5:
                    selectedItemPosition = regionList.indexOf(regionNameArray.get(applicationInfoRegionArray.indexOf("IN")));
                    break;
                default:
                    selectedItemPosition = 0;
                    break;
            }
        } else if(selectType == LANGUAGE_SELECT){
            //选择的是语言
            fragmentSelectWheelTitle.setText(getText(R.string.text_select_language_title));
            //sAllLanguageInfos = GsonHelper.convertEntities(AssetsHelper.readData(getActivity(), "AreaAndLanguageData"), LanguageInfo.class);


            languageList.clear();
            ArrayList<String> langArray = new ArrayList<String>();
            switch(SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11)){
                case 0:
                    //ArrayList<Integer> isDefaultArray = tinydb.getListInt(CommonStringUtil.JAPAN_DEFAULT_CODE_LIST_TAG);
                    langArray = tinydb.getListString(CommonStringUtil.JAPAN_LANG_LIST_TAG);
                    //int postition = isDefaultArray.indexOf(1);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    break;
                case 1:
                    langArray = tinydb.getListString(CommonStringUtil.VIETNAM_LANG_LIST_TAG);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    break;
                case 2:
                    langArray = tinydb.getListString(CommonStringUtil.MALAYSIA_LANG_LIST_TAG);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    break;
                case 3:
                    langArray = tinydb.getListString(CommonStringUtil.SINGAPORE_LANG_LIST_TAG);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    break;
                case 4:
                    langArray = tinydb.getListString(CommonStringUtil.BRUNEI_LANG_LIST_TAG);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    break;
                case 5:
                    langArray = tinydb.getListString(CommonStringUtil.INDIA_LANG_LIST_TAG);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    break;
                default:
                    langArray = tinydb.getListString(CommonStringUtil.OTHERS_LANG_LIST_TAG);

                    if(langArray.contains("JP")){
                        languageList.add("日本語");
                    }
                    if(langArray.contains("EN")){
                        languageList.add("English");
                    }
                    if(langArray.contains("VN")){
                        languageList.add("Tiếng Việt");
                    }
                    if(langArray.contains("CN")){
                        languageList.add("简体中文");
                    }
                    if(langArray.contains("IN")){
                        languageList.add("தமிழ்");
                    }

                    if(languageList.size() == 0){
                        languageList.add("English");
                    }

                    break;
            }

            //设置数据
            //wheelView.setData(sAllLanguageInfos);
            wheelView.setData(languageList);
//            wheelView.setVisibleItems(sAllLanguageInfos.size());

            //缓存的语言选项
            //if(LanguageUtils.getLanguageType() == 4){
            //    selectedItemPosition = 0;
            //}else{
            //    selectedItemPosition = LanguageUtils.getLanguageType();
            //}

            int selectedItem = 0;
            switch(LanguageUtils.getLanguageType()){
                case 0:
                    selectedItem = languageList.indexOf("English");
                    selectedItemPosition = selectedItem;
                    break;
                case 1:
                    selectedItem = languageList.indexOf("简体中文");
                    selectedItemPosition = selectedItem;
                    break;
                case 2:
                    selectedItem = languageList.indexOf("日本語");
                    selectedItemPosition = selectedItem;
                    break;
                case 3:
                    selectedItem = languageList.indexOf("Tiếng Việt");
                    selectedItemPosition = selectedItem;
                    break;
                case 4:
                    selectedItem = languageList.indexOf("English");
                    selectedItemPosition = selectedItem;
                    break;
                case 5:
                    selectedItem = languageList.indexOf("தமிழ்");
                    selectedItemPosition = selectedItem;
                    break;
                default:
                    selectedItemPosition = 0;
                    break;
            }
        } else {
            //选择的是重复扫描
            fragmentSelectWheelTitle.setText(getText(R.string.text_select_repeat_scan));
            List<String> scanList = new ArrayList<>();
            scanList.add(getString(R.string.text_yes));
            scanList.add(getString(R.string.text_no));
            wheelView.setData(scanList);
//            wheelView.setVisibleItems(scanList.size());
            //缓存的选项
            selectedItemPosition = SPUtils.getInstance().getInt(CommonStringUtil.REPEAT_SCAN_TAG, 0);

        }
        //设置当前选中下标
        wheelView.setSelectedItemPosition(selectedItemPosition);
        //设置字体大小
        wheelView.setTextSize(19f,true);

        if (regionArray.size() == 0) {
            wheelView.setEnabled(false);
        }else{
            wheelView.setEnabled(true);
        }
    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    /**
     * 设置语言。
     * @param type 0繁体中文，1简体中文
     */
    private void toSetLanguage(int type) {
        boolean sameLanguage = LanguageUtils.isSameLanguage(getActivity(), type);
        if (!sameLanguage) {
            LanguageUtils.setLocale(getActivity(), type);
            // 前面取系统语言时判断spType=0时取第一值，所以设置完语言后缓存type
            LanguageUtils.putLanguageType(type);
            LanguageUtils.toRestartMainActvity(getActivity());
        } else {
            // 缓存用户此次选择的类型，可能出现type不同而locale一样的情况（如：系统默认泰语type = 0，而我选择的也是泰语type = 3）
            LanguageUtils.putLanguageType(type);
        }
    }

    @OnClick({R.id.select_btn})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.select_btn:
                //点击确定按钮
                int selectedItemPosition = wheelView.getSelectedItemPosition();
                int selectedItemComparePosition = 0;
                Log.w(TAG, "selectedItemPosition-->" + selectedItemPosition);
                String selectItemName = "";
                if (selectType == AREA_SELECT) {
                    //选择区域数据完毕
//                    AreaInfo areaInfo = sAllAreaInfos.get(selectedItemPosition);
                    //获取上次缓存的区域数据，

                    TinyDB tinydb = new TinyDB(activity.getApplicationContext());
                    ArrayList<String> regionArray = tinydb.getListString(CommonStringUtil.REGION_LIST_TAG);
                    ArrayList<String> applicationInfoRegionArray = tinydb.getListString(CommonStringUtil.APPLICATION_INFO_REGION_LIST_TAG);
                    ArrayList<String> regionNameArray = tinydb.getListString(CommonStringUtil.REGION_NAME_LIST_TAG);

                    switch (applicationInfoRegionArray.get(regionNameArray.indexOf(regionList.get(selectedItemPosition)))){
                        case "JP":
                            selectedItemComparePosition = 0;
                            break;
                        case "VN":
                            selectedItemComparePosition = 1;
                            break;
                        case "MY":
                            selectedItemComparePosition = 2;
                            break;
                        case "SG":
                            selectedItemComparePosition = 3;
                            break;
                        case "BN":
                            selectedItemComparePosition = 4;
                            break;
                        case "IN":
                            selectedItemComparePosition = 5;
                            break;
                        default:
                            System.out.println("TUNG 888");
                            selectedItemComparePosition = 3;
                            break;
                    }

                    int savePosition = SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG, 11);
                    if (savePosition != selectedItemComparePosition && regionArray.size() != 0) {
                        //区域有发生变化时候，才做对应的切换和缓存动作
                        //selectItemName = regionList.get(selectedItemPosition);
                        switch(selectedItemComparePosition){
                            case 0:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 0);
                                toSetLanguage(2);
                                break;
                            case 1:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 1);
                                toSetLanguage(3);
                                break;
                            case 2:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 2);
                                toSetLanguage(4);
                                break;
                            case 3:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 3);
                                toSetLanguage(4);
                                break;
                            case 4:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 4);
                                toSetLanguage(4);
                                break;
                            case 5:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 5);
                                toSetLanguage(4);
                                break;
                            default:
                                SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, 10);
                                toSetLanguage(4);
                                break;
                        }

                        //SPUtils.getInstance().put(CommonStringUtil.LOCALE_AREA_TAG, selectedItemPosition);
                        ((MyApplication)getActivity().getApplication())._initWebConfig();

                    }

                } else if(selectType == LANGUAGE_SELECT){
                    //选择语言数据完毕
//                    LanguageInfo languageInfo = sAllLanguageInfos.get(selectedItemPosition);
                    //toSetLanguage(selectedItemPosition);

                    switch (languageList.get(selectedItemPosition)){
                        case "English":
                            toSetLanguage(4);
                            break;
                        case "简体中文":
                            toSetLanguage(1);
                            break;
                        case "日本語":
                            toSetLanguage(2);
                            break;
                        case "Tiếng Việt":
                            toSetLanguage(3);
                            break;
                        case "தமிழ்":
                            toSetLanguage(5);
                            break;
                        default:
                            toSetLanguage(4);
                            break;
                    }
                } else {
                    //选择重复扫描数据完毕
                    //获取上次缓存的数据，
                    int savePosition = SPUtils.getInstance().getInt(CommonStringUtil.REPEAT_SCAN_TAG, 0);
                    if (savePosition != selectedItemPosition) {
                        //有发生变化时候，才做对应的切换和缓存动作
                        SPUtils.getInstance().put(CommonStringUtil.REPEAT_SCAN_TAG, selectedItemPosition);
                    }
                }
                //回调方法
                if (mOnItemSelectCallBack != null) {
                    mOnItemSelectCallBack.OnItemSelect(selectType, selectedItemPosition);
                }
                //关闭当前框
                popModalFragment();
                break;
        }
    }

}
