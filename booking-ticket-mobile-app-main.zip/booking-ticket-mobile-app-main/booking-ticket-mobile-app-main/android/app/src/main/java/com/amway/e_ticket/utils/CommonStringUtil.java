package com.amway.e_ticket.utils;


@SuppressWarnings("ALL")
public class CommonStringUtil {

    /**************************************** 通用 int begin *****************************/
    //接口状态码,成功
    public static final int CODE_RESPONSE_SUCCESS = 1;
    //接口状态码,失败
    public static final int CODE_RESPONSE_FAIL = 0;

    //没有特殊含义的请求码，常用于startActivityForResult的回调
    public static final int REQUEST_CODE_COMMON = 666;
    //请求选图片
    public static final int REQUEST_CODE_TAKE_PIC = 10001;
    public static final int REQUEST_CODE_TAKE_PHOTO = 10002;

    /*//下载相关意图tag
    public static final String DOWNLOAD_URL_TAG = "url";
    public static final String DOWNLOAD_PATH_TAG = "downloadPath";
    public static final String DOWNLOAD_STATE_TAG = "downloadState";
    public static final String DOWNLOAD_PROGRESS_TAG = "progress";
    public static final String DOWNLOAD_FILEPATH_TAG = "filePath";*/


    //10测试机地址
//    public static final String DEBUG_BASE_URL = "http://10.210.144.12:8090/TicketApi/";
    //请求基础host
    /*public static final String DEBUG_BASE_URL = "http://172.80.0.182:8082/";
    public static final String DEBUG_BASE_IMAGE_URL = "http://172.80.0.100:8082";
    public static final String BASE_URL = "http://172.80.0.182:8082/";
    public static final String BASE_IMAGE_URL = "http://172.80.0.100:8082";

    public static final String CHANGE_IMAGE_PATH = "/wholesmart/cache/img/";*/

    /******************************************* 通用 string end ***************************************/

    /*用户选择的区域*/
    public static final String LOCALE_AREA_TAG = "locale_area_tag";

    /*用户选择的是否重复扫描*/
    public static final String REPEAT_SCAN_TAG = "repeat_scan_tag";

    /*首次登录Flag*/
    public static final String FIRST_TIME_TAG = "first_time_tag";

    /*CheckFlag*/
    public static final String CHECKED_CHANGED_TAG = "checked_changed_tag";

    /*DoubleTriggerAPIFlag*/
    public static final String MIN_API_DELAY_TAG = "min_api_delay_tag";

    /*languageListFlag*/
    public static final String VIETNAM_LANG_LIST_TAG = "vietnam_key";
    public static final String JAPAN_LANG_LIST_TAG = "japan_key";
    public static final String BRUNEI_LANG_LIST_TAG = "brunei_key";
    public static final String SINGAPORE_LANG_LIST_TAG = "singapore_key";
    public static final String MALAYSIA_LANG_LIST_TAG = "malaysia_key";
    public static final String INDIA_LANG_LIST_TAG = "india_key";
    public static final String OTHERS_LANG_LIST_TAG = "others_key";
    public static final String VIETNAM_DEFAULT_CODE_LIST_TAG = "vietnam_default_code_key";
    public static final String JAPAN_DEFAULT_CODE_LIST_TAG = "japan_default_code_key";
    public static final String BRUNEI_DEFAULT_CODE_LIST_TAG = "brunei_default_code_key";
    public static final String SINGAPORE_DEFAULT_CODE_LIST_TAG = "singapore_default_code_key";
    public static final String MALAYSIA_DEFAULT_CODE_LIST_TAG = "malaysia_default_code_key";
    public static final String INDIA_DEFAULT_CODE_LIST_TAG = "india_default_code_key";
    public static final String OTHERS_DEFAULT_CODE_LIST_TAG = "others_default_code_key";
    public static final String REGION_LIST_TAG = "region_key";

    public static final String APPLICATION_INFO_REGION_LIST_TAG = "application_info_region_key";
    public static final String REGION_NAME_LIST_TAG = "region_name_key";
}
