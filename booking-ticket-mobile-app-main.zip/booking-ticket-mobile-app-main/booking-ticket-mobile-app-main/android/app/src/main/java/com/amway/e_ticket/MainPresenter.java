package com.amway.e_ticket;

import android.content.Context;
import android.util.Log;

import com.amway.e_ticket.api.TicketApi;
import com.amway.e_ticket.model.EventDetailInfo;
import com.amway.e_ticket.model.UrlModule;
import com.amway.e_ticket.utils.UserAgentUtil;
import com.blankj.utilcode.util.StringUtils;
import com.google.gson.Gson;
import com.isoft.frame.base.IBasePresenter;
import com.isoft.frame.base.ILoadDataView;
import com.isoft.frame.network.http.MyErrcodeEnum;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.MediaType;


/**
 * Created by shaorulong on 2018/8/28.
 * 首页 Presenter
 */
public class MainPresenter implements IBasePresenter {

    private ILoadDataView mView;
//    private TicketService mTicketService;
    private String TAG = "MainPresenter";

    public MainPresenter(ILoadDataView view) {
        this.mView = view;
//        mTicketService = new TicketService();
    }

    /**
     * 获取活动详情
     */
    public void getEventDetail(Context context, String regionCode, String eventID) {
        Map<String, String> parammMap = new HashMap<>();
        parammMap.put("regionCode", regionCode);
        parammMap.put("eventID", eventID);

        String url = UrlModule.getInstance().url + TicketApi.CHECKIN_EVENT_DETAIL_URL;
        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(parammMap))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .addHeader("User-Agent", UserAgentUtil.getUserAgent(context))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        String code = MyErrcodeEnum.FAIL.getVal().toString();
                        Log.w(TAG, "失败，Code：" + code);
                        mView.loadData(null);
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        String code = MyErrcodeEnum.SUCCESS.getVal().toString();
                        if (!StringUtils.isEmpty(response)) {
                            Log.w(TAG, response);
                            //成功
                            EventDetailInfo eventDetailInfo = new Gson().fromJson(response, EventDetailInfo.class);
                            /*LoginHttpResult<EventDetailInfo> loginInfo = new Gson().fromJson(response,
                                    new TypeToken<EventDetailInfo>() {
                                    }.getType());*/
                            if (code.equals(eventDetailInfo.getResultCode() + "")) {
                                //成功
                                mView.loadData(eventDetailInfo);
                            } else {
                                //业务失败鸟
                                mView.loadData(null);
                            }

                        } else {
                            mView.loadData(null);
                        }
                    }
                });
    }
    /*public void getEventDetail(String regionCode, String eventID) {

        mTicketService.checkinEventDetail(regionCode, eventID)
            .compose(TransformUtils.<HttpResult<String>>defaultSchedulers())
            .subscribe(new HttpResultSubscriber<String>() {
                @Override
                public void onSuccess(String eventDetail) {
                    mView.loadData(eventDetail);
                }

                @Override
                public void _onError(int status, String msg) {
                    mView.loadNoData();
                }
            });

    }*/

    /**
     * 获取网络数据，更新界面
     *
     * @param isRefresh 新增参数，用来判断是否为下拉刷新调用，下拉刷新的时候不应该再显示加载界面和异常界面
     */
    @Override
    public void getData(boolean isRefresh) {

    }

    /**
     * 加载更多数据
     */
    @Override
    public void getMoreData() {

    }
}
