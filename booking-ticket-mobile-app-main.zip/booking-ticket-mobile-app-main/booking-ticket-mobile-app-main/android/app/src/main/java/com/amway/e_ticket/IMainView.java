package com.amway.e_ticket;


import com.amway.e_ticket.model.EventDetailInfo;
import com.isoft.frame.base.ILoadDataView;

public interface IMainView extends ILoadDataView<EventDetailInfo> {

    /**
     * 加载车源数据
     */
    void upLoadVideoView(String data);


}
