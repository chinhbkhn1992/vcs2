package com.amway.e_ticket.api.service;


import com.amway.e_ticket.api.TicketApi;
import com.amway.e_ticket.api.UserApi;
import com.amway.e_ticket.model.UserInfo;
import com.isoft.frame.network.http.HttpResult;
import com.isoft.frame.network.service.RetrofitService;

import java.util.HashMap;
import java.util.Map;

import rx.Observable;

/**
 * Ticket相关Service。
 */
public class TicketService {

    public TicketService() {

    }

    /**
     *
     * 获取活动详情
     * @param regionCode 区域码
     * @param eventID 活动id
     * @return
     */
    public Observable<HttpResult<String>> checkinEventDetail(String regionCode, String eventID) {
        Map<String, String> map = new HashMap<>();
        map.put("regionCode", regionCode);
        map.put("eventID", eventID);
        return RetrofitService.obtainRetrofitService(TicketApi.class).checkinEventDetail(map);
    }



}
