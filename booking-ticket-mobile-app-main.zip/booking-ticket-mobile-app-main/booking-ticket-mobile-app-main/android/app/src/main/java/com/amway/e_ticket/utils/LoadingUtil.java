package com.amway.e_ticket.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import com.amway.e_ticket.R;

public class LoadingUtil {
    private static LoadingDialog loadingDialog;
    public static void showLoading(Activity activity){
        if(loadingDialog == null){
            loadingDialog = new LoadingDialog(activity);
        }
        if(loadingDialog.isShowing())
            return;
        loadingDialog.show();
    }
    public static void hideLoading(){
        if(loadingDialog != null && loadingDialog.isShowing()){
            loadingDialog.dismiss();
        }
    }
    public  static class LoadingDialog extends Dialog{

        public LoadingDialog(@NonNull Context context) {
            super(context,R.style.loading);
            initView(context);
        }

        private View dialogView;
        private ImageView myImageView;
        private Animation myAlphaAnimation;
        private void initView(Context context){
            dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_loading, null);
            myImageView =  dialogView.findViewById(R.id.img_loading);
            myAlphaAnimation= AnimationUtils.loadAnimation(context, R.anim.loading);
            myAlphaAnimation.setInterpolator(new LinearInterpolator());
            myImageView.startAnimation(myAlphaAnimation);
            setCanceledOnTouchOutside(false);
        }

        @Override
        public void show() {
            Window window = this.getWindow();
            window.setGravity(Gravity.CENTER);
            window.setBackgroundDrawableResource(R.mipmap.app_transparency_icon);
            this.setContentView(dialogView);

            //No parent, so temporary comment this line
            //super.show();
        }
    }
}
