package com.amway.e_ticket.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 区域数据模型
 * Created by Tung Giim Horng - iss Malaysia on 2021/07/07.
 */
public class RegionBaseInfo implements Serializable {

    private int resultCode;
    private String resultMsg;
    private String errorCode;
    private String errorParams;

    private List<RegionModel> data = new ArrayList<RegionModel>();

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorParams() {
        return errorParams;
    }

    public void setErrorParams(String errorParams) {
        this.errorParams = errorParams;
    }

    public List<RegionModel> getData() {
        return data;
    }

    public void setData(List<RegionModel> region) {
        this.data = region;
    }

    /**
     *
     */
    public class RegionModel implements Serializable{
        private int isWorkflow;         //1 active region  0 inactive region
        private String applicationCode;
        private String applicationNameEn;
        private String aboSiteUrl;

        public String getApplicationCode() {
            return applicationCode;
        }

        public void setApplicationCode(String applicationCode) {
            this.applicationCode = applicationCode;
        }

        public String getApplicationNameEn() {
            return applicationNameEn;
        }

        public void setApplicationNameEn(String applicationNameEn) {
            this.applicationNameEn = applicationNameEn;
        }

        public String getAboSiteUrl() {
            return aboSiteUrl;
        }

        public void setAboSiteUrl(String aboSiteUrl) {
            this.aboSiteUrl = aboSiteUrl;
        }

        public int getIsWorkflow() {
            return isWorkflow;
        }

        public void setIsWorkflow(int isWorkflow) {
            this.isWorkflow = isWorkflow;
        }

    }

}