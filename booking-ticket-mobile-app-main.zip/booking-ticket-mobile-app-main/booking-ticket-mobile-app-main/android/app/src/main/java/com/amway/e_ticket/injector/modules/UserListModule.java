package com.amway.e_ticket.injector.modules;

import com.amway.e_ticket.adapter.UserListAdapter;
import com.amway.e_ticket.module.ticket.TicketUserFragment;
import com.amway.e_ticket.module.ticket.TicketUserPresenter;
import com.dl7.recycler.adapter.BaseQuickAdapter;
import com.isoft.frame.base.IBasePresenter;
import com.isoft.frame.injector.PerFragment;

import dagger.Module;
import dagger.Provides;

/**
 * Created by shaorulong on 2018/6/14.
 * 管理
 */
@Module
public class UserListModule {

    private TicketUserFragment mView;
    private String eventID;

    public UserListModule(TicketUserFragment view, String eventID) {
        this.mView = view;
        this.eventID = eventID;
    }

    @PerFragment
    @Provides
    public TicketUserPresenter provideManagePresenter() {
        return new TicketUserPresenter(mView.getActivity(), mView, eventID);
    }

    @PerFragment
    @Provides
    public BaseQuickAdapter provideAdapter() {
        return new UserListAdapter(mView.getActivity());
    }


}
