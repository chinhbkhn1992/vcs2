package com.amway.e_ticket.utils;

import android.content.Context;

import com.isoft.frame.utils.SystemUtil;
import com.orhanobut.logger.Logger;

/**
 * UserAgent 工具类
 * https://blog.csdn.net/zheng_weichao/article/details/79242125.
 */
public class UserAgentUtil {

    /**
     * 自定义UserAgent
     * @param context
     * @return
     */
    public static String getUserAgent(Context context) {
        String userAgent = "";
//        APP版本
        String versionName = SystemUtil.getVersionName(context);
//        手机型号
        String systemModel = SystemUtil.getSystemModel();
//        系统版本
        String systemVersion = SystemUtil.getSystemVersion();
        String deviceBrand = SystemUtil.getDeviceBrand();
        userAgent = "Android/" + versionName + "/" + deviceBrand + "" + systemModel + "/" + systemVersion;
        Logger.d("UserAgent-->" + userAgent, "");
        return userAgent;
    }
}
