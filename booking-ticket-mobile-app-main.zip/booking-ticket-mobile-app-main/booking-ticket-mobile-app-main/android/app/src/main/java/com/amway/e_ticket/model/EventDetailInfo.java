package com.amway.e_ticket.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.amway.e_ticket.utils.CommonStringUtil;
import com.blankj.utilcode.util.SPUtils;
import com.isoft.frame.utils.TimeUtils;

/**
 * 人员用户数据模型
 * Created by shaorulong on 2019/8/5.
 */
public class EventDetailInfo implements Parcelable {

    private String eventID;
    private String eventName;
    private String eventCode;
    private String startTime;
    private String endTime;
    private String eventAddress;
    //负责人
    private String applicant;
    private String ticketsTotal;
    private String checkinTotal;
    private String uncheckinTotal;
    private String checkinRate;
    private int resultCode;
    private String resultMsg;
    private String errorCode;
    private String errorParams;

    private String contactInfo;
    private String date;
    private String timeslot;
    private String venue;
    private String eventLongName;
    private String registered;


    /**
     * author colin
     * remark 2020-07-02 修改字段
     */

    private String eventVenueName;
    private String eventEndTime;
    private String eventStartTime;//activity Data显示 eventStartTime-eventEndTime

    private String language;

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    private String sessionDate;//Sessine Data显示 sessionDate
    private String sessionEndTimeSlot;
    private String sessionStartTimeSlot;//activity Sessine TimeSlot sessionStartTimeSlot-sessionEndTimeSlot
    private String sessionCityName;
    private String sessionDistrictName;
    private String sessionProvinceName;
    private String sessionVenue;
    private String sessionVenueAddr;
    private String sessionVenueName;

    public String getDateValue(){
        if(!TextUtils.isEmpty(eventID)){
            if(eventID.contains("-") && SPUtils.getInstance().getInt(CommonStringUtil.LOCALE_AREA_TAG) != 5){
                //return sessionDate;
                return TimeUtils.GetZoneTime(sessionDate,"yyyy-MM-dd'T'HH:mm:ss","dd/MM/yyyy");
            }
            return TimeUtils.GetZoneTime(eventStartTime,"yyyy-MM-dd'T'HH:mm:ss","dd/MM/yyyy")+" - "+TimeUtils.GetZoneTime(eventEndTime,"yyyy-MM-dd'T'HH:mm:ss","dd/MM/yyyy");
        }
        return "";
    }
    public String getTimeslotValue(){
        return TimeUtils.GetZoneTime(sessionStartTimeSlot,"yyyy-MM-dd'T'HH:mm:ss","HH:mm")+" - "+ TimeUtils.GetZoneTime(sessionEndTimeSlot,"yyyy-MM-dd'T'HH:mm:ss","HH:mm");
    }

    public String getAddressValue(){
        String address = (TextUtils.isEmpty(sessionVenueAddr)?"":sessionVenueAddr+",")+
                (TextUtils.isEmpty(sessionDistrictName)?"":sessionDistrictName+",")+
                (TextUtils.isEmpty(sessionCityName)?"":sessionCityName+",")+
                sessionProvinceName;
        address = address.endsWith(",")?address.substring(0,address.length()-1):address;
        if(TextUtils.isEmpty(address) || "null".endsWith(address)){
            address = eventAddress;
        }
        return address;
    }


    public String getEventVenueName() {
        return eventVenueName;
    }

    public void setEventVenueName(String eventVenueName) {
        this.eventVenueName = eventVenueName;
    }

    public String getEventEndTime() {
        return eventEndTime;
    }

    public void setEventEndTime(String eventEndTime) {
        this.eventEndTime = eventEndTime;
    }

    public String getEventStartTime() {
        return eventStartTime;
    }

    public void setEventStartTime(String eventStartTime) {
        this.eventStartTime = eventStartTime;
    }

    public String getSessionDate() {
        return sessionDate;
    }

    public void setSessionDate(String sessionDate) {
        this.sessionDate = sessionDate;
    }

    public String getSessionEndTimeSlot() {
        return sessionEndTimeSlot;
    }

    public void setSessionEndTimeSlot(String sessionEndTimeSlot) {
        this.sessionEndTimeSlot = sessionEndTimeSlot;
    }

    public String getSessionStartTimeSlot() {
        return sessionStartTimeSlot;
    }

    public void setSessionStartTimeSlot(String sessionStartTimeSlot) {
        this.sessionStartTimeSlot = sessionStartTimeSlot;
    }

    public String getSessionCityName() {
        return sessionCityName;
    }

    public void setSessionCityName(String sessionCityName) {
        this.sessionCityName = sessionCityName;
    }

    public String getSessionDistrictName() {
        return sessionDistrictName;
    }

    public void setSessionDistrictName(String sessionDistrictName) {
        this.sessionDistrictName = sessionDistrictName;
    }

    public String getSessionProvinceName() {
        return sessionProvinceName;
    }

    public void setSessionProvinceName(String sessionProvinceName) {
        this.sessionProvinceName = sessionProvinceName;
    }

    public String getSessionVenue() {
        return sessionVenue;
    }

    public void setSessionVenue(String sessionVenue) {
        this.sessionVenue = sessionVenue;
    }

    public String getSessionVenueAddr() {
        return sessionVenueAddr;
    }

    public void setSessionVenueAddr(String sessionVenueAddr) {
        this.sessionVenueAddr = sessionVenueAddr;
    }

    public String getSessionVenueName() {
        return sessionVenueName;
    }

    public void setSessionVenueName(String sessionVenueName) {
        this.sessionVenueName = sessionVenueName;
    }

    public String getRegistered() {
        return registered;
    }

    public void setRegistered(String registered) {
        this.registered = registered;
    }

    public String getEventLongName() {
        return eventLongName;
    }

    public void setEventLongName(String eventLongName) {
        this.eventLongName = eventLongName;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventCode() {
        return eventCode;
    }

    public void setEventCode(String eventCode) {
        this.eventCode = eventCode;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getEventAddress() {
        return eventAddress;
    }

    public void setEventAddress(String eventAddress) {
        this.eventAddress = eventAddress;
    }

    public String getTicketsTotal() {
        return ticketsTotal;
    }

    public void setTicketsTotal(String ticketsTotal) {
        this.ticketsTotal = ticketsTotal;
    }

    public String getCheckinTotal() {
        return checkinTotal;
    }

    public void setCheckinTotal(String checkinTotal) {
        this.checkinTotal = checkinTotal;
    }

    public String getUncheckinTotal() {
        return uncheckinTotal;
    }

    public void setUncheckinTotal(String uncheckinTotal) {
        this.uncheckinTotal = uncheckinTotal;
    }

    public String getCheckinRate() {
        return checkinRate;
    }

    public void setCheckinRate(String checkinRate) {
        this.checkinRate = checkinRate;
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorParams() {
        return errorParams;
    }

    public void setErrorParams(String errorParams) {
        this.errorParams = errorParams;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(String timeslot) {
        this.timeslot = timeslot;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.eventID);
        dest.writeString(this.eventName);
        dest.writeString(this.eventCode);
        dest.writeString(this.startTime);
        dest.writeString(this.endTime);
        dest.writeString(this.eventAddress);
        dest.writeString(this.applicant);
        dest.writeString(this.ticketsTotal);
        dest.writeString(this.checkinTotal);
        dest.writeString(this.uncheckinTotal);
        dest.writeString(this.checkinRate);
        dest.writeInt(this.resultCode);
        dest.writeString(this.resultMsg);
        dest.writeString(this.errorCode);
        dest.writeString(this.errorParams);
        dest.writeString(this.contactInfo);
        dest.writeString(this.date);
        dest.writeString(this.timeslot);
        dest.writeString(this.venue);
    }

    public EventDetailInfo() {
    }

    protected EventDetailInfo(Parcel in) {
        this.eventID = in.readString();
        this.eventName = in.readString();
        this.eventCode = in.readString();
        this.startTime = in.readString();
        this.endTime = in.readString();
        this.eventAddress = in.readString();
        this.applicant = in.readString();
        this.ticketsTotal = in.readString();
        this.checkinTotal = in.readString();
        this.uncheckinTotal = in.readString();
        this.checkinRate = in.readString();
        this.resultCode = in.readInt();
        this.resultMsg = in.readString();
        this.errorCode = in.readString();
        this.errorParams = in.readString();
        this.contactInfo = in.readString();
        this.date = in.readString();
        this.timeslot = in.readString();
        this.venue = in.readString();
    }

    public static final Creator<EventDetailInfo> CREATOR = new Creator<EventDetailInfo>() {
        @Override
        public EventDetailInfo createFromParcel(Parcel source) {
            return new EventDetailInfo(source);
        }

        @Override
        public EventDetailInfo[] newArray(int size) {
            return new EventDetailInfo[size];
        }
    };
}
