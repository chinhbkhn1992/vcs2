package com.vdaifu.user.utils

class DataUtilTest extends groovy.util.GroovyTestCase {
    void testTestCode() {
    }
}
