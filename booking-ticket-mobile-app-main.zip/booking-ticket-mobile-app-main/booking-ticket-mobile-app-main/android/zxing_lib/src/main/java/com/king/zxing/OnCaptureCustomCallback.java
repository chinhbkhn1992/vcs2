package com.king.zxing;



/**
 * @author shaorulong
 */
public interface OnCaptureCustomCallback {

    /**
     * 自定义页面，接收扫码结果回调
     * @param result 扫码结果
     */
    void onResultCallback(String result);
}
