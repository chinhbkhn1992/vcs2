package com.isoft.frame.widget;

import android.app.Dialog;
import android.content.Context;

import com.isoft.frame.R;


/**
 * 公共弹框
 * Created by rlshaoc on 2018/12/20 0020.
 */
public class LoadingDialog {

    /**
     * 显示正在加载动画
     * @param context
     */
    public static Dialog showLoadingDialog(Context context){
        //创建Dialog并传递style文件
        final Dialog dialog = new Dialog(context, R.style.base_loading_dialog);
//        final Dialog dialog = new Dialog(context);
        // 设置它的ContentView
        dialog.setContentView(R.layout.dialog_loading_layout);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();//显示dialog
        return dialog;
    }

}
