package com.isoft.frame.utils;

@SuppressWarnings("ALL")
public class CommonDataUtil {

    /**************************************** 通用 int begin *****************************/
    //接口状态码
    public static final int CODE_RESPONSE_SUCCESS = 0;
    public static final int CODE_RESPONSE_BISSINESS_FAIL = 1;
    public static final int CODE_RESPONSE_SYSTEM_FAIL = 2;

    //请求基础host
    public static String BASE_URL = "";
    public static String BASE_IMAGE_URL = "";

    public static final String CHANGE_IMAGE_PATH = "";

}
