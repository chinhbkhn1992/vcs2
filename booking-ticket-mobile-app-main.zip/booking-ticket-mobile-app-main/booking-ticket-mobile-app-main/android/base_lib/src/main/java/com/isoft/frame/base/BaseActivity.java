package com.isoft.frame.base;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.blankj.utilcode.util.BarUtils;
import com.blankj.utilcode.util.ConvertUtils;
import com.blankj.utilcode.util.ScreenUtils;
import com.isoft.frame.R;
import com.isoft.frame.R2;
import com.isoft.frame.injector.components.ApplicationComponent;
import com.isoft.frame.model.enums.ModalDirection;
import com.isoft.frame.module.ActivityModule;
import com.isoft.frame.utils.AppUtil;
import com.isoft.frame.utils.LanguageUtils;
import com.isoft.frame.utils.NotchScreenUtil;
import com.isoft.frame.utils.StatusBarUtil;
import com.isoft.frame.utils.SwipeRefreshHelper;
import com.isoft.frame.widget.EmptyLayout;
import com.isoft.frame.widget.LoadingDialog;
import com.trello.rxlifecycle.LifecycleTransformer;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by shaorulong on 2018/8/19.
 * 基类Activity
 * @version 2.0增加弹出Fragment的方法
 */
public abstract class BaseActivity<T extends IBasePresenter> extends RxAppCompatActivity implements IBaseView, EmptyLayout.OnRetryListener {

    /**
     * 把 EmptyLayout 放在基类统一处理，@Nullable 表明 View 可以为 null，详细可看 ButterKnife
     */
    @Nullable
    @BindView(R2.id.empty_layout)
    protected EmptyLayout mEmptyLayout;
    /**
     * 把 Presenter 提取到基类需要配合基类的 initInjector() 进行注入，如果继承这个基类则必定要提供一个 Presenter 注入方法，
     * 该APP所有 Presenter 都是在 Module 提供注入实现，也可以选择提供另外不带 Presenter 的基类
     */
    @Inject
    protected T mPresenter;
    /**
     * 刷新控件，注意，资源的ID一定要一样
     */
    @Nullable
    @BindView(R2.id.swipe_refresh)
    SwipeRefreshLayout mSwipeRefresh;

    /**
     * 上下文
     */
    public Context mContext;

    /**
     * 绑定布局文件
     *
     * @return 布局文件ID
     */
    @LayoutRes
    protected abstract int attachLayoutRes();

    /**
     * Dagger 注入
     */
    protected abstract void initInjector();


    /**
     * 初始化视图控件
     */
    protected abstract void initViews();

    /**
     * 更新视图控件
     */
    protected abstract void updateViews(boolean isRefresh);

    protected ViewStub bodyStub; //内容
    protected ViewStub bottomStub; //底部

    protected LinearLayout outSizeLL; // 外部布局，用来获取高度
    protected RelativeLayout modalViewGroup; // 用来动画 模态显示的 容器，里面可以嵌套fragment
    protected RelativeLayout modalViewGroupBg;// 用来动画 模态显示的 背景遮罩层

    /**
     *  把该值设置为false的时候，就不添加嵌套布局，直接使用原始布局，但是不能使用pushFargment等方法，为了解决一些布局必须放在根布局的问题，比如SlidingUpPanelLayout的使用
     */
    protected boolean usesSupperView = true;

    private static final String TAG = "BaseActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*添加透明标题栏的效果，如果不加的话，会有灰色效果*/
        Window window = getWindow();
        mContext = this;

        setContentView(attachLayoutRes());

        //  设置本地化语言
        setLocale();
//        setMIUISetStatusBarLightMode(window, false);
        //改变标题栏颜色,如果不需要修改的话，则在对应的页面手动调用用下下面的方法，参数为false
//        BarUtils.setStatusBarLightMode(getWindow(), true);
        //屏幕适配方案，参数请在AndroidManifest里修改
//        ScreenAdapterTools.getInstance().loadView(getWindow().getDecorView());
        ButterKnife.bind(this);
        initInjector();
        initViews();
        initSwipeRefresh();
        updateViews(false);
        //当FitsSystemWindows设置 true 时，会在屏幕最上方预留出状态栏高度的 padding
        StatusBarUtil.setRootViewFitsSystemWindows(this,true);
        //设置状态栏透明
//        StatusBarUtil.setTranslucentStatus(this);
        //设置标题栏内容颜色为白色
//        StatusBarUtil.setStatusBarDarkTheme(this, true);
//        StatusBarUtil.setStatusBarColor(this,R.color.colorAccent);
        //一般的手机的状态栏文字和图标都是白色的, 可如果你的应用也是纯白色的, 或导致状态栏文字看不清
        //所以如果你是这种情况,请使用以下代码, 设置状态使用深色文字图标风格, 否则你可以选择性注释掉这个if内容
        /*if (!StatusBarUtil.setStatusBarDarkTheme(this, true)) {
            //如果不支持设置深色风格 为了兼容总不能让状态栏白白的看不清, 于是设置一个状态栏颜色为半透明,
            //这样半透明+白=灰, 状态栏的文字能看得清
            StatusBarUtil.setStatusBarColor(this,0x55000000);
        }*/
    }

    @Override
    public void setContentView(int layoutResID) {
        if (!usesSupperView) {
            super.setContentView(layoutResID);
            return;
        }
        super.setContentView(R.layout.activity_frame);
        // 适配底部导航栏
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);

        outSizeLL = findViewById(R.id.outsize_ll);
        //初始化屏幕的宽度和高度，用于Fragment的捆绑弹出
        SCREEN_WIDTH = ScreenUtils.getScreenWidth();
        SCREEN_HEIGHT = ScreenUtils.getScreenHeight();
//        SCREEN_HEIGHT = outSizeLL.getLayoutParams().height;
//        Log.w("HEIGHT", SCREEN_HEIGHT + "");

        bodyStub = findViewById(R.id.body_stub);
        bottomStub = findViewById(R.id.bottom_stub);

        bodyStub.setLayoutResource(layoutResID);
        bodyStub.inflate();
//        boolean[] systemUiVisible = AppUtil.isSystemUiVisible(getWindow());

        /*// 判断是否存在底部虚拟栏
//        if (systemUiVisible[0] && systemUiVisible[1]) {
        if (AppUtil.checkDeviceHasNavigationBar(mContext) && AppUtil.isNavigationBarShow(this)) {
            Log.w(TAG, "存在虚拟底部栏");
            ViewGroup.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, AppUtil.getNavigationBarHeight(this));
            bottomStub.setLayoutParams(params);
            bottomStub.setLayoutResource(R.layout.activity_empty_bottom_view);
            bottomStub.inflate();
            bottomStub.setVisibility(View.VISIBLE);
        }*/


        modalViewGroup = findViewById(R.id.frame_modal_view_root);
        modalViewGroupBg = findViewById(R.id.frame_modal_view_bg);

        modalViewGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popModalFragment();
            }
        });
        modalViewGroupBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popModalFragment();
            }
        });

    }

    /**
     * 设置Locale
     */
    private void setLocale() {
        if (!LanguageUtils.isSameLanguage(this)) {
            LanguageUtils.setLocale(this);
            LanguageUtils.toRestartMainActvity(mContext);
        }
    }

    /**
     * 防止留海屏遮挡标题栏
     * @param paddinView
     */
    protected void initToolBarView(View ll, View paddinView) {
        int notchSize = NotchScreenUtil.getHasNotchSize(mContext);
        //判断是否是刘海屏，不是的话还要留出状态栏的高度呢
        if (notchSize > 0) {
//            notchSize = BarUtils.getStatusBarHeight();
            paddinView.setVisibility(View.VISIBLE);
            final ViewGroup.LayoutParams params = ll.getLayoutParams();
            params.height = ConvertUtils.dp2px(R.dimen.toolbar_height) + ConvertUtils.dp2px(10);
            ll.setLayoutParams(params);
        }

    }

    //是否已经弹出了Fragment
    private boolean isModalFragmentDisplay;
    //弹出Fragment的方向
    private ModalDirection direction = ModalDirection.RIGHT;
    private int modalAnimTime = 300; //弹出动画时长
    public float SCREEN_WIDTH; // 设备屏幕宽
    public float SCREEN_HEIGHT;// 设备屏幕高
    private float heightDip = 0;//弹出Fragment的高度

    /**
     * 收起弹出的Fragment
     */
    public void popModalFragment() {
        isModalFragmentDisplay = false;
        if (direction == ModalDirection.RIGHT) {
            ObjectAnimator.ofFloat(modalViewGroup, "translationX", 0, SCREEN_WIDTH)
                    .setDuration(modalAnimTime).start();
        } else if (direction == ModalDirection.LEFT) {
            ObjectAnimator.ofFloat(modalViewGroup, "translationX", 0, -heightDip).setDuration(modalAnimTime).start();
        } else if (direction == ModalDirection.TOP) {
            ObjectAnimator.ofFloat(modalViewGroup, "y", BarUtils.getActionBarHeight() + BarUtils.getStatusBarHeight(), - heightDip).setDuration(modalAnimTime).start();
        } else if (direction == ModalDirection.BOTTOM) {
            SCREEN_HEIGHT = outSizeLL.getMeasuredHeight() + 100;
            ObjectAnimator.ofFloat(modalViewGroup, "translationY", SCREEN_HEIGHT - heightDip,
                    SCREEN_HEIGHT).setDuration(modalAnimTime).start();
        } else if (direction == ModalDirection.TOP_BOTTOM) {
            int titleBarHeight = BarUtils.getActionBarHeight();
            ObjectAnimator.ofFloat(modalViewGroup, "y", titleBarHeight, heightDip + titleBarHeight).setDuration(modalAnimTime).start();
        }
        ValueAnimator colorAnim = ObjectAnimator.ofInt(modalViewGroupBg, "backgroundColor", /* Red */
                0x55000000, /* Blue */0x00000000);

        colorAnim.setDuration(modalAnimTime);
        colorAnim.setEvaluator(new ArgbEvaluator());
        colorAnim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                modalViewGroupBg.setVisibility(View.GONE);
                modalViewGroup.setVisibility(View.GONE);
//                statuBarChange();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }
        });
        colorAnim.start();
    }

    /**
     * 外部调用的弹出Fragment方式
     * @param d ,弹出方向
     * @param heightDip 弹出Fragment的高度
     * @param f 需要弹出的Fragment
     */
    public void pushModalFragment(ModalDirection d, int heightDip, BaseFragment f) {
        this.pushModalFragment(d, heightDip, modalAnimTime, f);
    }

    /**
     * 快捷捆绑需要弹出的BaseFragment
     * @param f BaseFragment
     */
    public void initModalFragment(BaseFragment f) {
        pushFragment(R.id.frame_modal_view_root, f, true);
    }

    /**
     * 真正捆绑需要弹出的BaseFragment
     * @param layoutId 需要捆绑的资源id
     * @param f BaseFragment
     * @param flag 是否需要实时更新
     */
    public void pushFragment(int layoutId, BaseFragment f, boolean flag) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out, android.R.anim.fade_out,
                    android.R.anim.fade_in);
        ft.replace(layoutId, f);
        if (flag) {
            ft.addToBackStack(f.name);
        }
        //解决异常：java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState
        ft.commitAllowingStateLoss();
    }

    /**
     * 外部调用的，需要持续时间的弹出Fragment方式
     * @param d 弹出方向
     * @param heightDip 弹出高度
     * @param time 弹出时长，默认为300ms
     * @param f 需要弹出的Fragment
     */
    public void pushModalFragment(ModalDirection d, int heightDip, int time, BaseFragment f) {
        initModalFragment(f);
        pushModalFragment(d, heightDip, time);
    }

    /**
     * 真正的弹出Fragment方法
     * @param d ModalDirection,弹出方向
     * @param heightDip 弹出Fragment的高度
     * @param time 持续时长
     */
    public void pushModalFragment(ModalDirection d, int heightDip, int time) {
        isModalFragmentDisplay = true;
        this.heightDip = heightDip;
        this.modalAnimTime = time;
        this.direction = d;
        modalViewGroupBg.setVisibility(View.VISIBLE);
        modalViewGroup.setVisibility(View.VISIBLE);

        ValueAnimator colorAnim = ObjectAnimator.ofInt(modalViewGroupBg, "backgroundColor", /* Red */0x00000000, /* Blue */
                0x55000000);
        colorAnim.setDuration(modalAnimTime);
        colorAnim.setEvaluator(new ArgbEvaluator());
        colorAnim.start();

        RelativeLayout.LayoutParams imagebtn_params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        if (ModalDirection.RIGHT == d) {
            // Lg.print("modal  right");
            imagebtn_params.height = heightDip;
            imagebtn_params.width = (int) SCREEN_WIDTH;
            modalViewGroup.setLayoutParams(imagebtn_params);
            ObjectAnimator.ofFloat(modalViewGroup, "translationX", SCREEN_WIDTH, 0)
                    .setDuration(modalAnimTime).start();

        } else if (ModalDirection.LEFT == d) {
            // Lg.print("modal  left");
            imagebtn_params.height = heightDip;
            imagebtn_params.width = (int) SCREEN_WIDTH;
            modalViewGroup.setLayoutParams(imagebtn_params);
            ObjectAnimator.ofFloat(modalViewGroup, "translationX", -heightDip, 0).setDuration(modalAnimTime).start();
        } else if (ModalDirection.BOTTOM == d) {
            // Lg.print("modal  bottom");
            imagebtn_params.height = heightDip;
            imagebtn_params.width = (int) SCREEN_WIDTH;
            modalViewGroup.setLayoutParams(imagebtn_params);
            SCREEN_HEIGHT = outSizeLL.getMeasuredHeight() + 100;
            ObjectAnimator.ofFloat(modalViewGroup, "translationY", SCREEN_HEIGHT, SCREEN_HEIGHT - heightDip)
                    .setDuration(modalAnimTime).start();
        } else if (ModalDirection.TOP == d) {
            // Lg.print("modal  top");
            imagebtn_params.height = heightDip;
            imagebtn_params.width = (int) SCREEN_WIDTH;
            modalViewGroup.setLayoutParams(imagebtn_params);
            ObjectAnimator.ofFloat(modalViewGroup, "translationY", 0, BarUtils.getActionBarHeight() + BarUtils.getStatusBarHeight()).setDuration(modalAnimTime).start();
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (isModalFragmentDisplay) {
                popModalFragment();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * loading加载框
     */
    protected Dialog loadingDialog;
    @Override
    public void showLoading() {
        /*if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(EmptyLayout.STATUS_LOADING);
        }*/
        if (loadingDialog == null) {
            loadingDialog = LoadingDialog.showLoadingDialog(mContext);
        } else {
            loadingDialog.show();
        }
    }

    @Override
    public void hideLoading() {
        /* if (mEmptyLayout != null) {
            mEmptyLayout.hide();
        }*/
        if (loadingDialog != null) {
            loadingDialog.dismiss();
        }
    }

    @Override
    public void showNetError() {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(EmptyLayout.STATUS_NO_NET);
            mEmptyLayout.setRetryListener(this);
        }
    }

    @Override
    public void showNoData() {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(EmptyLayout.STATUS_NO_DATA);
            mEmptyLayout.setRetryListener(this);
        }
    }

    /**
     * 显示数据为空的情况，显示自定义的页面
     * modify 对数据为空的情况在 BaseActivity 和 BaseFragment 统一处理
     *
     * @param state EmptyLayout的枚举值.比如 EmptyLayout.STATUS_NO_DATA
     */
    @Override
    public void showOtherView(int state) {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(state);
            mEmptyLayout.setRetryListener(this);
        }
    }

    /**
     * 初始化视图控件
     */
    protected void initSwipeRefreshViews(SwipeRefreshLayout mSwipeRefresh, EmptyLayout mEmptyLayout){
        this.mSwipeRefresh = mSwipeRefresh;
        this.mEmptyLayout = mEmptyLayout;
    }

    @Override
    public void onRetry() {
        updateViews(false);
    }

    @Override
    public <T> LifecycleTransformer<T> bindToLife() {
        return this.<T>bindToLifecycle();
    }

    @Override
    public void finishRefresh() {
        if (mSwipeRefresh != null) {
            mSwipeRefresh.setRefreshing(false);
        }
    }

    /**
     * 初始化下拉刷新
     */
    private void initSwipeRefresh() {
        if (mSwipeRefresh != null) {
            SwipeRefreshHelper.init(mSwipeRefresh, new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    updateViews(true);
                }
            });
        }
    }

    /**
     * 获取 ApplicationComponent
     *
     * @return ApplicationComponent
     */
    protected ApplicationComponent getAppComponent() {
        return BaseApplication.getAppComponent();
    }

    /**
     * 获取 ActivityModule
     *
     * @return ActivityModule
     */
    protected ActivityModule getActivityModule() {
        return new ActivityModule(this);
    }


    /**
     * 添加 Fragment
     *
     * @param containerViewId
     * @param fragment
     */
    protected void addFragment(int containerViewId, Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(containerViewId, fragment);
        fragmentTransaction.commit();
    }

    /**
     * 添加 Fragment
     *
     * @param containerViewId
     * @param fragment
     */
    protected void addFragment(int containerViewId, Fragment fragment, String tag) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        // 设置tag，不然下面 findFragmentByTag(tag)找不到
        fragmentTransaction.add(containerViewId, fragment, tag);
        fragmentTransaction.addToBackStack(tag);
        fragmentTransaction.commit();
    }

    /**
     * 替换 Fragment
     *
     * @param containerViewId
     * @param fragment
     */
    protected void replaceFragment(int containerViewId, Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(containerViewId, fragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    /**
     * 替换 Fragment
     *
     * @param containerViewId
     * @param fragment
     */
    protected void replaceFragment(int containerViewId, Fragment fragment, String tag) {
        if (getSupportFragmentManager().findFragmentByTag(tag) == null) {
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            // 设置tag
            fragmentTransaction.replace(containerViewId, fragment, tag);
            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            // 这里要设置tag，上面也要设置tag
            fragmentTransaction.addToBackStack(tag);
            fragmentTransaction.commit();
        } else {
            // 存在则弹出在它上面的所有fragment，并显示对应fragment
            getSupportFragmentManager().popBackStack(tag, 0);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
