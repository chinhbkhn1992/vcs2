package com.isoft.frame.model;

import com.google.gson.annotations.SerializedName;
import com.isoft.frame.utils.CommonDataUtil;

/**
 * 服务器通用返回数据格式
 * Created by jaycee on 2017/6/23.
 */
public class BaseEntity<E> {

    @SerializedName("code")
    private int code;
    @SerializedName("msg")
    private String msg;
    @SerializedName("data")
    private E data;

    public boolean isSuccess() {
        return code == CommonDataUtil.CODE_RESPONSE_SUCCESS;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public E getData() {
        return data;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(E data) {
        this.data = data;
    }
}