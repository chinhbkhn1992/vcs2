package com.isoft.frame.network.http;

/**
 * 对接服务器端返回数据
 */
public class HttpResult<T> {
    public int code;
    private String eMessage;
    private T result;

    public String getMessage() {
        return eMessage;
    }

    public void setMessage(String eMessage) {
        this.eMessage = eMessage;
    }

    public T getData() {
        return result;
    }

    public void setData(T data) {
        this.result = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }


}
