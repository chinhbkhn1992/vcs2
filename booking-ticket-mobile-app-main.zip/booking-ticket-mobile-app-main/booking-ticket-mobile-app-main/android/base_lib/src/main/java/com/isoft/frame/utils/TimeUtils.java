package com.isoft.frame.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by colinSun on 2020/7/3.
 */

public class TimeUtils {
    /**
     *
     * @param zeroTimeStr 零时区参数
     * @param backFormat 返回时间的格式
     * @return
     */
    public static String GetZoneTime(String zeroTimeStr,String inFormat,String backFormat){
        SimpleDateFormat zeroFormat = new SimpleDateFormat(inFormat);
        zeroFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        SimpleDateFormat currentFormat = new SimpleDateFormat(backFormat);
        currentFormat.setTimeZone(TimeZone.getDefault());
        Date date = null;
        try {
            date = zeroFormat.parse(zeroTimeStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return currentFormat.format(date);
    }
}
