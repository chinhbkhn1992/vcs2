package com.isoft.frame.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.LocaleList;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.webkit.WebView;

import com.blankj.utilcode.util.SPUtils;
import com.isoft.frame.R;
import com.isoft.frame.base.AppConstants;
import com.isoft.frame.base.BaseApplication;

import java.util.Locale;

import static com.isoft.frame.utils.PermissionUtils.getSystemProperty;

/**
 * 国际化相关工具类
 * Created by rlshao on 2019/8/12.
 */
public class LanguageUtils {

    private static final String TAG = "LanguageUtils";
    private static Locale thLocale = new Locale("zh");
    private static Locale viLocale = new Locale("vi");
    private static Locale taLocale = new Locale("ta");
    private static Locale defaultLocale = new Locale("en");
    /**
     * 设置本地化语言
     *
     * @param context
     * @param type
     */
    public static void setLocale(Context context, int type) {
        // 解决webview所在的activity语言没有切换问题
        new WebView(context).destroy();
        // 切换语言
        Resources resources = context.getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        Configuration config = resources.getConfiguration();
        config.locale = getLocaleByType(type);
        Log.d(TAG, "setLocale: " + config.locale.toString());
        resources.updateConfiguration(config, dm);
    }

    /**
     * 根据type获取locale
     *
     * @param type
     * @return
     */
    private static Locale getLocaleByType(int type) {
        Locale locale;
        // 应用用户选择语言
        switch (type) {
            case 0:
                locale = Locale.ENGLISH;
                break;
            case 1:
                //locale = Locale.SIMPLIFIED_CHINESE;
                locale = Locale.CHINESE;
                break;
            case 2:
                locale = Locale.JAPANESE;
                break;
            case 3:
                locale = viLocale;
                break;
            case 4:
                locale = Locale.ENGLISH;
                break;
            case 5:
                locale = taLocale;
                break;
            case 11:
                //由于API仅支持7.0，需要判断，否则程序会crash(解决7.0以上系统不能跟随系统语言问题)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    LocaleList localeList = LocaleList.getDefault();
                    int spType = getLanguageType();
                    // 如果app已选择不跟随系统语言，则取第二个数据为系统默认语言
                    if (spType != 0 && localeList.size() > 1) {
                        locale = localeList.get(1);
                    } else {
                        locale = localeList.get(0);
                    }
                } else {
                    locale = Locale.getDefault();
                }
                break;
            default:
                locale = defaultLocale;
                break;
        }
        return locale;
    }

    /**
     * 根据sp数据设置本地化语言
     *
     * @param context
     */
    public static void setLocale(Context context) {
        //String languagename = Locale.getDefault().getLanguage();
        String languagename = context.getResources().getConfiguration().locale.getLanguage();
        Log.e(TAG,"Device language: " + languagename);
        //String countryname = Locale.getDefault().getCountry();
        //String countryname = context.getResources().getConfiguration().locale.getCountry();
        //Log.e(TAG,"Device region: " + countryname);

        String countryname = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            countryname = context.getResources().getConfiguration().getLocales().get(0).getCountry();
        } else {
            countryname = context.getResources().getConfiguration().locale.getCountry();
        }

        String miuiRegion = getSystemProperty("ro.miui.region");

        if (!miuiRegion.isEmpty()) {
            countryname = miuiRegion;
        }
        Log.e(TAG,"Device region: " + countryname);

        int type = getLanguageType();
        Log.e(TAG,"TUNG Initial Language Type: " + type);
        Log.e(TAG,"TUNG Initial First Time Tag: " + SPUtils.getInstance().getString("first_time_tag", ""));

        if(type == 0){
            switch(countryname){
                case "JP":
                    SPUtils.getInstance().put("locale_area_tag", 0);
                    type = 2;
                    putLanguageType(type);
                    break;
                case "VN":
                    SPUtils.getInstance().put("locale_area_tag", 1);
                    switch(languagename){
                        case "en":
                            type = 4;
                            putLanguageType(type);
                            break;
                        case "vi":
                            type = 3;
                            putLanguageType(type);
                            break;
                        default:
                            type = 4;
                            putLanguageType(type);
                            break;
                    }
                    break;
                case "BN":
                    SPUtils.getInstance().put("locale_area_tag", 4);
                    switch(languagename){
                        case "en":
                            type = 4;
                            putLanguageType(type);
                            break;
                        case "zh":
                            type = 1;
                            putLanguageType(type);
                            break;
                        default:
                            type = 4;
                            putLanguageType(type);
                            break;
                    }
                    break;
                case "MY":
                    SPUtils.getInstance().put("locale_area_tag", 2);
                    switch(languagename){
                        case "en":
                            type = 4;
                            putLanguageType(type);
                            break;
                        case "zh":
                            type = 1;
                            putLanguageType(type);
                            break;
                        default:
                            type = 4;
                            putLanguageType(type);
                            break;
                    }
                    break;
                case "SG":
                    SPUtils.getInstance().put("locale_area_tag", 3);
                    switch(languagename){
                        case "en":
                            type = 4;
                            putLanguageType(type);
                            break;
                        case "zh":
                            type = 1;
                            putLanguageType(type);
                            break;
                        default:
                            type = 4;
                            putLanguageType(type);
                            break;
                    }
                    break;
                case "IN":
                    SPUtils.getInstance().put("locale_area_tag", 5);
                    switch(languagename){
                        case "en":
                            type = 4;
                            putLanguageType(type);
                            break;
                        case "ta":
                            type = 5;
                            putLanguageType(type);
                            break;
                        default:
                            type = 4;
                            putLanguageType(type);
                            break;
                    }
                    break;
                default:
                    switch(languagename){
                        case "en":
                            type = 4;
                            putLanguageType(type);
                            break;
                        case "zh":
                            type = 1;
                            putLanguageType(type);
                            break;
                        case "ja":
                            type = 2;
                            putLanguageType(type);
                            break;
                        case "vi":
                            type = 3;
                            putLanguageType(type);
                            break;
                        case "ta":
                            type = 5;
                            putLanguageType(type);
                            break;
                        default:
                            type = 4;
                            putLanguageType(type);
                            break;
                    }
                    break;
            }
        }else{
            if (SPUtils.getInstance().getString("first_time_tag", "") == "") {
                Log.e(TAG,"TUNG non-Empty Lang Type & Empty First Time Login: ");

                switch(countryname){
                    case "JP":
                        SPUtils.getInstance().put("locale_area_tag", 0);
                        type = 2;
                        putLanguageType(type);
                        break;
                    case "VN":
                        SPUtils.getInstance().put("locale_area_tag", 1);
                        switch(languagename){
                            case "en":
                                type = 4;
                                putLanguageType(type);
                                break;
                            case "vi":
                                type = 3;
                                putLanguageType(type);
                                break;
                            default:
                                type = 4;
                                putLanguageType(type);
                                break;
                        }
                        break;
                    case "BN":
                        SPUtils.getInstance().put("locale_area_tag", 4);
                        switch(languagename){
                            case "en":
                                type = 4;
                                putLanguageType(type);
                                break;
                            case "zh":
                                type = 1;
                                putLanguageType(type);
                                break;
                            default:
                                type = 4;
                                putLanguageType(type);
                                break;
                        }
                        break;
                    case "MY":
                        SPUtils.getInstance().put("locale_area_tag", 2);
                        switch(languagename){
                            case "en":
                                type = 4;
                                putLanguageType(type);
                                break;
                            case "zh":
                                type = 1;
                                putLanguageType(type);
                                break;
                            default:
                                type = 4;
                                putLanguageType(type);
                                break;
                        }
                        break;
                    case "SG":
                        SPUtils.getInstance().put("locale_area_tag", 3);
                        switch(languagename){
                            case "en":
                                type = 4;
                                putLanguageType(type);
                                break;
                            case "zh":
                                type = 1;
                                putLanguageType(type);
                                break;
                            default:
                                type = 4;
                                putLanguageType(type);
                                break;
                        }
                        break;
                    case "IN":
                        SPUtils.getInstance().put("locale_area_tag", 5);
                        switch(languagename){
                            case "en":
                                type = 4;
                                putLanguageType(type);
                                break;
                            case "ta":
                                type = 5;
                                putLanguageType(type);
                                break;
                            default:
                                type = 4;
                                putLanguageType(type);
                                break;
                        }
                        break;
                    default:
                        switch(languagename){
                            case "en":
                                type = 4;
                                putLanguageType(type);
                                break;
                            case "zh":
                                type = 1;
                                putLanguageType(type);
                                break;
                            case "ja":
                                type = 2;
                                putLanguageType(type);
                                break;
                            case "vi":
                                type = 3;
                                putLanguageType(type);
                                break;
                            case "ta":
                                type = 5;
                                putLanguageType(type);
                                break;
                            default:
                                type = 4;
                                putLanguageType(type);
                                break;
                        }
                        break;
                }
            }
        }
        setLocale(context, type);
    }

    /**
     * 判断是否是相同语言
     *
     * @param context
     * @return
     */
    public static boolean isSameLanguage(Context context) {
        int type = getLanguageType();
        return isSameLanguage(context, type);
    }

    /**
     * 判断是否是相同语言
     *
     * @param context
     * @param type
     * @return
     */
    public static boolean isSameLanguage(Context context, int type) {
        Locale locale = getLocaleByType(type);
        Locale appLocale = context.getResources().getConfiguration().locale;
        boolean equals = appLocale.getLanguage().equals(locale.toString());
        Log.d(TAG, "isSameLanguage: " + locale.toString() + " / " + appLocale.getLanguage() + " / " + equals);
        return equals;

    }

    /**
     * sp存储本地语言类型
     *
     * @param type
     */
    public static void putLanguageType(int type) {
        SPUtils.getInstance().put(AppConstants.LOCALE_LANGUAGE, type);
    }

    /**
     * sp获取本地存储语言类型
     *
     * @return
     */
    public static int getLanguageType() {
        return SPUtils.getInstance().getInt(AppConstants.LOCALE_LANGUAGE, 0);
    }

    /**
     * 重启主页.
     * @param context 当前页
     */
    public static void toRestartMainActvity(Context context) {
        Log.d(TAG, "toRestartMainActvity");
        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeCustomAnimation(context, R.anim.fade_in_anim, R.anim.fade_out_anim);
        Intent intent = new Intent();
        intent.setClassName(context, BaseApplication.mainActivityName);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        ActivityCompat.startActivity(context, intent, optionsCompat.toBundle());
        ((Activity) context).finish();
        // 杀掉进程，如果是跨进程则杀掉当前进程
//        android.os.Process.killProcess(android.os.Process.myPid());
//        System.exit(0);
    }
}
