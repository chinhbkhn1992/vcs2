package com.isoft.frame.local.table;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

/**
 * Created by shaorulonglong on 2018/8/31.
 * 联网数据基础模型.
 */
@Entity
public class NetDataInfo {

    @Id(autoincrement = true)
    private Long id;
    //也有可能是examid，根据type来区分
    private Long topicId;
    private Long questionid;
    //我填写的答案
    private String answer;
    //正确的答案
    private String rightanswer;
    //是否点击了显示答案
    private int showanswer;
    //类型0：章节练习，1：理论考试，2：模拟考试
    private int type;
    @Generated(hash = 191845729)
    public NetDataInfo(Long id, Long topicId, Long questionid, String answer,
            String rightanswer, int showanswer, int type) {
        this.id = id;
        this.topicId = topicId;
        this.questionid = questionid;
        this.answer = answer;
        this.rightanswer = rightanswer;
        this.showanswer = showanswer;
        this.type = type;
    }
    @Generated(hash = 1830622722)
    public NetDataInfo() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getTopicId() {
        return this.topicId;
    }
    public void setTopicId(Long topicId) {
        this.topicId = topicId;
    }
    public Long getQuestionid() {
        return this.questionid;
    }
    public void setQuestionid(Long questionid) {
        this.questionid = questionid;
    }
    public String getAnswer() {
        return this.answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    public String getRightanswer() {
        return this.rightanswer;
    }
    public void setRightanswer(String rightanswer) {
        this.rightanswer = rightanswer;
    }
    public int getShowanswer() {
        return this.showanswer;
    }
    public void setShowanswer(int showanswer) {
        this.showanswer = showanswer;
    }
    public int getType() {
        return this.type;
    }
    public void setType(int type) {
        this.type = type;
    }

}
