package com.isoft.frame.network.service;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.blankj.utilcode.util.AppUtils;
import com.isoft.frame.base.BaseApplication;
import com.isoft.frame.network.http.SSLSocketClient;
import com.orhanobut.logger.Logger;
import com.isoft.frame.utils.CommonDataUtil;
import com.isoft.frame.utils.NetUtil;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static com.isoft.frame.utils.CommonDataUtil.BASE_URL;


/**
 * Created by rlshao on 2018/12/03.
 * 整个网络通信服务的启动控制，必须先调用初始化函数才能正常使用网络通信接口
 */
public class RetrofitService {

    //请求类型
    public static final String HTTP_TYPE_HTTPS = "https";

    //设缓存有效期为1天
    static final long CACHE_STALE_SEC = 60 * 60 * 24 * 1;
    //查询缓存的Cache-Control设置，为if-only-cache时只查询缓存而不会请求服务器，max-stale可以配合设置缓存失效时间
    private static final String CACHE_CONTROL_CACHE = "only-if-cached, max-stale=" + CACHE_STALE_SEC;
    //查询网络的Cache-Control设置
    //(假如请求了服务器并在a时刻返回响应结果，则在max-age规定的秒数内，浏览器将不会发送对应的请求到服务器，数据由缓存直接返回)
    public static final String CACHE_CONTROL_NETWORK = "Cache-Control: public, max-age=3600";
    // 避免出现 HTTP 403 Forbidden，参考：http://stackoverflow.com/questions/13670692/403-forbidden-with-java-but-not-web-browser
    public static final String AVOID_HTTP403_FORBIDDEN = "User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11";


    // 递增页码
    private static final int INCREASE_PAGE = 20;

    private static final LinkedHashMap<String, Object> cache = new LinkedHashMap<>(100, 0.75f, true);


    private RetrofitService() {
        throw new AssertionError();
    }


    /**
     * Retrofit是基于OkHttpClient的，可以创建一个OkHttpClient进行一些配置
     * @return OkHttpClient
     */
    private static OkHttpClient getHttpClient(Context context) {
        String hosts[] = {BASE_URL};
        // 指定缓存路径,缓存大小100Mb
        Cache cache = new Cache(new File(AppUtils.getAppPackageName(), "HttpCache"),
                1024 * 1024 * 100);
        OkHttpClient.Builder httpClientBuild = new OkHttpClient.Builder().cache(cache);
        //判断是否使用https进行网络请求，是的话则要添加证书验证
        if (BASE_URL.startsWith(HTTP_TYPE_HTTPS)) {
            /*
            被屏蔽的代码是需要验证证书的，现在的做法是信任所有的证书
            int[] certificates = {R.raw.ssl};
            httpClientBuild.sslSocketFactory(HttpsUtil.getSSLSocketFactory(context, certificates));
            httpClientBuild.hostnameVerifier(HttpsUtil.getHostnameVerifier(hosts));*/
            httpClientBuild.sslSocketFactory(SSLSocketClient.getSSLSocketFactory());
            httpClientBuild.hostnameVerifier(SSLSocketClient.getHostnameVerifier());


        }
        httpClientBuild.retryOnConnectionFailure(true)
                .addInterceptor(sLoggingInterceptor)
                .addInterceptor(sRewriteCacheControlInterceptor)
                .addNetworkInterceptor(sRewriteCacheControlInterceptor)
                .connectTimeout(10, TimeUnit.SECONDS);
        return httpClientBuild.build();
    }
    /**
     * 初始化网络通信服务
     */
    public static void init(Context context) {
        Retrofit retrofit = new Retrofit.Builder()
                .client(getHttpClient(context))
//                .addConverterFactory(ResponseConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(CommonDataUtil.BASE_URL)
                .build();
    }

    /**
     * 由retrofit创建各个api的生成类，先从缓存中寻找，有的就返回，没有的创建新的再存入缓存
     * 不需要提前init
     * @param service api接口类的类对象
     * @param <T> api接口生成类泛型
     * @return api生成类
     */
    public static <T> T obtainRetrofitService(Class<T> service) {
        T retrofitService;
        synchronized (cache) {
            retrofitService = (T) cache.get(service.getCanonicalName());
            if (retrofitService == null) {
                retrofitService = new Retrofit.Builder()
                        .client(getHttpClient(BaseApplication.getContext()))
                        .addConverterFactory(GsonConverterFactory.create())
                        .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                        .baseUrl(BASE_URL)
//                        .baseUrl(BASE_URL)
                        .build()
                        .create(service);
                cache.put(service.getCanonicalName(), retrofitService);
            }
        }
        return retrofitService;
    }

    /**
     * 云端响应头拦截器，用来配置缓存策略
     * Dangerous interceptor that rewrites the server's cache-control header.
     */
    private static final Interceptor sRewriteCacheControlInterceptor = new Interceptor() {

        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            if (!NetUtil.isNetworkAvailable(BaseApplication.getContext())) {
                request = request.newBuilder().cacheControl(CacheControl.FORCE_CACHE).build();
                Logger.e("no network");
            }
            Response originalResponse = chain.proceed(request);

            if (NetUtil.isNetworkAvailable(BaseApplication.getContext())) {
                //有网的时候读接口上的@Headers里的配置，你可以在这里进行统一的设置
                String cacheControl = request.cacheControl().toString();
                return originalResponse.newBuilder()
                        .header("Cache-Control", cacheControl)
                        .removeHeader("Pragma")
                        .build();
            } else {
                return originalResponse.newBuilder()
                        .header("Cache-Control", "public, " + CACHE_CONTROL_CACHE)
                        .removeHeader("Pragma")
                        .build();
            }
        }
        /*@Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request()
                    .newBuilder()
                    .addHeader("appType", "android")
                    .build();
            return chain.proceed(request);
        }*/
    };

    /**
     * 打印返回的json数据拦截器
     */
    private static final Interceptor sLoggingInterceptor = new Interceptor() {

        @Override
        public Response intercept(Chain chain) throws IOException {
            final Request request = chain.request();
            Buffer requestBuffer = new Buffer();
            if (request.body() != null) {
                request.body().writeTo(requestBuffer);
            } else {
                Logger.d("LogTAG", "request.body() == null");
            }
            //打印url信息
            Logger.w(request.url() + (request.body() != null ? "?" + _parseParams(request.body(), requestBuffer) : ""));
            final Response response = chain.proceed(request);

            return response;
        }
    };

    @NonNull
    private static String _parseParams(RequestBody body, Buffer requestBuffer) throws UnsupportedEncodingException {
        if (body.contentType() != null && !body.contentType().toString().contains("multipart")) {
            return URLDecoder.decode(requestBuffer.readUtf8(), "UTF-8");
        }
        return "null";
    }



    /******************************************* 转换器 **********************************************/

    /**
     * 转换器，因为 Key 是动态变动，所以用这种不太合适
     * @param <T>
     */
    @Deprecated
    public static class FlatMapTransformer<T> implements Observable.Transformer<Map<String, List<T>>, T> {

        private String mMapKey;

        public FlatMapTransformer<T> setMapKey(String mapKey) {
            mMapKey = mapKey;
            return this;
        }

        @Override
        public Observable<T> call(Observable<Map<String, List<T>>> mapObservable) {
            return  mapObservable.flatMap(new Func1<Map<String, List<T>>, Observable<T>>() {
                @Override
                public Observable<T> call(Map<String, List<T>> stringListMap) {
                    if (TextUtils.isEmpty(mMapKey)) {
                        return Observable.error(new Throwable("Map Key is empty"));
                    }
                    return Observable.from(stringListMap.get(mMapKey));
                }
            }).subscribeOn(Schedulers.io())
                    .unsubscribeOn(Schedulers.io())
                    .subscribeOn(AndroidSchedulers.mainThread())
                    .observeOn(AndroidSchedulers.mainThread());
        }
    }


}
