package com.isoft.frame.model.enums;

/**
 * 动画方向
 */
public enum ModalDirection {
	//左，右，上，下，从顶部延伸至底部
	LEFT(0x001), RIGHT(0x002), TOP(0x003), BOTTOM(0x004), TOP_BOTTOM(0x005);
	private int context=0x001;
	ModalDirection(int context) {
		this.context=context;
	}
	public int getContext() {
		return context;
	}
}