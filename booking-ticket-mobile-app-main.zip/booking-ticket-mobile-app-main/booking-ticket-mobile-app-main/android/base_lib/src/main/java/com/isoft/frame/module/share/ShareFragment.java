package com.isoft.frame.module.share;

import android.app.Activity;

import com.blankj.utilcode.util.ConvertUtils;
import com.isoft.frame.R;
import com.isoft.frame.base.BaseFragment;

public class ShareFragment extends BaseFragment {
    @Override
    protected int attachLayoutRes() {
        return R.layout.fragment_my_share;
    }

    @Override
    protected void initInjector() {

    }

    @Override
    protected void initViews() {

    }

    @Override
    protected void updateViews(boolean isRefresh) {

    }

    public int getSelectorHeight(Activity context) {
        float h = context.getResources().getDimension(R.dimen.common_share_height_size);
        return ConvertUtils.dp2px(h);
    }
}
