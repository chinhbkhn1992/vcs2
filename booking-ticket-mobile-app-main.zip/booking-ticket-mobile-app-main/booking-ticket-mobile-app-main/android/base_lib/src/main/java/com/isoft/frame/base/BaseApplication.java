package com.isoft.frame.base;

import android.app.Application;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.multidex.MultiDex;

import com.blankj.utilcode.util.Utils;
import com.isoft.frame.injector.components.ApplicationComponent;
import com.isoft.frame.local.dao.DaoMaster;
import com.isoft.frame.local.dao.DaoSession;
import com.isoft.frame.rxbus.RxBus;
import com.isoft.frame.utils.ToastUtils;

/**
 * Created by shaorulong on 2018/12/5.
 * Application基类
 */
public class BaseApplication extends Application {

    protected static ApplicationComponent sAppComponent;
    protected static Context sContext;
    public static String mainActivityName;
    // 因为下载那边需要用，这里在外面实例化在通过 ApplicationModule 设置
    protected RxBus mRxBus = new RxBus();
    //数据库名称
    private static final String DB_NAME = "base-db";
    private static DaoSession daoSession;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        sContext = this;

        _initConfig();
//        _initDatabase();
    }


    /**
     * 初始化配置
     */
    protected void _initConfig() {
        Utils.init(this);
        ToastUtils.init(this);
        //暂时不用系统框架
//        RetrofitService.init(sContext);
    }

    /**
     * 配置数据库
     */
    private void _initDatabase() {
        //创建数据库shop.db
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, DB_NAME, null);
        //获取可写数据库
        SQLiteDatabase db = helper.getWritableDatabase();
        //获取数据库对象
        DaoMaster daoMaster = new DaoMaster(db);
        //获取dao对象管理者
        daoSession = daoMaster.newSession();
    }

    //返回可操作对象
    public static DaoSession getBaseDaoInstant() {
        return daoSession;
    }


    public static Context getContext() {
        return sContext;
    }

    public static Context getApplication() {
        return sContext;
    }

    /**
     * 使用Tinker生成Application，这里改成静态调用
     * @return
     */
    public static ApplicationComponent getAppComponent() {
        return sAppComponent;
    }

}
