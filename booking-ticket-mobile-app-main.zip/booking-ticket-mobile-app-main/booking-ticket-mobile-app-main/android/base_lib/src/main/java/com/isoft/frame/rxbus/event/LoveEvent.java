package com.isoft.frame.rxbus.event;

/**
 * Created by long on 2016/9/29.
 * 收藏事件
 */
public class LoveEvent {
}
