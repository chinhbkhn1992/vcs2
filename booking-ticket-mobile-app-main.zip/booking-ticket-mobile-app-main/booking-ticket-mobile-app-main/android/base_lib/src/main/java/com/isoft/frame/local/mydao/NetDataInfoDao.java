package com.isoft.frame.local.mydao;

import com.isoft.frame.base.BaseApplication;
import com.isoft.frame.local.table.NetDataInfo;

import java.util.List;

/**
 * 试题答案DAO操作
 */
public class NetDataInfoDao {
    /**
     * 添加数据，如果有重复则覆盖
     *
     * @param bean
     */
    public static void insertOrReplace(NetDataInfo bean) {
        BaseApplication.getBaseDaoInstant().insertOrReplace(bean);
    }

    /**
     * 删除数据
     *
     * @param bean
     */
    public static void deleteBean(NetDataInfo bean) {
        BaseApplication.getBaseDaoInstant().delete(bean);
    }

    /**
     * 删除对应试卷数据
     *
     * @param topicId
     */
    public static void delete(long topicId) {
        BaseApplication.getBaseDaoInstant().delete(topicId);
    }

    /**
     * 更新数据
     */
    public static void updateBean(NetDataInfo bean) {
        BaseApplication.getBaseDaoInstant().update(bean);
    }

    /**
     * 根据试卷id查询所有的答案数据
     *
     * @return List<ExamAnswerInfo>
     */
    /*public static List<ExamAnswerInfo> queryList(long topicId, int type) {
        return MyApplication.getDaoInstant().queryBuilder(ExamAnswerInfo.class).where(ExamAnswerInfoDao.Properties.TopicId.eq(topicId), ExamAnswerInfoDao.Properties.Type.eq(type)).list();
    }*/

    /**
     * 根据试卷id查询所有的答案数据
     *
     * @return List<ExamAnswerInfo>
     */
   /* public static List<ExamAnswerInfo> queryListByType(int type) {
        return MyApplication.getDaoInstant().queryBuilder(ExamAnswerInfo.class).where(ExamAnswerInfoDao.Properties.Type.eq(type)).list();
    }*/

    /**
     * 根据题目id查询所有对应的答案数据
     *
     * @return ExamAnswerInfo
     */
    /*public static ExamAnswerInfo queryExamAnswerInfoById(long questionid, int type) {
        List<ExamAnswerInfo> infoList = MyApplication.getDaoInstant().queryBuilder(ExamAnswerInfo.class).where(
                ExamAnswerInfoDao.Properties.Questionid.eq(questionid), ExamAnswerInfoDao.Properties.Type.eq(type)).list();
        if (infoList != null && infoList.size() > 0) {
            return infoList.get(0);
        } else {
            return null;
        }
    }*/

}
