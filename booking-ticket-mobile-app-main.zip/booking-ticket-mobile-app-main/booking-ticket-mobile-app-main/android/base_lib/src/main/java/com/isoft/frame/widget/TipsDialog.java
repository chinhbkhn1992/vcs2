package com.isoft.frame.widget;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.isoft.frame.R;


/**
 * <p>重复扫描提示弹框：<p>
 * <p>作者：rlshao<p>
 * <p>rlshao@isoftstone.com<p>
 * <p>创建时间：2020/4/30<p>
 * <p>版本号：1.0<p>
 */
public class TipsDialog extends Dialog {
    private Context mContext;
    private View view;

    private Button knowBtn;
    private TextView contentTv;

    public void setListener(ExitClickListener listener) {
        this.listener = listener;
    }

    private ExitClickListener listener;

    public TipsDialog(@NonNull Context context) {
        this(context, R.layout.common_dialog_tips, R.style.dialog_tips_style,
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

        this.mContext = context;

    }

    public TipsDialog(@NonNull Context context, int type) {
        this(context, R.layout.common_dialog_tips, R.style.dialog_tips_style,
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

        contentTv = findViewById(R.id.id_tv_content);
        if(type == 0){
            contentTv.setText(R.string.please_select_region_first);
        }else if(type == 1){
            contentTv.setText(R.string.please_select_region_and_language);
        }else if(type == 2){
            contentTv.setText(R.string.text_error_network);
        }

        this.mContext = context;

    }

    public TipsDialog(Context context, int layout, int style, int width,
                      int height) {
        super(context, style);

        view = View.inflate(context, layout, null);
        setContentView(view);
        setCanceledOnTouchOutside(true);
        setCancelable(false);
//        // 设置属性值
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = width;
        lp.height = height;
        getWindow().setAttributes(lp);

        knowBtn = findViewById(R.id.btn_know);
        contentTv = findViewById(R.id.id_tv_content);

        knowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                if (listener != null){
                    listener.click(listener.BTN_EXIT_YES);
                }
            }
        });

    }

    public void setContent(String content){
        contentTv.setText(content);
    }


    @Override
    public void show() {
        super.show();
        //设置dialog显示动画
        getWindow().setWindowAnimations(R.style.dialogInOut);
        // 设置显示位置为底部
        getWindow().setGravity(Gravity.BOTTOM);
    }

    /**
     * 点击回调.
     */
    public interface ExitClickListener {
        //同意按钮
        int BTN_EXIT_YES = 0;

        /**
         * 点击类型
         * @param state
         */
        void click(int state);
    }

}
