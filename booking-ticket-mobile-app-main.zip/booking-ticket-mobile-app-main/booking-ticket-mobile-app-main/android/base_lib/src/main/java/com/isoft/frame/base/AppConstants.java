package com.isoft.frame.base;

/**
 * 国际化本地记录标识
 * Created by rlshao on 2019/8/21.
 */
public class AppConstants {

    /**
     * 国际化本地记录标识
     */
    public static final String LOCALE_LANGUAGE = "locale_language";
}
