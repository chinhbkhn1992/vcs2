package com.isoft.frame.network.http;

/** 
 * 【作用】错误码<br>
 * 【说明】[1000,1999]通用错误；[2000,2999]对外错误；[3000,3999]对内错误
 * @author yinsj
 * @Date 2018年5月18日 下午7:28:14
 */
public enum MyErrcodeEnum {

    SUCCESS(1, "执行成功")
    ,FAIL(0, "服务器发生错误")
    ,SERVER_ERROR(-1, "服务器发生错误")
    ,CODE_NO_DATA(11, "返回数据为空")
    ,CODE_NO_NET(12, "网络不可用")
    ,CODE_TIMEOUT(13, "请求网络超时")
    ,CODE_JSON_PARSE(14, "数据解析错误JsonParse")
    ,CODE_PARSE(15, "数据解析错误JsonParse")
    ,CODE_JSON(16, "数据解析错误JsonParse")
    ,CODE_COMMON_ERROR(99, "返回数据为空")
    ,HTTP_EXCEPTION_307(307, "请求被重定向到其他页面")
    ,HTTP_EXCEPTION_403(403, "请求被服务器拒绝")
    ,HTTP_EXCEPTION_404(404, "请求地址不存在")

    ;

    /**
     * 值
     */
    private Integer val;

    /**
     * 说明
     */
    private String desc;

    private MyErrcodeEnum(Integer val, String desc) {
        this.val = val;
        this.desc = desc;
    }

    public Integer getVal() {
        return val;
    }

    public String getDesc() {
        return desc;
    }
    
}

