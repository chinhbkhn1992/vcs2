package com.isoft.frame.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.isoft.frame.R;
import com.isoft.frame.R2;
import com.trello.rxlifecycle.LifecycleTransformer;
import com.trello.rxlifecycle.components.support.RxFragment;
import com.isoft.frame.model.enums.ModalDirection;
import com.isoft.frame.utils.SwipeRefreshHelper;
import com.isoft.frame.widget.EmptyLayout;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by shaorulong on 2018/5/31.
 * 碎片基类
 */
public abstract class BaseFragment<T extends IBasePresenter> extends RxFragment implements IBaseView, EmptyLayout.OnRetryListener {

    /**
     * 注意，资源的ID一定要一样
     */
    @Nullable
    @BindView(R2.id.empty_layout)
    protected EmptyLayout mEmptyLayout;

    @Nullable
    @BindView(R2.id.swipe_refresh)
    protected SwipeRefreshLayout mSwipeRefresh;

    @Inject
    protected T mPresenter;

    protected BaseActivity activity;
    //缓存Fragment view
    protected View mRootView;
    private boolean mIsMulti = false;

    public String name = this.getClass().getName();

    //Fragment中，Butterknife需要解绑
    private Unbinder unbinder;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (BaseActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mRootView == null) {
            mRootView = inflater.inflate(attachLayoutRes(), null);
            //屏幕适配方案，参数请在AndroidManifest中修改
//            ScreenAdapterTools.getInstance().loadView(mRootView);
            //返回一个Unbinder值（进行解绑），注意这里的this不能使用getActivity()
            unbinder = ButterKnife.bind(this, mRootView);
            mEmptyLayout = mRootView.findViewById(R.id.empty_layout);
            mSwipeRefresh = mRootView.findViewById(R.id.swipe_refresh);
            initInjector();
            initViews();
            initSwipeRefresh();
        }
        ViewGroup parent = (ViewGroup) mRootView.getParent();
        if (parent != null) {
            parent.removeView(mRootView);
        }
        return mRootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getUserVisibleHint() && mRootView != null && !mIsMulti) {
            mIsMulti = true;
            updateViews(false);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if (isVisibleToUser && isVisible() && mRootView != null && !mIsMulti) {
            mIsMulti = true;
            updateViews(false);
        } else {
            super.setUserVisibleHint(isVisibleToUser);
        }
    }

    @Override
    public void showLoading() {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(EmptyLayout.STATUS_LOADING);
            SwipeRefreshHelper.enableRefresh(mSwipeRefresh, false);
        }
    }

    /**
     * 外部调用的弹出Fragment方式
     * @param d ,弹出方向
     * @param heightDip 弹出Fragment的高度
     * @param f 需要弹出的Fragment
     */
    public void pushModalFragment(ModalDirection d, int heightDip, BaseFragment f) {
        activity.pushModalFragment(d, heightDip, f);
    }

    /**
     * 隐藏已经弹出的Fragment。
     */
    public void popModalFragment() {
        activity.popModalFragment();
    }

    @Override
    public void hideLoading() {
        if (mEmptyLayout != null) {
            mEmptyLayout.hide();
            SwipeRefreshHelper.enableRefresh(mSwipeRefresh, true);
            SwipeRefreshHelper.controlRefresh(mSwipeRefresh, false);
        }
    }

    @Override
    public void showNetError() {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(EmptyLayout.STATUS_NO_NET);
            mEmptyLayout.setRetryListener(this);
        }
    }

    @Override
    public void showNoData() {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(EmptyLayout.STATUS_NO_DATA);
            mEmptyLayout.setRetryListener(this);
        }
    }

    /**
     * 显示数据为空的情况，显示自定义的页面
     * modify 对数据为空的情况在 BaseActivity 和 BaseFragment 统一处理
     * @param state EmptyLayout的枚举值.比如 EmptyLayout.STATUS_NO_DATA
     */
    @Override
    public void showOtherView(int state) {
        if (mEmptyLayout != null) {
            mEmptyLayout.setEmptyStatus(state);
            mEmptyLayout.setRetryListener(this);
        }
    }

    /**
     * 初始化视图控件
     */
    protected void initSwipeRefreshViews(SwipeRefreshLayout mSwipeRefresh, EmptyLayout mEmptyLayout){
        this.mSwipeRefresh = mSwipeRefresh;
        this.mEmptyLayout = mEmptyLayout;
    }

    @Override
    public void onRetry() {
        updateViews(false);
    }

    @Override
    public <T> LifecycleTransformer<T> bindToLife() {
        return this.<T>bindToLifecycle();
    }

    @Override
    public void finishRefresh() {
        if (mSwipeRefresh != null) {
            mSwipeRefresh.setRefreshing(false);
        }
    }

    /**
     * onDestroyView中进行解绑操作
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //https://www.jianshu.com/p/3678aafdabc7
        unbinder.unbind();
    }


    /**
     * 获取 ApplicationComponent
     *
     * @return ApplicationComponent
     */
    /*protected ApplicationComponent getAppComponent() {
        return MyApplication.getAppComponent();
//        return ((MvpApplication) getActivity().getApplication().get).getAppComponent();
    }*/

    /**
     * 初始化 Toolbar
     *
     * @param toolbar
     * @param homeAsUpEnabled
     * @param title
     */
    /*protected void initToolBar(Toolbar toolbar, boolean homeAsUpEnabled, String title) {
        ((BaseActivity)getActivity()).initToolBar(toolbar, homeAsUpEnabled, title);
    }*/

    /**
     * 初始化下拉刷新
     */
    private void initSwipeRefresh() {
        if (mSwipeRefresh != null) {
            SwipeRefreshHelper.init(mSwipeRefresh, new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    updateViews(true);
                }
            });
        }
    }

    /**
     * 绑定布局文件
     * @return  布局文件ID
     */
    protected abstract int attachLayoutRes();

    /**
     * Dagger 注入
     */
    protected abstract void initInjector();

    /**
     * 初始化视图控件
     */
    protected abstract void initViews();

    /**
     * 更新视图控件
     * @param isRefresh 新增参数，用来判断是否为下拉刷新调用，下拉刷新的时候不应该再显示加载界面和异常界面
     */
    protected abstract void updateViews(boolean isRefresh);

}
