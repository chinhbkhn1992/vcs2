package com.isoft.frame.injector.components;

import android.content.Context;

import com.isoft.frame.injector.modules.ApplicationModule;
import com.isoft.frame.rxbus.RxBus;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by long on 2016/8/19.
 * Application Component
 */
@Singleton
@Component(modules = ApplicationModule.class)
public interface ApplicationComponent {

    // provide
    Context getContext();
    RxBus getRxBus();
//    DaoSession getDaoSession();
//    RxErrorHandler getResponseErrorHandler();
}
