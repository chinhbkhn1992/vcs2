package com.isoft.frame.network.http;

import android.net.ParseException;

import com.blankj.utilcode.util.ObjectUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.google.gson.JsonParseException;

import org.json.JSONException;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.List;

import retrofit2.HttpException;
import rx.Subscriber;

/**
 * @author shaorulong
 * @time 2018-06-27
 * 自定义服务器交互转换类，统一异常处理返回
 */
public abstract class HttpResultSubscriber<T> extends Subscriber<HttpResult<T>> {

    @Override
    public void onNext(HttpResult<T> t) {
        if (t.code == MyErrcodeEnum.SUCCESS.getVal()) {
            if (ObjectUtils.isEmpty(t.getData()) && t.getData() instanceof List) {
                //没有数据
                _onError(MyErrcodeEnum.CODE_NO_DATA.getVal(),MyErrcodeEnum.CODE_NO_DATA.getDesc());
            } else {
                onSuccess(t.getData());
            }
        } else {
            _onError(t.getCode(), t.getMessage());
        }
    }

    @Override
    public void onCompleted() {

    }

    @Override
    public void onError(Throwable e) {
        e.printStackTrace();
        String msg;
        if (e instanceof UnknownHostException) {
            msg = "网络不可用";
            _onError(MyErrcodeEnum.CODE_NO_NET.getVal(), MyErrcodeEnum.CODE_NO_NET.getDesc());
        } else if (e instanceof SocketTimeoutException) {
            msg = "请求网络超时";
            _onError(MyErrcodeEnum.CODE_TIMEOUT.getVal(), MyErrcodeEnum.CODE_TIMEOUT.getDesc());
        } else if (e instanceof HttpException) {
            HttpException httpException = (HttpException) e;
            msg = convertStatusCode(httpException);
        } else if (e instanceof JsonParseException) {
            ToastUtils.showShort(e.getMessage());
            msg = "数据解析错误JsonParse";
            _onError(MyErrcodeEnum.CODE_JSON_PARSE.getVal(), MyErrcodeEnum.CODE_JSON_PARSE.getDesc());
        } else if (e instanceof ParseException) {
            msg = "数据解析错误Parse";
            _onError(MyErrcodeEnum.CODE_PARSE.getVal(), MyErrcodeEnum.CODE_PARSE.getDesc());
        } else if (e instanceof JSONException) {
            msg = "数据解析错误Json";
            _onError(MyErrcodeEnum.CODE_JSON.getVal(), MyErrcodeEnum.CODE_JSON.getDesc());
        } else if (e instanceof ResultException) {
            //自定义的ResultException
            //由于返回200,300返回格式不统一的问题，自定义GsonResponseBodyConverter凡是300的直接抛异常
            _onError(((ResultException) e).getErrCode(),((ResultException) e).getMsg());
        }
    }

    private String convertStatusCode(HttpException httpException) {
        String msg;
        if (httpException.code() == MyErrcodeEnum.SERVER_ERROR.getVal()) {
            //服务器出错了
            msg = MyErrcodeEnum.SERVER_ERROR.getDesc();
        } else if (httpException.code() == MyErrcodeEnum.CODE_NO_DATA.getVal()) {
            //返回数据为空
            msg = MyErrcodeEnum.CODE_NO_DATA.getDesc();
        } else if (httpException.code() == MyErrcodeEnum.HTTP_EXCEPTION_404.getVal()) {
            //请求地址不存在
            msg = MyErrcodeEnum.HTTP_EXCEPTION_404.getDesc();
        } else if (httpException.code() == MyErrcodeEnum.HTTP_EXCEPTION_403.getVal()) {
            //请求被服务器拒绝
            msg = MyErrcodeEnum.HTTP_EXCEPTION_403.getDesc();
        } else if (httpException.code() == MyErrcodeEnum.HTTP_EXCEPTION_307.getVal()) {
            //请求被重定向到其他页面
            msg = MyErrcodeEnum.HTTP_EXCEPTION_307.getDesc();
        } else {
            msg = httpException.message();
        }
        _onError(httpException.code(), msg);
        return msg;
    }



    public abstract void onSuccess(T t);

    public abstract void _onError(int status, String msg);
}
