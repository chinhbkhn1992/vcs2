package com.isoft.frame.network.http;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

import com.blankj.utilcode.util.FileUtils;
import com.blankj.utilcode.util.SDCardUtils;
import com.isoft.frame.utils.CommonDataUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * 创建上传图片的body工厂
 */
public class RequestBodyFactory {

    private static String CHANGE_IMG_FILE_NAME = "tempImg.jpg";

    public static MultipartBody.Part provideFileRequestPart(File file) {
        RequestBody requestFile;
        long fileSize = FileUtils.getFileLength(file);
        File uploadFile = new File(fileOpera() + CHANGE_IMG_FILE_NAME);

        try {
            if (uploadFile.exists()) {
                uploadFile.delete();
            }
            uploadFile.createNewFile();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //图片压缩，不需要的可屏蔽
        if (fileSize > 3 * 1024 * 1024) {
            compressBitmap(file.getAbsolutePath(), uploadFile, 4);
        } else if (fileSize > 2 * 1024 * 1024){
            compressBitmap(file.getAbsolutePath(), uploadFile, 3);
        } else if (fileSize > 1024 * 1024) {
            compressBitmap(file.getAbsolutePath(), uploadFile, 2);
        } else {
            uploadFile = file;
        }
        requestFile = RequestBody.create(MediaType.parse("image/*"), uploadFile);
        return MultipartBody.Part.createFormData("file", file.getName(), requestFile);
    }

    public static RequestBody provideFormValue(String value) {
        return RequestBody.create(MediaType.parse("multipart/form-data"), value);
    }

    private static void compressBitmap(String filePath, File file, int inSampleSize) {
        // 数值越高，图片像素越低
        BitmapFactory.Options options = new BitmapFactory.Options();
        //采样率
        options.inSampleSize = inSampleSize;
        Bitmap bitmap = BitmapFactory.decodeFile(filePath, options);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // 把压缩后的数据存放到baos中
        bitmap.compress(Bitmap.CompressFormat.JPEG, 95 ,baos);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(baos.toByteArray());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String fileOpera() {
        String sdPath = SDCardUtils.getSDCardPathByEnvironment();
        String savePath;
        if (sdPath != null && !"".equals(sdPath)) {
            if (!sdPath.endsWith(File.separator)) {
                savePath = sdPath + CommonDataUtil.CHANGE_IMAGE_PATH;
            } else {
                savePath = sdPath + File.separator + CommonDataUtil.CHANGE_IMAGE_PATH;
            }
        } else {
            savePath = Environment.getDownloadCacheDirectory().getAbsolutePath() + CommonDataUtil.CHANGE_IMAGE_PATH;
        }

        File file = new File(savePath);
        if (!file.exists() && !file.mkdirs()) {
            savePath = savePath + File.separator;
        }

        return savePath;
    }
}
