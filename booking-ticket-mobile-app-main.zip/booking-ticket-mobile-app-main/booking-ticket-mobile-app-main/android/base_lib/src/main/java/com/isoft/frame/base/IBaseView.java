package com.isoft.frame.base;

import com.trello.rxlifecycle.LifecycleTransformer;

/**
 * Created by long on 2016/8/23.
 * 基础 BaseView 接口
 */
public interface IBaseView {

    /**
     * 显示加载动画
     */
    void showLoading();

    /**
     * 隐藏加载
     */
    void hideLoading();

    /**
     * 显示网络错误，modify 对网络异常在 BaseActivity 和 BaseFragment 统一处理
     */
    void showNetError();
    /**
     * 显示数据为空的情况，modify 对数据为空的情况在 BaseActivity 和 BaseFragment 统一处理
     */
    void showNoData();

    /**
     * 显示数据为空的情况，显示自定义的页面
     * modify 对数据为空的情况在 BaseActivity 和 BaseFragment 统一处理
     * @param state EmptyLayout的枚举值.比如 EmptyLayout.STATUS_NO_DATA
     */
    void showOtherView(int state);

    /**
     * 绑定生命周期
     * @param <T>
     * @return
     */
    <T> LifecycleTransformer<T> bindToLife();

    /**
     * 完成刷新, 新增控制刷新
     */
    void finishRefresh();
}
