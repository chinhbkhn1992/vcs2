# Project Title

Amway Booking - Tikcet Inspection App (Android & IOS)


## Release

#### IOS 1.8.1

* Re-achitecture mobile solution.
* merging all market code into one.
* New country/language selection page added.

#### Android 1.8.1

* Re-achitecture mobile solution.
* merging all market code into one.
* New country/language selection page added.