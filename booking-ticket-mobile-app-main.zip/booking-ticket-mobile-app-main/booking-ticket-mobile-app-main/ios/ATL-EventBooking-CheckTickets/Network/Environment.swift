//
//  Environment.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by Tung Giim Horng - iss malaysia team on 15/07/2021.
//  Copyright © 2021 莫至钊. All rights reserved.
//

import Foundation

public enum PlistKey {
    case baseURL, baseURLIndia
    
    func value() -> String {
        switch self {
        case .baseURL:
            return "baseURL"
        case .baseURLIndia:
            return "baseURLIndia"
        }
    }
}

public struct Environment {
    
    fileprivate var infoDict: [String: Any]  {
        get {
            if let dict = Bundle.main.infoDictionary {
                return dict
            }else {
                fatalError("Plist file not found")
            }
        }
    }
    
    public func configuration(_ key: PlistKey) -> String {
        switch key {
        case .baseURL:
            return infoDict[PlistKey.baseURL.value()] as! String
        case .baseURLIndia:
            return infoDict[PlistKey.baseURLIndia.value()] as! String
        }
    }
}
