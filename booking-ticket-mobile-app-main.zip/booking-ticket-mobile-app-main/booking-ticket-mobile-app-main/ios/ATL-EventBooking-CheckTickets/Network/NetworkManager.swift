//
//  NetworkManager.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/30.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import Alamofire

// MARK:master版本域名
//fileprivate let baseURL = "https://bookingapi-qa.amway.com"
//fileprivate let baseURL = "https://bookingapi-dv.amway.com" // dev
//fileprivate let baseURL = "https://bookingapi.amway.com" // PD


typealias NetworkResult = (NetworkManager.NetworkResponse) -> Void

class NetworkManager {
    struct NetworkResponse {
        let isSuccess: Bool
        let jsonValue: [String:Any]?
        let errorCode: Int
        let errorString: String?
        init(_ jsonValue: [String:Any]?, _ errorCode: Int?, errorString: String?) {
            isSuccess = errorCode == 1
            self.errorCode = errorCode == nil ? -100 : errorCode!
            self.jsonValue = jsonValue
            self.errorString = errorString
        }
    }
    
    static var isQA: Bool {
        get {
            let baseURL = Environment().configuration(PlistKey.baseURL)
            return baseURL == "https://event-api-qa.amwaynet.com.tw"
        }
    }
    
    fileprivate static var _manager: Alamofire.SessionManager?
    static var manager: Alamofire.SessionManager? {
        if _manager == nil {
            let config = URLSessionConfiguration.default
            config.timeoutIntervalForRequest = 20.0
            _manager = Alamofire.SessionManager.init(configuration: config)
            return _manager
        }
        return _manager
    }
    
    static func POST(_ path: String, _ parmeters: Parameters? = nil, _ reuslt: @escaping NetworkResult) {
        var headers = SessionManager.defaultHTTPHeaders
        var userAgent = headers["User-Agent"];
        let appVersion = getCurrentVersion()
        let iosVersion = getSystemVersion()
        let model = getCurrentModel()
        
        userAgent?.append(contentsOf: "_iOS/")
        userAgent?.append(contentsOf: "\(appVersion)/")
        userAgent?.append(contentsOf: "\(model)/")
        userAgent?.append(contentsOf: "\(iosVersion)")
        headers["User-Agent"] = userAgent
        
        var baseURL = Environment().configuration(PlistKey.baseURL)
        if (SettingManager.getCurrentRegionName() == "India") {
            baseURL = Environment().configuration(PlistKey.baseURLIndia)
        }
        
        manager?.request(baseURL + path, method: .post, parameters: parmeters, encoding: JSONEncoding.default, headers: headers).responseJSON(completionHandler: { response in
            var networkResponse: NetworkResponse
            switch response.result {
            case .success:
                let jsonValue = response.result.value as! [String : Any]
                let resultCode = jsonValue["resultCode"] as? Int
                let errorStr = jsonValue["resultMsg"] as? String
                networkResponse = NetworkResponse(jsonValue, resultCode, errorString: errorStr)
            case .failure:
                networkResponse = NetworkResponse(nil, -100, errorString: "网络异常")
            }
            reuslt(networkResponse)
        })
    }
    
    static func POSTRL(_ path: String,  _ reuslt: @escaping NetworkResult) {
        let username = "event"
        let password = "event123"
        
        //let credentialData = "\(username):\(password)".dataUsingEncoding(String.Encoding.utf8)!
        let credentialData = "\(username):\(password)".data(using: .utf8)!
        let base64Credentials = credentialData.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64Credentials)"]
        
        let baseURL = Environment().configuration(PlistKey.baseURL)
        
        manager?.request(baseURL + path, method: .post, encoding: JSONEncoding.default, headers: headers).responseJSON(completionHandler: { response in
            var networkResponse: NetworkResponse
            switch response.result {
            case .success:
                let jsonValue = response.result.value as! [String : Any]
                let resultCode = jsonValue["resultCode"] as? Int
                let errorStr = jsonValue["resultMsg"] as? String
                networkResponse = NetworkResponse(jsonValue, resultCode, errorString: errorStr)
            case .failure:
                networkResponse = NetworkResponse(nil, -100, errorString: "网络异常")
            }
            reuslt(networkResponse)
        })
    }
}

// MARK:台湾接口
extension NetworkManager {
    
    /// 获取人员名单
    ///
    /// - Parameters:
    ///   - eventID: 活动的ID
    ///   - role: 获取人员的身份- "ABO"代表ABO， "CUS"代表普通顾客, "ALL"代表两种身份都获取
    ///   - currentPage: 当前的页数
    ///   - totalPerPage: 每页的总条数
    ///   - result: 回调
    static func getAttendeeList(_ eventID: String, _ role: String, _ currentPage: Int, _ totalPerPage: Int, _ orderBy: String, _ isDesc: Bool, _ search: String, _ result: @escaping NetworkResult) {
        let parmeters: [String:Any] = [
            "eventID" : eventID,
            "role" : role,
            "currentPage" : currentPage,
            "totalPerPage" : totalPerPage,
            "orderBy" : orderBy,
            "isDesc" : isDesc,
            "search" : search
        ]
        
        let getAttendeeListPath: String
        
        switch SettingManager.getCurrentRegionName() {
        case "Japan":
            getAttendeeListPath = "/japan/ticketcheckApi/v1/ticket/getAttendeeList"
        case "Việt Nam":
            getAttendeeListPath = "/vietnam/ticketcheckApi/v1/ticket/getAttendeeList"
        case "Malaysia":
            getAttendeeListPath = "/my/ticketcheckApi/v1/ticket/getAttendeeList"
        case "Singapore":
            getAttendeeListPath = "/sg/ticketcheckApi/v1/ticket/getAttendeeList"
        case "Brunei":
            getAttendeeListPath = "/bn/ticketcheckApi/v1/ticket/getAttendeeList"
        case "India":
            getAttendeeListPath = "/admin/ticketcheckApi/v1/ticket/getAttendeeList"
        default:
            //Master
            getAttendeeListPath = "/master/ticketcheckApi/v1/ticket/getAttendeeList"
        }
        
        POST(getAttendeeListPath, parmeters, result)
    }
    
    /// 通过二维码检验门派票
    ///
    /// - Parameters:
    ///   - qrCode: 门票二维码
    ///   - result: 回调
    static func checkIn(_ qrCode: String, _ eventID: String, _ result: @escaping NetworkResult) {
        let parmeters: [String: Any] = [
            "qrCode" : qrCode,
            "eventID" : eventID
        ]
        
        let checkInPath: String
        
        switch SettingManager.getCurrentRegionName() {
        case "Japan":
            checkInPath = "/japan/ticketcheckApi/v1/ticket/checkin"
        case "Việt Nam":
            checkInPath = "/vietnam/ticketcheckApi/v1/ticket/checkin"
        case "Malaysia":
            checkInPath = "/my/ticketcheckApi/v1/ticket/checkin"
        case "Singapore":
            checkInPath = "/sg/ticketcheckApi/v1/ticket/checkin"
        case "Brunei":
            checkInPath = "/bn/ticketcheckApi/v1/ticket/checkin"
        case "India":
            checkInPath = "/admin/ticketcheckApi/v1/ticket/checkin"
        default:
            //Master
            checkInPath = "/master/ticketcheckApi/v1/ticket/checkin"
        }
        
        POST(checkInPath, parmeters, result)
    }
    
    /// 获取活动详情信息
    ///
    /// - Parameters:
    ///   - regionCode: 场地编码
    ///   - eventID: 活动ID
    ///   - result: 回调
    static func checkinEventDetail(_ regionCode: String, _ eventID: String, _ result: @escaping NetworkResult) {
        let parmeters: [String: Any] = [
            "regionCode" : regionCode,
            "eventID" : eventID
        ]
        
        let checkinEventDetailPath: String
        
        switch SettingManager.getCurrentRegionName() {
        case "Japan":
            checkinEventDetailPath = "/japan/ticketcheckApi/v1/ticket/checkinEventDetail"
        case "Việt Nam":
            checkinEventDetailPath = "/vietnam/ticketcheckApi/v1/ticket/checkinEventDetail"
        case "Malaysia":
            checkinEventDetailPath = "/my/ticketcheckApi/v1/ticket/checkinEventDetail"
        case "Singapore":
            checkinEventDetailPath = "/sg/ticketcheckApi/v1/ticket/checkinEventDetail"
        case "Brunei":
            checkinEventDetailPath = "/bn/ticketcheckApi/v1/ticket/checkinEventDetail"
        case "India":
            checkinEventDetailPath = "/admin/ticketcheckApi/v1/ticket/checkinEventDetail"
        default:
            //Master
            checkinEventDetailPath = "/master/ticketcheckApi/v1/ticket/checkinEventDetail"
        }
        
        POST(checkinEventDetailPath, parmeters, result)
    }
    
    /// 获取语言地区信息
    ///
    /// - Parameters:
    ///   - result: 回调
    static func getRegionLanguageList(_ result: @escaping NetworkResult) {
        //let parmeters: [String: Any] = [:]
        
        let getRegionLanguageListPath: String
        
        getRegionLanguageListPath = "/master/openservice/login/v1/getLanguageInfo"
        
        //POSTRL(getRegionLanguageListPath, parmeters, result)
        POSTRL(getRegionLanguageListPath, result)
    }
    
    /// 获取地区信息
    ///
    /// - Parameters:
    ///   - result: 回调
    static func getRegionList(_ result: @escaping NetworkResult) {
        //let parmeters: [String: Any] = [:]
        
        let getRegionListPath: String
        
        getRegionListPath = "/master/openservice/login/v1/getApplicationInfosForApp"
        
        //POSTRL(getRegionListPath, parmeters, result)
        POSTRL(getRegionListPath, result)
    }
}

