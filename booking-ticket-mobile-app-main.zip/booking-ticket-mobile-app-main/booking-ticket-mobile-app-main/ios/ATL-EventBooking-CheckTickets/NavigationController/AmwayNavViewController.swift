//
//  AmwayNavViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/19.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

class AmwayNavViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        initNavBar()
    }
    
    func initNavBar() {
        if #available(iOS 15.0, *) {                  // UINavigationBarAppearance start from iOS13
            let app = UINavigationBarAppearance.init()
            app.configureWithOpaqueBackground()       // Set background and shadow color
            app.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20)]
            app.backgroundColor = hexColor(0x002F5F)  // Set background color of nav bar
            //app.shadowImage = UIColor.clear.image   // Set bottom shadow of nav bar
            navigationBar.scrollEdgeAppearance = app  // Scroll page
            navigationBar.standardAppearance = app    // Standard page
        } else {
            self.navigationBar.isTranslucent = false
            self.navigationBar.barTintColor = hexColor(0x002F5F)
            self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 20)]
        }
    }
}

