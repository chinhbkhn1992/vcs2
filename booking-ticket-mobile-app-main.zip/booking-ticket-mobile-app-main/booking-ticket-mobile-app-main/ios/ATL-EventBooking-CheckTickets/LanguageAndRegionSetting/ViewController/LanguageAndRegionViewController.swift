//
//  LanguageAndRegionViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by Tung Giim Horng - iss malaysia team on 14/06/2021.
//  Copyright © 2021 莫至钊. All rights reserved.
//

import UIKit

class LanguageAndRegionViewController: UIViewController {
    
    @IBOutlet weak var regionLanguageView: UIView!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var selectAreaLabel: UILabel!
    @IBOutlet weak var regionLabel: UILabel!
    @IBOutlet weak var selectLanguageLabel: UILabel!
    @IBOutlet weak var languageLabel: UILabel!
    var languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
    var regionLocalList : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configNav()
        configLanguage()
        registerNotification()
        configDefSelect()
        
        if UserDefaults.standard.string(forKey: CurrentFirstTimeFlag) == "" {
            print("Tung 666")
            self.navigationItem.leftBarButtonItem = nil
            self.navigationItem.hidesBackButton = true
        }
        
        let server_url = Environment().configuration(PlistKey.baseURL)
        print(server_url)
        
        //switch SettingManager.getCurrentRegionName() {
        //case "Japan":
        //    self.languageSource = [SettingManager.Language.JapanLanguage.rawValue]
        //case "安利（中国）":
        //    self.languageSource = [SettingManager.Language.ChinaLanguage.rawValue, SettingManager.Language.TWLanguage.rawValue]
        //case "Việt Nam":
        //    self.languageSource = [SettingManager.Language.VietnameLanguage.rawValue, SettingManager.Language.EnglishLanguage.rawValue]
        //case "Malaysia":
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
        //case "Singapore":
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
        //case "Brunei":
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
        //default:
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
            
        //}
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        regionLanguageView.layer.masksToBounds = false
        regionLanguageView.layer.shadowOffset = .zero
        regionLanguageView.layer.shadowColor = UIColor(red: 144/255, green: 144/255, blue: 144/255, alpha: 1).cgColor
        regionLanguageView.layer.shadowRadius = 9.0
        regionLanguageView.layer.shadowOpacity = 0.7
        
        confirmButton.layer.masksToBounds = false
        confirmButton.layer.shadowOffset = .zero
        confirmButton.layer.shadowColor = UIColor(red: 144/255, green: 144/255, blue: 144/255, alpha: 1).cgColor
        confirmButton.layer.shadowRadius = 6.0
        confirmButton.layer.shadowOpacity = 0.7
    }
    
    func registerNotification() {
        NotificationCenter.default.addObserver(forName: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil, queue: OperationQueue.main) {
            [weak self] (notification) in
            self?.configLanguage()
        }
    }
    
    func configLanguage() {
        let imageView = UIImageView.init(image: pngImage(with: "logo"))
        self.navigationItem.titleView = imageView
        
        selectAreaLabel.text = SettingManager.value(for: "select area")
        selectLanguageLabel.text = SettingManager.value(for: "select language")
        self.confirmButton.setText(with: "confirm")
    }
    
    func configDefSelect() {
        regionLabel.text = SettingManager.getCurrentRegionName()
        languageLabel.text = SettingManager.getCurrentLanguageName()
    }
    
    @IBAction func selectRegionClick(_ sender: UIButton) {
        let regionArray = UserDefaults.standard.stringArray(forKey: "regionKey") ?? [String]()
        let applicationInfoRegionArray = UserDefaults.standard.stringArray(forKey: "applicationInfoRegionKey") ?? [String]()
        let regionNameArray = UserDefaults.standard.stringArray(forKey: "regionNameKey") ?? [String]()
        var source : [String]? = []
        
        if regionArray.contains("JP"){
            if let index = applicationInfoRegionArray.firstIndex(of: "JP") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.TW.rawValue)
        }
        
        if regionArray.contains("VN"){
            if let index = applicationInfoRegionArray.firstIndex(of: "VN") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Vietname.rawValue)
        }
        
        if regionArray.contains("SG"){
            if let index = applicationInfoRegionArray.firstIndex(of: "SG") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Singapore.rawValue)
        }
        
        if regionArray.contains("MY"){
            if let index = applicationInfoRegionArray.firstIndex(of: "MY") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Malaysia.rawValue)
        }
        
        if regionArray.contains("BN"){
            if let index = applicationInfoRegionArray.firstIndex(of: "BN") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Brunei.rawValue)
        }
        
        if regionArray.contains("IN"){
            if let index = applicationInfoRegionArray.firstIndex(of: "IN") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.India.rawValue)
        }
        
        //source = [SettingManager.Region.TW.rawValue, SettingManager.Region.Vietname.rawValue, SettingManager.Region.Brunei.rawValue, SettingManager.Region.Malaysia.rawValue, SettingManager.Region.Singapore.rawValue]
        
        SelectView.show(with: source ?? [""], selectType: .region, selectResult: {
            [weak self] (index) in
            
            if (source?.count ?? 0 > 0){
            self?.regionLabel.text = source?[index] ?? ""
            
            var region = ""
            if source?[index] != "" && source?[index] != nil {
                if let index = regionNameArray.firstIndex(of: source?[index] ?? "") {
                    region = applicationInfoRegionArray[index]
                }
                //SettingManager.setRegion(with: SettingManager.Region(rawValue: source?[index] ?? "")!)
            }
        
                
            switch region {
            case "JP":
                let def = UserDefaults.standard
                def.set(TWRegionCode, forKey: LocalRegionCodeKey)
                def.synchronize()
                
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.TW.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "japanDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "japanKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    print("TUNG 1")
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "japanKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    print("TUNG 2")
                    self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.JapanLanguage.rawValue]
                }
                
            case "安利（中国）":
                let def = UserDefaults.standard
                def.set(ChinaRegionCode, forKey: LocalRegionCodeKey)
                def.synchronize()
                
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "othersDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "othersKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "othersKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                        self?.languageSource.append(SettingManager.Language.TWLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.ChinaLanguage.rawValue, SettingManager.Language.TWLanguage.rawValue]
                }
                
            case "VN":
                let def = UserDefaults.standard
                def.set(TWRegionCode, forKey: LocalRegionCodeKey)
                def.synchronize()
                
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Vietname.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "vietnamDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "vietnamKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "vietnamKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.VietnameLanguage.rawValue, SettingManager.Language.EnglishLanguage.rawValue]
                }
                
            case "MY":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Malaysia.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "malaysiaDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "malaysiaKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "malaysiaKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
                }
                
            case "SG":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Singapore.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "singaporeDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "singaporeKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "singaporeKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
                }
                
            case "BN":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Brunei.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "bruneiDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "bruneiKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "bruneiKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
                }
               
            case "IN":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.India.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "indiaDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "indiaKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "indiaKey") ?? [String]()
                    self?.languageSource = []
                    if languageArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if languageArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
                }
                
            default:
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "singaporeDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "singaporeKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if langArray?.count !=  0{
                        if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                            self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                            self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                            self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                            self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                            self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                        }
                        
                        let languageArray = UserDefaults.standard.stringArray(forKey: "singaporeKey") ?? [String]()
                        self?.languageSource = []
                        if languageArray.contains("JP"){
                            self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                        }
                        
                        if languageArray.contains("EN"){
                            self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                        }
                        
                        if languageArray.contains("VN"){
                            self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                        }
                        
                        if languageArray.contains("CN"){
                            self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                        }

                        if languageArray.contains("IN"){
                            self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                        }

                    }
                                        
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
                }
                
            }
            }
        })
    }
    
    @IBAction func selectLanguageClick(_ sender: UIButton) {
        if SettingManager.getCurrentRegionName() == "" {
            let alert = UIAlertController(title: SettingManager.value(for: "Please select Region first"), message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: SettingManager.value(for: "confirm"), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            SelectView.show(with: self.languageSource, selectType: .language, selectResult: {
                [weak self] (index) in
                self?.languageLabel.text = self?.languageSource[index]
                SettingManager.setLanguage(with: SettingManager.Language(rawValue: self?.languageSource[index] ?? "")!)
            })
        }
    }
    
    @IBAction func confirmClick(_ sender: Any) {
        let regionArray = UserDefaults.standard.stringArray(forKey: "regionKey") ?? [String]()
        let applicationInfoRegionArray = UserDefaults.standard.stringArray(forKey: "applicationInfoRegionKey") ?? [String]()
        regionLocalList = []
        
        if regionArray.contains("JP") && applicationInfoRegionArray.contains("JP") {
            regionLocalList.append(SettingManager.Region.TW.rawValue)
        }
        
        if regionArray.contains("VN") && applicationInfoRegionArray.contains("VN") {
            regionLocalList.append(SettingManager.Region.Vietname.rawValue)
        }
        
        if regionArray.contains("SG") && applicationInfoRegionArray.contains("SG") {
            regionLocalList.append(SettingManager.Region.Singapore.rawValue)
        }
        
        if regionArray.contains("MY") && applicationInfoRegionArray.contains("MY") {
            regionLocalList.append(SettingManager.Region.Malaysia.rawValue)
        }
        
        if regionArray.contains("BN") && applicationInfoRegionArray.contains("BN") {
            regionLocalList.append(SettingManager.Region.Brunei.rawValue)
        }
        
        if regionArray.contains("IN") && applicationInfoRegionArray.contains("IN") {
            regionLocalList.append(SettingManager.Region.India.rawValue)
        }
        
        if SettingManager.getCurrentRegionName() == "" {
            let alert = UIAlertController(title: SettingManager.value(for: "Please select Region and Laguage"), message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: SettingManager.value(for: "confirm"), style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            //if let _arr = UserDefaults.standard.stringArray(forKey: "vietnamKey") {
            //    print("TUNG 1: ", _arr)
            //}
        }else{
            //let regionArray = UserDefaults.standard.stringArray(forKey: "regionKey") ?? [String]()
            
            if regionLocalList.count > 0 && regionLocalList.contains(SettingManager.getCurrentRegionName()) {
                UserDefaults.standard.set("Y", forKey: CurrentFirstTimeFlag)
                UserDefaults.standard.synchronize()
                self.navigationController?.popViewController(animated: false)
            } else {
                let alert = UIAlertController(title: SettingManager.value(for: "Network error. Please try again after checking the network"), message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: SettingManager.value(for: "confirm"), style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            
            //if let _arr = UserDefaults.standard.stringArray(forKey: "vietnamKey") {
            //    print("TUNG 1: ", _arr)
            //}
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil)
    }
}
