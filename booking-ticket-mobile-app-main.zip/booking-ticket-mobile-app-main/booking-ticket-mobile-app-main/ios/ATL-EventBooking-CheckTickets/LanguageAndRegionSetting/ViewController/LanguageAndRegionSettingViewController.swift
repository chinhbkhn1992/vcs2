//
//  LanguageAndRegionSettingViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/22.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

class LanguageAndRegionSettingViewController: UIViewController {

    @IBOutlet weak var regionLabel: UILabel!
    @IBOutlet weak var languageLabel: UILabel!
    @IBOutlet weak var selectAreaLabel: UILabel!
    @IBOutlet weak var selectLanguageLabel: UILabel!
    @IBOutlet weak var selectRepeatScanLabel: UILabel!
    @IBOutlet weak var repeatScanLabel: UILabel!
    var languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configNav()
        configLanguage()
        registerNotification()
        configDefSelect()
        
        //print("Tung 11:" + SettingManager.getCurrentRegionName())
        //print("Tung 12:" + SettingManager.getCurrentRegionCode())
        //print("Tung 13:" + SettingManager.getCurrentLanguageName())
        //let def = UserDefaults.standard
        //let currentLanguage = def.value(forKey: LocalLanguageKey) as? String ?? ""
        //print("Tung 14:" + currentLanguage)
        
        //switch SettingManager.getCurrentRegionName() {
        //case "Japan":
        //    self.languageSource = [SettingManager.Language.JapanLanguage.rawValue]
        //case "安利（中国）":
        //    self.languageSource = [SettingManager.Language.ChinaLanguage.rawValue, SettingManager.Language.TWLanguage.rawValue]
        //case "Việt Nam":
        //    self.languageSource = [SettingManager.Language.VietnameLanguage.rawValue, SettingManager.Language.EnglishLanguage.rawValue]
        //case "Malaysia":
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
        //case "Singapore":
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
        //case "Brunei":
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
        //default:
        //    self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
        //}
        
        switch SettingManager.getCurrentRegionName() {
        case "Japan":
            
            if (UserDefaults.standard.stringArray(forKey: "japanKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "japanKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.JapanLanguage.rawValue]
            }
        case "安利（中国）":
            
            if (UserDefaults.standard.stringArray(forKey: "othersKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "othersKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    self.languageSource.append(SettingManager.Language.TWLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.ChinaLanguage.rawValue, SettingManager.Language.TWLanguage.rawValue]
            }
        case "Việt Nam":
            
            if (UserDefaults.standard.stringArray(forKey: "vietnamKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "vietnamKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.VietnameLanguage.rawValue, SettingManager.Language.EnglishLanguage.rawValue]
            }
        case "Malaysia":
            
            if (UserDefaults.standard.stringArray(forKey: "malaysiaKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "malaysiaKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
            }
        case "Singapore":
            
            if (UserDefaults.standard.stringArray(forKey: "singaporeKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "singaporeKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
            }
        case "Brunei":
            
            if (UserDefaults.standard.stringArray(forKey: "bruneiKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "bruneiKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
            }
        case "India":
            
            if (UserDefaults.standard.stringArray(forKey: "indiaKey")?.count ?? 0) > 0 {
                
                let languageArray = UserDefaults.standard.stringArray(forKey: "indiaKey") ?? [String]()
                self.languageSource = []
                if languageArray.contains("JP"){
                    self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                }
                
                if languageArray.contains("EN"){
                    self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                }
                
                if languageArray.contains("VN"){
                    self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                }
                
                if languageArray.contains("CN"){
                    self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                }
                
                if languageArray.contains("IN"){
                    self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                }
                
            } else {
                self.languageSource = [SettingManager.Language.IndiaLanguage.rawValue]
            }
        default:
            
            if (UserDefaults.standard.stringArray(forKey: "singaporeKey")?.count ?? 0) > 0 {
                let langArray = UserDefaults.standard.stringArray(forKey: "singaporeKey")
                
                if langArray?.count != 0 {
                    
                    let languageArray = UserDefaults.standard.stringArray(forKey: "singaporeKey") ?? [String]()
                    self.languageSource = []
                    if languageArray.contains("JP"){
                        self.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if languageArray.contains("EN"){
                        self.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if languageArray.contains("VN"){
                        self.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if languageArray.contains("CN"){
                        self.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }

                    if languageArray.contains("IN"){
                        self.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                }
                                    
            } else {
                self.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
            }
            
        }
    }
    
    func registerNotification() {
        NotificationCenter.default.addObserver(forName: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil, queue: OperationQueue.main) {
            [weak self] (notification) in
            self?.configLanguage()
        }
    }
    
    func configLanguage() {
        self.navigationItem.title = SettingManager.value(for: "setting")
        selectAreaLabel.text = SettingManager.value(for: "select area")
        selectLanguageLabel.text = SettingManager.value(for: "select language")
        selectRepeatScanLabel.text = SettingManager.value(for: "repeat scan")
    }
    
    func configDefSelect() {
        regionLabel.text = SettingManager.getCurrentRegionName()
        languageLabel.text = SettingManager.getCurrentLanguageName()
        repeatScanLabel.text = SettingManager.getCurrentRepeatScanName()
    }
    
    @IBAction func selectRegionClick(_ sender: UIButton) {
        let regionArray = UserDefaults.standard.stringArray(forKey: "regionKey") ?? [String]()
        let applicationInfoRegionArray = UserDefaults.standard.stringArray(forKey: "applicationInfoRegionKey") ?? [String]()
        let regionNameArray = UserDefaults.standard.stringArray(forKey: "regionNameKey") ?? [String]()
        var source : [String]? = []
        
        if regionArray.contains("JP") {
            if let index = applicationInfoRegionArray.firstIndex(of: "JP") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.TW.rawValue)
        }
        
        if regionArray.contains("VN") {
            if let index = applicationInfoRegionArray.firstIndex(of: "VN") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Vietname.rawValue)
        }
        
        if regionArray.contains("SG") {
            if let index = applicationInfoRegionArray.firstIndex(of: "SG") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Singapore.rawValue)
        }
        
        if regionArray.contains("MY") {
            if let index = applicationInfoRegionArray.firstIndex(of: "MY") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Malaysia.rawValue)
        }
        
        if regionArray.contains("BN"){
            if let index = applicationInfoRegionArray.firstIndex(of: "BN") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Brunei.rawValue)
        }
        
        if regionArray.contains("IN"){
            if let index = applicationInfoRegionArray.firstIndex(of: "IN") {
                source?.append(regionNameArray[index])
            }
            //source?.append(SettingManager.Region.Brunei.rawValue)
        }
        
        //let source = [SettingManager.Region.TW.rawValue, SettingManager.Region.Vietname.rawValue, SettingManager.Region.Brunei.rawValue, SettingManager.Region.Malaysia.rawValue, SettingManager.Region.Singapore.rawValue]
        
        SelectView.show(with: source ?? [""], selectType: .region, selectResult: {
            [weak self] (index) in
            
            if (source?.count ?? 0 > 0){
            self?.regionLabel.text = source?[index]
            
            var region = ""
            if source?[index] != "" && source?[index] != nil {
                if let index = regionNameArray.firstIndex(of: source?[index] ?? "") {
                    region = applicationInfoRegionArray[index]
                }
                //SettingManager.setRegion(with: SettingManager.Region(rawValue: source?[index] ?? "")!)
            }
            
            switch region {
            case "JP":
                let def = UserDefaults.standard
                def.set(TWRegionCode, forKey: LocalRegionCodeKey)
                def.synchronize()
                
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.TW.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "japanDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "japanKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    print("TUNG 1")
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "japanKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    print("TUNG 2")
                    self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.JapanLanguage.rawValue]
                }
            case "安利（中国）":
                let def = UserDefaults.standard
                def.set(ChinaRegionCode, forKey: LocalRegionCodeKey)
                def.synchronize()
                
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "othersDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "othersKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "othersKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                        self?.languageSource.append(SettingManager.Language.TWLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.ChinaLanguage.rawValue, SettingManager.Language.TWLanguage.rawValue]
                }
            case "VN":
                let def = UserDefaults.standard
                def.set(TWRegionCode, forKey: LocalRegionCodeKey)
                def.synchronize()
                
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Vietname.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "vietnamDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "vietnamKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "vietnamKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.VietnameLanguage.rawValue, SettingManager.Language.EnglishLanguage.rawValue]
                }
            case "MY":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Malaysia.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "malaysiaDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "malaysiaKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "malaysiaKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
                }
            case "SG":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Singapore.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "singaporeDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "singaporeKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "singaporeKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
                }
            case "BN":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.Brunei.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "bruneiDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "bruneiKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "bruneiKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.ChinaLanguage.rawValue]
                }
            case "IN":
                SettingManager.setRegion(with: SettingManager.Region(rawValue: SettingManager.Region.India.rawValue)!)
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "indiaDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "indiaKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                        self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                        self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                        self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                        self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                    } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                        self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                        SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                    }
                    
                    let regionArray = UserDefaults.standard.stringArray(forKey: "indiaKey") ?? [String]()
                    self?.languageSource = []
                    if regionArray.contains("JP"){
                        self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                    }
                    
                    if regionArray.contains("EN"){
                        self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                    }
                    
                    if regionArray.contains("VN"){
                        self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                    }
                    
                    if regionArray.contains("CN"){
                        self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                    }
                    
                    if regionArray.contains("IN"){
                        self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                    }
                    
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
                }
            default:
                if let isDefaultIndex = UserDefaults.standard.array(forKey: "singaporeDefaultCodeKey") as? [Int] {
                    let langArray = UserDefaults.standard.stringArray(forKey: "singaporeKey")
                    let index = isDefaultIndex.firstIndex(of: 1)
                    
                    if langArray?.count !=  0{
                        if (langArray?[index ?? 0] as AnyObject).isEqual("JP"){
                            self?.languageLabel.text = SettingManager.Language.JapanLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.JapanLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("EN"){
                            self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("VN"){
                            self?.languageLabel.text = SettingManager.Language.VietnameLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.VietnameLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("CN"){
                            self?.languageLabel.text = SettingManager.Language.ChinaLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.ChinaLanguage.rawValue)!)
                        
                        } else if (langArray?[index ?? 0] as AnyObject).isEqual("IN"){
                            self?.languageLabel.text = SettingManager.Language.IndiaLanguage.rawValue
                            SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.IndiaLanguage.rawValue)!)
                        
                        }
                        
                        let regionArray = UserDefaults.standard.stringArray(forKey: "singaporeKey") ?? [String]()
                        self?.languageSource = []
                        if regionArray.contains("JP"){
                            self?.languageSource.append(SettingManager.Language.JapanLanguage.rawValue)
                        }
                        
                        if regionArray.contains("EN"){
                            self?.languageSource.append(SettingManager.Language.EnglishLanguage.rawValue)
                        }
                        
                        if regionArray.contains("VN"){
                            self?.languageSource.append(SettingManager.Language.VietnameLanguage.rawValue)
                        }
                        
                        if regionArray.contains("CN"){
                            self?.languageSource.append(SettingManager.Language.ChinaLanguage.rawValue)
                        }

                        if regionArray.contains("IN"){
                            self?.languageSource.append(SettingManager.Language.IndiaLanguage.rawValue)
                        }
                    }
                                        
                } else {
                    self?.languageLabel.text = SettingManager.Language.EnglishLanguage.rawValue
                    SettingManager.setLanguage(with: SettingManager.Language(rawValue: SettingManager.Language.EnglishLanguage.rawValue)!)
                    self?.languageSource = [SettingManager.Language.EnglishLanguage.rawValue]
                }
                
            }
                self?.configDefSelect()
            }
        })
    }
    
    @IBAction func selectLanguageClick(_ sender: UIButton) {
        //let source = [SettingManager.Language.JapanLanguage.rawValue, SettingManager.Language.EnglishLanguage.rawValue, SettingManager.Language.VietnameLanguage.rawValue,SettingManager.Language.ChinaLanguage.rawValue]
        
        SelectView.show(with: self.languageSource, selectType: .language, selectResult: {
            [weak self] (index) in
            self?.languageLabel.text = self?.languageSource[index]
            SettingManager.setLanguage(with: SettingManager.Language(rawValue: self?.languageSource[index] ?? "")!)
        })
    }
    
    @IBAction func clickRepeatScan(_ sender: Any) {
        let source = [SettingManager.RepeatScan.open, SettingManager.RepeatScan.close]
        let sourceName = source.map {
            return SettingManager.value(for: $0.rawValue)
        }
        SelectView.show(with: sourceName, selectType: .repeatScan) { (index) in
            self.repeatScanLabel.text = sourceName[index]
            SettingManager.setRepeatScan(with: source[index])
        }
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil)
    }
}
