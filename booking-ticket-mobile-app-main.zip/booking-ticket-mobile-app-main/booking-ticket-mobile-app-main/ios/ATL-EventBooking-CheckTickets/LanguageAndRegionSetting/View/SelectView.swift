//
//  SelectView.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/22.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

typealias SelectResult = (Int) -> Void

class SelectView: UIView, UIPickerViewDelegate, UIPickerViewDataSource {
    
    enum SelectType {
        case language, region, repeatScan
    }
    
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var confirmButton: UIButton!
    var source: [String] = []
    var resultIndex = 0
    var selectResult: SelectResult?
    var type: SelectType?

    
    @discardableResult static func show(with source: [String], selectType: SelectType, selectResult: @escaping SelectResult) -> SelectView {
        let window = getWindow()
        let maskView = UIView.init(frame: window.bounds)
        maskView.backgroundColor = rgba(r: 0, g: 0, b: 0, a: 0.4)
        window.addSubview(maskView)
        let selectView = Bundle.main.loadNibNamed("SelectView", owner: nil, options: nil)?.first as! SelectView
        maskView.addSubview(selectView)
        selectView.snp.makeConstraints {
            $0.width.equalToSuperview()
            $0.height.equalTo(334)
            $0.left.equalTo(0)
            $0.bottom.equalTo(0)
        }
        selectView.type = selectType
        selectView.source = source
        selectView.pickerView.delegate = selectView
        selectView.initLanguage()
        selectView.selectResult = selectResult
        return selectView
    }
    
    func dismiss() {
        self.superview?.removeFromSuperview()
    }
    
    @IBAction fileprivate func dismissClick(_ sender: UIButton) {
        self.dismiss()
    }
    
    @IBAction func confirmClick(_ sender: Any) {
        if let result = self.selectResult {
            result(self.resultIndex)
        }
        self.dismiss()
    }
    
    // MARK:pickerViewDelegate
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.source.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40.0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.source[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let view = UIView.init(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 40))
        let sepView = UIView.init(frame: CGRect(x: 60, y: 39, width: screenWidth - 120, height: 1))
        sepView.backgroundColor = hexColor(0xE3E3E3)
        view.addSubview(sepView)
        let label = UILabel.init()
        view.addSubview(label)
        label.snp.makeConstraints {
            $0.centerY.equalToSuperview().offset(-0.5)
            $0.centerX.equalToSuperview()
        }
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = hexColor(0x1A1A1A)
        label.text = self.source[row]
        return view
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.resultIndex = row
    }
    
    func initLanguage() {
        var value = ""
        switch type {
        case .language:
            value = "select language"
        case .region:
            value = "select area"
        case .repeatScan:
            value = "repeat scan"
        default:
            value = ""
        }
        self.typeLabel.setText(with: value)
        self.confirmButton.setText(with: "confirm")
    }
}



