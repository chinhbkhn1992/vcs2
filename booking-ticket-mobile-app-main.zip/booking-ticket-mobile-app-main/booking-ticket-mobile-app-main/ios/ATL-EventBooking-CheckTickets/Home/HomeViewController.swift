//
//  HomeViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/9/16.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    fileprivate var ATLVC: ATLActivityVenueInformationViewController?
    fileprivate var ACCLNavIndex: Int?
    fileprivate var isLayout = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UserDefaults.standard.string(forKey: CurrentFirstTimeFlag) == "" {
            //self.clickLanguage()
            let regionLanguageVC = LanguageAndRegionViewController()
            navigationController?.pushViewController(regionLanguageVC, animated: true)
        }
        
        self.configNotification()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if !isLayout {
            configSubVC()
            _configNav()
            isLayout = true
        }
    }
    
    fileprivate func configSubVC() {
        ATLVC = ATLActivityVenueInformationViewController.init()
        if let _ATLVC = ATLVC {
            _ATLVC.view.frame = self.view.bounds
            self.view.addSubview(_ATLVC.view)
            self.addChild(_ATLVC)
            self.regionChange()
        }
    }
    
    fileprivate func regionChange() {
        let currentRegion = SettingManager.Region(rawValue: SettingManager.getCurrentRegionName())
        if currentRegion == .TW {
            let imageView = UIImageView.init(image: pngImage(with: "logo"))
            self.navigationItem.titleView = imageView
        } else {
            self.navigationItem.titleView = nil
            self.navigationItem.title = "Amway"
            //self.navigationItem.setText(with: "Electronic ticket check-in system")
        }
        self.ATLVC?.view.isHidden = currentRegion == .China
    }
    
    func configNotification() {
        NotificationCenter.default.addObserver(forName: SettingManager.REGION_CHANGE_POST_NAME, object: nil, queue: OperationQueue.main) {
            [unowned self] (no) in
            self.regionChange()
        }
        NotificationCenter.default.addObserver(forName: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil, queue: OperationQueue.main) {
            [unowned self] (notification) in
            self.configACCLNavTitle()
        }
    }
    
    func configACCLNavTitle() {
        if ATLVC!.view.isHidden {
            let navTitle = self.ACCLNavIndex == 2 ? "Sets the latest information" : "Electronic ticket check-in system"
            self.navigationItem.setText(with: navTitle)
            if self.ACCLNavIndex == 0 {
                self._configNav()
            } else {
                self.navigationItem.rightBarButtonItem = nil
            }
        }
    }
    
    // MARK:configView
    fileprivate func _configNav() {
        let rigthItem = UIBarButtonItem.init(image: pngImage(with: "icon_setting")?.withRenderingMode(.alwaysOriginal), style: UIBarButtonItem.Style.plain, target: self, action: #selector(HomeViewController.clickLanguage))
        self.navigationItem.rightBarButtonItem = rigthItem
    }
    
    @objc fileprivate func clickLanguage() {
        let languageSettingVC = LanguageAndRegionSettingViewController()
        self.navigationController?.pushViewController(languageSettingVC, animated: true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: SettingManager.REGION_CHANGE_POST_NAME, object: nil)
    }
}
