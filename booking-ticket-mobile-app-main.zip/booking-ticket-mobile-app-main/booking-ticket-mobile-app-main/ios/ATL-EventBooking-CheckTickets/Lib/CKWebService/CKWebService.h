#import <Foundation/Foundation.h>
#import "USAdditions.h"
#import <libxml/tree.h>
#import "USGlobals.h"
@class CKWebService_Notice;
@class CKWebService_ArrayOfNameValue;
@class CKWebService_NameValue;
@class CKWebService_NoticeResponse;
@class CKWebService_CheckTicket;
@class CKWebService_ETickReturnValue;
@class CKWebService_CheckTicketResponse;
@class CKWebService_WsSecurityHeader;
@class CKWebService_DownLoadActivity;
@class CKWebService_CheckingTicketDTO;
@class CKWebService_ArrayOfCheckingTicketDTO;
@class CKWebService_DownLoadActivityResponse;
@class CKWebService_DownLoadActivityForMobile;
@class CKWebService_ActivityInfoForMobileDTO;
@class CKWebService_DownLoadActivityForMobileResponse;
@class CKWebService_UploadActivity;
@class CKWebService_UploadActivityResponse;
@class CKWebService_OnlineTest;
@class CKWebService_OnlineTestResponse;
@class CKWebService_GetAppVersion;
@class CKWebService_GetAppVersionResponse;
@interface CKWebService_NameValue : NSObject {
	
/* elements */
	NSString * Name;
	NSString * Value;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_NameValue *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * Name;
@property (retain) NSString * Value;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_ArrayOfNameValue : NSObject {
	
/* elements */
	NSMutableArray *NameValue;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_ArrayOfNameValue *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
- (void)addNameValue:(CKWebService_NameValue *)toAdd;
@property (readonly) NSMutableArray * NameValue;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_Notice : NSObject {
	
/* elements */
	NSString * recordId;
	NSString * workflowInfoId;
	NSString * empNumber;
	NSNumber * AgileEventType;
	NSString * agileWorkCode;
	CKWebService_ArrayOfNameValue * customAttribute;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_Notice *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * recordId;
@property (retain) NSString * workflowInfoId;
@property (retain) NSString * empNumber;
@property (retain) NSNumber * AgileEventType;
@property (retain) NSString * agileWorkCode;
@property (retain) CKWebService_ArrayOfNameValue * customAttribute;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_NoticeResponse : NSObject {
	
/* elements */
	USBoolean * NoticeResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_NoticeResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) USBoolean * NoticeResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_CheckTicket : NSObject {
	
/* elements */
	NSString * activityID;
	NSString * ticketNumber;
	NSString * checkIP;
	NSString * machineName;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_CheckTicket *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * activityID;
@property (retain) NSString * ticketNumber;
@property (retain) NSString * checkIP;
@property (retain) NSString * machineName;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_ETickReturnValue : NSObject {
	
/* elements */
	NSNumber * Result;
	NSNumber * UsedCount;
	NSString * Message;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_ETickReturnValue *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSNumber * Result;
@property (retain) NSNumber * UsedCount;
@property (retain) NSString * Message;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_CheckTicketResponse : NSObject {
	
/* elements */
	CKWebService_ETickReturnValue * CheckTicketResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_CheckTicketResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) CKWebService_ETickReturnValue * CheckTicketResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_WsSecurityHeader : NSObject {
	
/* elements */
	NSString * AppId;
	NSString * AppKey;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_WsSecurityHeader *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * AppId;
@property (retain) NSString * AppKey;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_DownLoadActivity : NSObject {
	
/* elements */
	NSString * activitySN;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_DownLoadActivity *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * activitySN;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_CheckingTicketDTO : NSObject {
	
/* elements */
	NSString * RecordID;
	NSString * ActivitySN;
	NSString * ActivityName;
	NSNumber * IsRealName;
	NSString * TicketID;
	NSString * TicketSN;
	NSNumber * TicketStatus;
	NSDate * CheckingTime;
	NSString * AdaCard;
	NSString * AdaName;
	NSString * CheckinIP;
	NSString * MachineName;
	NSString * CheckingType;
	NSNumber * Mark;
	NSString * ApplyCity;
	NSString * ApplyName;
	NSString * BackString;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_CheckingTicketDTO *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * RecordID;
@property (retain) NSString * ActivitySN;
@property (retain) NSString * ActivityName;
@property (retain) NSNumber * IsRealName;
@property (retain) NSString * TicketID;
@property (retain) NSString * TicketSN;
@property (retain) NSNumber * TicketStatus;
@property (retain) NSDate * CheckingTime;
@property (retain) NSString * AdaCard;
@property (retain) NSString * AdaName;
@property (retain) NSString * CheckinIP;
@property (retain) NSString * MachineName;
@property (retain) NSString * CheckingType;
@property (retain) NSNumber * Mark;
@property (retain) NSString * ApplyCity;
@property (retain) NSString * ApplyName;
@property (retain) NSString * BackString;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_ArrayOfCheckingTicketDTO : NSObject {
	
/* elements */
	NSMutableArray *CheckingTicketDTO;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_ArrayOfCheckingTicketDTO *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
- (void)addCheckingTicketDTO:(CKWebService_CheckingTicketDTO *)toAdd;
@property (readonly) NSMutableArray * CheckingTicketDTO;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_DownLoadActivityResponse : NSObject {
	
/* elements */
	CKWebService_ArrayOfCheckingTicketDTO * DownLoadActivityResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_DownLoadActivityResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) CKWebService_ArrayOfCheckingTicketDTO * DownLoadActivityResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_DownLoadActivityForMobile : NSObject {
	
/* elements */
	NSString * activitySN;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_DownLoadActivityForMobile *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * activitySN;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_ActivityInfoForMobileDTO : NSObject {
	
/* elements */
	NSString * RecordID;
	NSString * ActivitySN;
	NSString * ActivityName;
	NSNumber * IsRealName;
	NSNumber * TicketCount;
	NSNumber * UsedTicketCount;
	NSString * ApplyCity;
	NSString * ApplyName;
	NSString * BackString;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_ActivityInfoForMobileDTO *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * RecordID;
@property (retain) NSString * ActivitySN;
@property (retain) NSString * ActivityName;
@property (retain) NSNumber * IsRealName;
@property (retain) NSNumber * TicketCount;
@property (retain) NSNumber * UsedTicketCount;
@property (retain) NSString * ApplyCity;
@property (retain) NSString * ApplyName;
@property (retain) NSString * BackString;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_DownLoadActivityForMobileResponse : NSObject {
	
/* elements */
	CKWebService_ActivityInfoForMobileDTO * DownLoadActivityForMobileResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_DownLoadActivityForMobileResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) CKWebService_ActivityInfoForMobileDTO * DownLoadActivityForMobileResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_UploadActivity : NSObject {
	
/* elements */
	CKWebService_ArrayOfCheckingTicketDTO * ticketList;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_UploadActivity *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) CKWebService_ArrayOfCheckingTicketDTO * ticketList;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_UploadActivityResponse : NSObject {
	
/* elements */
	USBoolean * UploadActivityResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_UploadActivityResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) USBoolean * UploadActivityResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_OnlineTest : NSObject {
	
/* elements */
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_OnlineTest *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_OnlineTestResponse : NSObject {
	
/* elements */
	USBoolean * OnlineTestResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_OnlineTestResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) USBoolean * OnlineTestResult;
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_GetAppVersion : NSObject {
	
/* elements */
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_GetAppVersion *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
/* attributes */
- (NSDictionary *)attributes;
@end
@interface CKWebService_GetAppVersionResponse : NSObject {
	
/* elements */
	NSString * GetAppVersionResult;
/* attributes */
}
- (NSString *)nsPrefix;
- (xmlNodePtr)xmlNodeForDoc:(xmlDocPtr)doc elementName:(NSString *)elName elementNSPrefix:(NSString *)elNSPrefix;
- (void)addAttributesToNode:(xmlNodePtr)node;
- (void)addElementsToNode:(xmlNodePtr)node;
+ (CKWebService_GetAppVersionResponse *)deserializeNode:(xmlNodePtr)cur;
- (void)deserializeAttributesFromNode:(xmlNodePtr)cur;
- (void)deserializeElementsFromNode:(xmlNodePtr)cur;
/* elements */
@property (retain) NSString * GetAppVersionResult;
/* attributes */
- (NSDictionary *)attributes;
@end
/* Cookies handling provided by http://en.wikibooks.org/wiki/Programming:WebObjects/Web_Services/Web_Service_Provider */
#import <libxml/parser.h>
#import "xsd.h"
#import "CKWebService.h"
@class CKWebServiceSoapBinding;
@class CKWebServiceSoap12Binding;
@interface CKWebService : NSObject {
	
}
/**do not use this method, it applys only to QA environment*/
+ (CKWebServiceSoapBinding *)CKWebServiceSoapBinding;
/**do not use this method, it applys only to QA environment*/
+ (CKWebServiceSoap12Binding *)CKWebServiceSoap12Binding;
@end
@class CKWebServiceSoapBindingResponse;
@class CKWebServiceSoapBindingOperation;
@protocol CKWebServiceSoapBindingResponseDelegate <NSObject>
- (void) operation:(CKWebServiceSoapBindingOperation *)operation completedWithResponse:(CKWebServiceSoapBindingResponse *)response;
@end
@interface CKWebServiceSoapBinding : NSObject <CKWebServiceSoapBindingResponseDelegate> {
	NSURL *address;
	NSTimeInterval defaultTimeout;
	NSMutableArray *cookies;
	BOOL logXMLInOut;
	BOOL synchronousOperationComplete;
	NSString *authUsername;
	NSString *authPassword;
}
@property (copy) NSURL *address;
@property (assign) BOOL logXMLInOut;
@property (assign) NSTimeInterval defaultTimeout;
@property (nonatomic, retain) NSMutableArray *cookies;
@property (nonatomic, retain) NSString *authUsername;
@property (nonatomic, retain) NSString *authPassword;
- (id)initWithAddress:(NSString *)anAddress;
- (void)sendHTTPCallUsingBody:(NSString *)body soapAction:(NSString *)soapAction forOperation:(CKWebServiceSoapBindingOperation *)operation;
- (void)addCookie:(NSHTTPCookie *)toAdd;
- (CKWebServiceSoapBindingResponse *)NoticeUsingParameters:(CKWebService_Notice *)aParameters ;
- (void)NoticeAsyncUsingParameters:(CKWebService_Notice *)aParameters  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoapBindingResponse *)CheckTicketUsingParameters:(CKWebService_CheckTicket *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)CheckTicketAsyncUsingParameters:(CKWebService_CheckTicket *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoapBindingResponse *)DownLoadActivityUsingParameters:(CKWebService_DownLoadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)DownLoadActivityAsyncUsingParameters:(CKWebService_DownLoadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoapBindingResponse *)DownLoadActivityForMobileUsingParameters:(CKWebService_DownLoadActivityForMobile *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)DownLoadActivityForMobileAsyncUsingParameters:(CKWebService_DownLoadActivityForMobile *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoapBindingResponse *)UploadActivityUsingParameters:(CKWebService_UploadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)UploadActivityAsyncUsingParameters:(CKWebService_UploadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoapBindingResponse *)OnlineTestUsingParameters:(CKWebService_OnlineTest *)aParameters ;
- (void)OnlineTestAsyncUsingParameters:(CKWebService_OnlineTest *)aParameters  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoapBindingResponse *)GetAppVersionUsingParameters:(CKWebService_GetAppVersion *)aParameters ;
- (void)GetAppVersionAsyncUsingParameters:(CKWebService_GetAppVersion *)aParameters  delegate:(id<CKWebServiceSoapBindingResponseDelegate>)responseDelegate;
@end
@interface CKWebServiceSoapBindingOperation : NSOperation {
	CKWebServiceSoapBinding *binding;
	CKWebServiceSoapBindingResponse *response;
	id<CKWebServiceSoapBindingResponseDelegate> delegate;
	NSMutableData *responseData;
	NSURLConnection *urlConnection;
}
@property (retain) CKWebServiceSoapBinding *binding;
@property (readonly) CKWebServiceSoapBindingResponse *response;
@property (nonatomic, assign) id<CKWebServiceSoapBindingResponseDelegate> delegate;
@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSURLConnection *urlConnection;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate;
@end
@interface CKWebServiceSoapBinding_Notice : CKWebServiceSoapBindingOperation {
	CKWebService_Notice * parameters;
}
@property (retain) CKWebService_Notice * parameters;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_Notice *)aParameters
;
@end
@interface CKWebServiceSoapBinding_CheckTicket : CKWebServiceSoapBindingOperation {
	CKWebService_CheckTicket * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_CheckTicket * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_CheckTicket *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoapBinding_DownLoadActivity : CKWebServiceSoapBindingOperation {
	CKWebService_DownLoadActivity * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_DownLoadActivity * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_DownLoadActivity *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoapBinding_DownLoadActivityForMobile : CKWebServiceSoapBindingOperation {
	CKWebService_DownLoadActivityForMobile * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_DownLoadActivityForMobile * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_DownLoadActivityForMobile *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoapBinding_UploadActivity : CKWebServiceSoapBindingOperation {
	CKWebService_UploadActivity * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_UploadActivity * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_UploadActivity *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoapBinding_OnlineTest : CKWebServiceSoapBindingOperation {
	CKWebService_OnlineTest * parameters;
}
@property (retain) CKWebService_OnlineTest * parameters;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_OnlineTest *)aParameters
;
@end
@interface CKWebServiceSoapBinding_GetAppVersion : CKWebServiceSoapBindingOperation {
	CKWebService_GetAppVersion * parameters;
}
@property (retain) CKWebService_GetAppVersion * parameters;
- (id)initWithBinding:(CKWebServiceSoapBinding *)aBinding delegate:(id<CKWebServiceSoapBindingResponseDelegate>)aDelegate
	parameters:(CKWebService_GetAppVersion *)aParameters
;
@end
@interface CKWebServiceSoapBinding_envelope : NSObject {
}
+ (CKWebServiceSoapBinding_envelope *)sharedInstance;
- (NSString *)serializedFormUsingHeaderElements:(NSDictionary *)headerElements bodyElements:(NSDictionary *)bodyElements;
@end
@interface CKWebServiceSoapBindingResponse : NSObject {
	NSArray *headers;
	NSArray *bodyParts;
	NSError *error;
}
@property (retain) NSArray *headers;
@property (retain) NSArray *bodyParts;
@property (retain) NSError *error;
@end
@class CKWebServiceSoap12BindingResponse;
@class CKWebServiceSoap12BindingOperation;
@protocol CKWebServiceSoap12BindingResponseDelegate <NSObject>
- (void) operation:(CKWebServiceSoap12BindingOperation *)operation completedWithResponse:(CKWebServiceSoap12BindingResponse *)response;
@end
@interface CKWebServiceSoap12Binding : NSObject <CKWebServiceSoap12BindingResponseDelegate> {
	NSURL *address;
	NSTimeInterval defaultTimeout;
	NSMutableArray *cookies;
	BOOL logXMLInOut;
	BOOL synchronousOperationComplete;
	NSString *authUsername;
	NSString *authPassword;
}
@property (copy) NSURL *address;
@property (assign) BOOL logXMLInOut;
@property (assign) NSTimeInterval defaultTimeout;
@property (nonatomic, retain) NSMutableArray *cookies;
@property (nonatomic, retain) NSString *authUsername;
@property (nonatomic, retain) NSString *authPassword;
- (id)initWithAddress:(NSString *)anAddress;
- (void)sendHTTPCallUsingBody:(NSString *)body soapAction:(NSString *)soapAction forOperation:(CKWebServiceSoap12BindingOperation *)operation;
- (void)addCookie:(NSHTTPCookie *)toAdd;
- (CKWebServiceSoap12BindingResponse *)NoticeUsingParameters:(CKWebService_Notice *)aParameters ;
- (void)NoticeAsyncUsingParameters:(CKWebService_Notice *)aParameters  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoap12BindingResponse *)CheckTicketUsingParameters:(CKWebService_CheckTicket *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)CheckTicketAsyncUsingParameters:(CKWebService_CheckTicket *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoap12BindingResponse *)DownLoadActivityUsingParameters:(CKWebService_DownLoadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)DownLoadActivityAsyncUsingParameters:(CKWebService_DownLoadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoap12BindingResponse *)DownLoadActivityForMobileUsingParameters:(CKWebService_DownLoadActivityForMobile *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)DownLoadActivityForMobileAsyncUsingParameters:(CKWebService_DownLoadActivityForMobile *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoap12BindingResponse *)UploadActivityUsingParameters:(CKWebService_UploadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader ;
- (void)UploadActivityAsyncUsingParameters:(CKWebService_UploadActivity *)aParameters WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoap12BindingResponse *)OnlineTestUsingParameters:(CKWebService_OnlineTest *)aParameters ;
- (void)OnlineTestAsyncUsingParameters:(CKWebService_OnlineTest *)aParameters  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
- (CKWebServiceSoap12BindingResponse *)GetAppVersionUsingParameters:(CKWebService_GetAppVersion *)aParameters ;
- (void)GetAppVersionAsyncUsingParameters:(CKWebService_GetAppVersion *)aParameters  delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)responseDelegate;
@end
@interface CKWebServiceSoap12BindingOperation : NSOperation {
	CKWebServiceSoap12Binding *binding;
	CKWebServiceSoap12BindingResponse *response;
	id<CKWebServiceSoap12BindingResponseDelegate> delegate;
	NSMutableData *responseData;
	NSURLConnection *urlConnection;
}
@property (retain) CKWebServiceSoap12Binding *binding;
@property (readonly) CKWebServiceSoap12BindingResponse *response;
@property (nonatomic, assign) id<CKWebServiceSoap12BindingResponseDelegate> delegate;
@property (nonatomic, retain) NSMutableData *responseData;
@property (nonatomic, retain) NSURLConnection *urlConnection;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate;
@end
@interface CKWebServiceSoap12Binding_Notice : CKWebServiceSoap12BindingOperation {
	CKWebService_Notice * parameters;
}
@property (retain) CKWebService_Notice * parameters;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_Notice *)aParameters
;
@end
@interface CKWebServiceSoap12Binding_CheckTicket : CKWebServiceSoap12BindingOperation {
	CKWebService_CheckTicket * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_CheckTicket * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_CheckTicket *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoap12Binding_DownLoadActivity : CKWebServiceSoap12BindingOperation {
	CKWebService_DownLoadActivity * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_DownLoadActivity * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_DownLoadActivity *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoap12Binding_DownLoadActivityForMobile : CKWebServiceSoap12BindingOperation {
	CKWebService_DownLoadActivityForMobile * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_DownLoadActivityForMobile * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_DownLoadActivityForMobile *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoap12Binding_UploadActivity : CKWebServiceSoap12BindingOperation {
	CKWebService_UploadActivity * parameters;
	CKWebService_WsSecurityHeader * WsSecurityHeader;
}
@property (retain) CKWebService_UploadActivity * parameters;
@property (retain) CKWebService_WsSecurityHeader * WsSecurityHeader;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_UploadActivity *)aParameters
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
	WsSecurityHeader:(CKWebService_WsSecurityHeader *)aWsSecurityHeader
;
@end
@interface CKWebServiceSoap12Binding_OnlineTest : CKWebServiceSoap12BindingOperation {
	CKWebService_OnlineTest * parameters;
}
@property (retain) CKWebService_OnlineTest * parameters;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_OnlineTest *)aParameters
;
@end
@interface CKWebServiceSoap12Binding_GetAppVersion : CKWebServiceSoap12BindingOperation {
	CKWebService_GetAppVersion * parameters;
}
@property (retain) CKWebService_GetAppVersion * parameters;
- (id)initWithBinding:(CKWebServiceSoap12Binding *)aBinding delegate:(id<CKWebServiceSoap12BindingResponseDelegate>)aDelegate
	parameters:(CKWebService_GetAppVersion *)aParameters
;
@end
@interface CKWebServiceSoap12Binding_envelope : NSObject {
}
+ (CKWebServiceSoap12Binding_envelope *)sharedInstance;
- (NSString *)serializedFormUsingHeaderElements:(NSDictionary *)headerElements bodyElements:(NSDictionary *)bodyElements;
@end
@interface CKWebServiceSoap12BindingResponse : NSObject {
	NSArray *headers;
	NSArray *bodyParts;
	NSError *error;
}
@property (retain) NSArray *headers;
@property (retain) NSArray *bodyParts;
@property (retain) NSError *error;
@end
