//
//  AppDelegate.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/19.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.initWindow()
        SettingManager.regionAndLanguage()
        initGlobal()
        return true
    }

    // 初始化window
    func initWindow() {
        self.window = UIWindow.init(frame: UIScreen.main.bounds)
        self.window?.backgroundColor = UIColor.white
        self.window?.makeKeyAndVisible()
        let homeVC = HomeViewController.init()
        let navVC = AmwayNavViewController.init(rootViewController: homeVC)
        self.window?.rootViewController = navVC
    }
    
    // 初始化全局变量
    func initGlobal() {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        IQKeyboardManager.shared.enableAutoToolbar = false
    }

}

