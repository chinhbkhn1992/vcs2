//
//  MuteDetector.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2021/2/4.
//  Copyright © 2021 莫至钊. All rights reserved.
//

import UIKit
import AudioToolbox

class MuteDetector: NSObject {
    
    static let shared: MuteDetector = {
        let path = Bundle.main.path(forResource: "mute", ofType: "m4a")
        let url = URL(fileURLWithPath: path!)
        var detector = MuteDetector()
        let status = AudioServicesCreateSystemSoundID(url as CFURL, &detector.soundID)
        if status == kAudioServicesNoError {
            AudioServicesAddSystemSoundCompletion(detector.soundID, CFRunLoopGetMain(), CFRunLoopMode.defaultMode.rawValue, completionProc, Unmanaged.passUnretained(detector).toOpaque())
            var yes = 1
            AudioServicesSetProperty(kAudioServicesPropertyIsUISound, UInt32(MemoryLayout<SystemSoundID>.size), &detector.soundID, UInt32(MemoryLayout<Bool>.size), &yes)
        } else {
            detector.soundID = .max
        }
        return detector
    }()
 
    static let completionProc: AudioServicesSystemSoundCompletionProc = {(soundID: SystemSoundID, p: UnsafeMutableRawPointer?) in
        let elapsed = Date.timeIntervalSinceReferenceDate - shared.interval
        let isMute = elapsed < 0.1
        shared.completion(isMute)
    }
    
    var completion = { (mute: Bool) in }
 
    var soundID: SystemSoundID = 1312
    
    var interval: TimeInterval = 1
    
    func detect(block: @escaping (Bool) -> ()) {
        interval = NSDate.timeIntervalSinceReferenceDate
        AudioServicesPlaySystemSound(soundID)
        completion = block
    }
    
    deinit {
        if (soundID != .max) {
            AudioServicesRemoveSystemSoundCompletion(soundID);
            AudioServicesDisposeSystemSoundID(soundID);
        }
    }
}
