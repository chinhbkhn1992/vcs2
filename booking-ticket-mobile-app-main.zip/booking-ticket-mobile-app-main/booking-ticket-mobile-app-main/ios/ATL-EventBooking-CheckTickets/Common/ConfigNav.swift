//
//  ConfigNav.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/22.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import UIKit

typealias backAction = () -> Void

extension UIViewController {
    func configNav() {
        let backItem = UIBarButtonItem.init(image: pngImage(with: "back")?.withRenderingMode(.alwaysOriginal), style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.back))
        self.navigationItem.leftBarButtonItem = backItem
    }
    
    @objc func back() {
        self.navigationController?.popViewController(animated: true)
    }
}
