//
//  ScanQrCodeView.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/22.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit
import AVFoundation


class ATLScanQrCodeView: UIView {
    
    var scan_interval = 2.0;
    
    var scanManager: ScanQrCodeManager?
    var scanResult: ScanResultBlock?
    var timer: Timer?
    lazy var lineImageView: UIImageView = UIImageView.init()
    var lineY: Float = 0.0
    var isDown = true
    var needContinueScan = false
    var canScan = false
    var isLayOut = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        initConfig()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initConfig()
    }
    
    override func layoutSubviews() {
        superview?.layoutSubviews()
        if !isLayOut {
            isLayOut = true
            let layer = self.layer.sublayers?.first
            layer?.frame = self.bounds
            let width = self.bounds.size.width
            let heigth = (width * 6.0) / 460.0
            lineImageView.frame = CGRect(x: 0, y: 0, width: width, height: heigth)
        }
    }
    
    fileprivate func initConfig() {
        configSubView()
        canScan = initAV()
    }
    
    fileprivate func initAV() -> Bool {
        guard
            let scanManager = ScanQrCodeManager(scanResult: {
            [weak self] in
            self?.scanResult(with: $0)
        }),
            let layer = scanManager.getVideoLayer()
        else {
            return false
        }
        self.scanManager = scanManager
        initVideoLayer(with: layer)
        return true
    }
    
    fileprivate func configSubView() {
        let borderImageView = UIImageView.init()
        self.addSubview(borderImageView)
        borderImageView.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.left.equalToSuperview()
            $0.width.equalToSuperview()
            $0.height.equalToSuperview()
        }
        borderImageView.image = pngImage(with: "frame")
        
        let width = self.bounds.size.width
        let heigth = (width * 6.0) / 460.0
        lineImageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: width, height: heigth))
        lineImageView.image = pngImage(with: "scan_line")
        self.addSubview(lineImageView)
    }
    
    
    func startScan(_ scanResult: @escaping ScanResultBlock) -> Bool {
        guard canScan else {
            return false
        }
        self.scanResult = scanResult
        scanManager?.startScan()
        startScanLineAnimaion()
        return true
    }
    
    func stopScan() {
        self.scanResult = nil
        stopScanLineAnimation()
        scanManager?.stopScan()
    }
    
    func continueScan() {
        self.scanManager?.startScan()
        startScanLineAnimaion()
    }
    
    fileprivate func initVideoLayer(with videoLayer: AVCaptureVideoPreviewLayer) {
        videoLayer.frame = self.bounds
        self.layer.insertSublayer(videoLayer, at: 0)
    }
    
    fileprivate func scanResult(with result: String) {
//        scanManager?.stopScan()
        scanResult?(result)
//        stopScanLineAnimation()
//        if needContinueScan {
//            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + scan_interval) {
//                [weak self] in
//                self?.scanManager?.startScan()
//            }
//        }
    }
    
    fileprivate func startScanLineAnimaion() {
        if timer == nil {
            timer = Timer.init(timeInterval: 0.01, target: self, selector: #selector(scanLineAnimation), userInfo: nil, repeats: true)
            RunLoop.current.add(timer!, forMode: RunLoop.Mode.common)
            timer?.fire()
        }
    }
    
    fileprivate func stopScanLineAnimation() {
        timer?.invalidate()
        timer = nil
    }
    
    @objc fileprivate func scanLineAnimation() {
        
        let totalY = self.bounds.size.height
        if isDown {
            lineY += 1
            if lineY >= Float(totalY) {
                lineY = Float(totalY)
                isDown = false
            }
        } else {
            lineY -= 1
            if lineY <= 0 {
                lineY = 0
                isDown = true
            }
        }
        var rect = lineImageView.frame
        rect.origin.y = CGFloat(lineY)
        lineImageView.frame = rect
    }
}
