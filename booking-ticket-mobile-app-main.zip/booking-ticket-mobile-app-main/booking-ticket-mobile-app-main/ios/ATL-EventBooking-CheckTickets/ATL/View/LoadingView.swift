//
//  LoadingView.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2020/12/24.
//  Copyright © 2020 莫至钊. All rights reserved.
//

import UIKit

class LoadingView: UIView {

    static func show() {
        let view = UIView.init(frame: UIScreen.main.bounds)
        view.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.6)
        let imageWidth = 50.0
        let imageHight = 50.0
        let imageView = UIImageView.init(frame: CGRect(x: (Double(screenWidth) - imageWidth) / 2.0, y: (Double(screenHeight) - imageHight) / 2.0, width: imageWidth, height: imageHight))
        imageView.image = UIImage.init(named: "Ticket App Loading")
        imageView.tag = 100
        view.addSubview(imageView)
        let label = UILabel.init()
        label.text = "Loading"
        label.textColor = hexColor(0x002F5F)
        label.sizeToFit()
        let labelSize = label.bounds
        label.frame = CGRect(x: (screenWidth - labelSize.width) / 2.0, y: (screenHeight - labelSize.height) / 2.0 + 40.0, width: labelSize.width, height: labelSize.height)
        view.addSubview(label)
        let window = UIApplication.shared.delegate?.window as? UIWindow
        view.tag = 10086
        window?.addSubview(view)
        let animaiton = CABasicAnimation.init(keyPath: "transform.rotation.z")
        animaiton.toValue = Double.pi * 2.0
        animaiton.duration = 2.0
        animaiton.isCumulative = true
        animaiton.repeatCount = HUGE
        imageView.layer.add(animaiton, forKey: "animaiton")
    }
    
    static func dismiss() {
        let window = UIApplication.shared.delegate?.window as? UIWindow
        let view = window?.viewWithTag(10086)
        view?.viewWithTag(100)?.layer.removeAllAnimations()
        view?.removeFromSuperview()
    }
}
