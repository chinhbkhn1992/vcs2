//
//  RegionLanguage.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by Tung Giim Horng - iss malaysia team on 22/06/2021.
//  Copyright © 2021 莫至钊. All rights reserved.
//

import Foundation
import HandyJSON

class RegionLanguageModel: HandyJSON {
    
    class ListModel: HandyJSON {
        var applicationCode: String?
        var langCode: String?
        var langName: String?
        var isDefault: Int?
        
        required init() {}
        
    }
    
    var resultCode: Int?
    var data: [ListModel] = []
    var count: Int {
        return data.count
    }
    
    func clearData() {
        data.removeAll()
    }
    
    fileprivate func appendData(_ value: [RegionLanguageModel.ListModel]?) {
        if value != nil {
            data += value!
        }
    }
    
    required init() {}
    
}

extension RegionLanguageModel {
    
    static func getData(_ completion: @escaping (RegionLanguageModel?, Bool) -> Void) {
        NetworkManager.getRegionLanguageList() {
            (response) in
            let result = RegionLanguageModel.deserialize(from: response.jsonValue)
            print(response.jsonValue ?? "getRegionLanguageList no response")
            //print(UserDefaults.standard.stringArray(forKey: "regionKey")?.count ?? 00)
            
            let def = UserDefaults.standard
            if result?.resultCode != nil && result?.resultCode != 0 {
                var vietnamLangArray : [String] = []
                var japanLangArray : [String] = []
                var bruneiLangArray : [String] = []
                var singaporeLangArray : [String] = []
                var malaysiaLangArray : [String] = []
                var indiaLangArray : [String] = []
                var othersLangArray : [String] = []
                var vietnamDefaultCodeArray : [Int] = []
                var japanDefaultCodeArray : [Int] = []
                var bruneiDefaultCodeArray : [Int] = []
                var singaporeDefaultCodeArray : [Int] = []
                var malaysiaDefaultCodeArray : [Int] = []
                var indiaDefaultCodeArray : [Int] = []
                var othersDefaultCodeArray : [Int] = []
                
                var regionList : [String] = []
                let list = result?.data
                if let _list = list {
                    for model in _list {
                        if !regionList.contains(model.applicationCode ?? "") {
                            if (model.applicationCode ?? "") != ""{
                                regionList.append(model.applicationCode ?? "")
                            }
                        }
                    
                        switch model.applicationCode {
                        case "VN":
                            vietnamLangArray.append(model.langCode ?? "")
                            vietnamDefaultCodeArray.append(model.isDefault ?? 0)
                        case "SG":
                            singaporeLangArray.append(model.langCode ?? "")
                            singaporeDefaultCodeArray.append(model.isDefault ?? 0)
                        case "MY":
                            malaysiaLangArray.append(model.langCode ?? "")
                            malaysiaDefaultCodeArray.append(model.isDefault ?? 0)
                        case "BN":
                            bruneiLangArray.append(model.langCode ?? "")
                            bruneiDefaultCodeArray.append(model.isDefault ?? 0)
                        case "JP":
                            japanLangArray.append(model.langCode ?? "")
                            japanDefaultCodeArray.append(model.isDefault ?? 0)
                        case "IN":
                            indiaLangArray.append(model.langCode ?? "")
                            indiaDefaultCodeArray.append(model.isDefault ?? 0)
                        default:
                            othersLangArray.append(model.langCode ?? "")
                            othersDefaultCodeArray.append(model.isDefault ?? 0)
                        }
                    
                    }
                }
                
                for element in regionList {
                    print(element, terminator: " ")
                }
                print(regionList.count)
                
                def.set(vietnamLangArray, forKey: "vietnamKey")
                def.set(japanLangArray, forKey: "japanKey")
                def.set(bruneiLangArray, forKey: "bruneiKey")
                def.set(singaporeLangArray, forKey: "singaporeKey")
                def.set(malaysiaLangArray, forKey: "malaysiaKey")
                def.set(indiaLangArray, forKey: "indiaKey")
                def.set(othersLangArray, forKey: "othersKey")
                def.set(vietnamDefaultCodeArray, forKey: "vietnamDefaultCodeKey")
                def.set(japanDefaultCodeArray, forKey: "japanDefaultCodeKey")
                def.set(bruneiDefaultCodeArray, forKey: "bruneiDefaultCodeKey")
                def.set(singaporeDefaultCodeArray, forKey: "singaporeDefaultCodeKey")
                def.set(malaysiaDefaultCodeArray, forKey: "malaysiaDefaultCodeKey")
                def.set(indiaDefaultCodeArray, forKey: "indiaDefaultCodeKey")
                def.set(othersDefaultCodeArray, forKey: "othersDefaultCodeKey")
                def.set(regionList, forKey: "regionKey")
                def.synchronize()
            }
            
            completion(result, response.isSuccess)
        }
    }
    
}
