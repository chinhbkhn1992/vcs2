//
//  RegionLanguage.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by Tung Giim Horng - iss malaysia team on 22/06/2021.
//  Copyright © 2021 莫至钊. All rights reserved.
//

import Foundation
import HandyJSON

class RegionNameModel: HandyJSON {
    
    class ListModel: HandyJSON {
        var isWorkflow: Int?
        var applicationCode: String?
        var applicationNameEn: String?
        var aboSiteUrl: String?
        
        required init() {}
        
    }
    
    var resultCode: Int?
    var data: [ListModel] = []
    var count: Int {
        return data.count
    }
    
    func clearData() {
        data.removeAll()
    }
    
    fileprivate func appendData(_ value: [RegionNameModel.ListModel]?) {
        if value != nil {
            data += value!
        }
    }
    
    required init() {}
    
}

extension RegionNameModel {
    
    static func getData(_ completion: @escaping (RegionNameModel?, Bool) -> Void) {
        NetworkManager.getRegionList() {
            (response) in
            let result = RegionNameModel.deserialize(from: response.jsonValue)
            print(response.jsonValue ?? "getRegionNameList no response")
            //print(UserDefaults.standard.stringArray(forKey: "regionKey")?.count ?? 00)
            
            let def = UserDefaults.standard
            if result?.resultCode != nil && result?.resultCode != 0 {
                var regionNameArray : [String] = []
                
                var applicationInfoRegionList : [String] = []
                let list = result?.data
                if let _list = list {
                    for model in _list {
                        if !applicationInfoRegionList.contains(model.applicationCode ?? "") {
                            if (model.applicationCode ?? "") != ""{
                                if model.isWorkflow == 1 {
                                    applicationInfoRegionList.append(model.applicationCode ?? "")
                                    regionNameArray.append(model.applicationNameEn ?? "")
                                }
                            }
                        }
                    
                    }
                }
                
                for element in applicationInfoRegionList {
                    print(element, terminator: " ")
                }
                print(applicationInfoRegionList.count)
                
                for element in regionNameArray {
                    print(element, terminator: " ")
                }
                print(regionNameArray.count)
                
                def.set(regionNameArray, forKey: "regionNameKey")
                def.set(applicationInfoRegionList, forKey: "applicationInfoRegionKey")
                def.synchronize()
            }
            
            completion(result, response.isSuccess)
        }
    }
    
}
