//
//  CheckTicketsViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/23.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

fileprivate let CellID = "MemberListTableViewCell"

class ATLMemberListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    enum IdentityType: Int {
        case ABOIdentity = 1, customerIdentity, all
    }
    
    enum FilterType: Int {
        case All = 1, attendance, unregistered
    }
    
    @IBOutlet weak var admissionNumberLabel: UILabel!
    @IBOutlet weak var totalNumberLabel: UILabel!
    @IBOutlet weak var noEntryNumberLabel: UILabel!
    @IBOutlet weak var admissionRateProgressView: AdmissionRateProgressView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var ABOListTableView: UITableView!
    @IBOutlet weak var customerListTableView: UITableView!
    @IBOutlet weak var ABOLabel: UILabel!
    @IBOutlet weak var ABOHightLight: UIView!
    @IBOutlet weak var customerHightLight: UIView!
    @IBOutlet weak var customerLabel: UILabel!
    @IBOutlet weak var signUpLabel: UILabel!
    @IBOutlet weak var admissionLabel: UILabel!
    @IBOutlet weak var noAdmissionLabel: UILabel!
    @IBOutlet weak var admissionRateLabel: UILabel!
    @IBOutlet weak var ABOIDLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var TimeLabel: UILabel!
    @IBOutlet weak var nameViewLeft: NSLayoutConstraint!
    @IBOutlet weak var nameViewWidth: NSLayoutConstraint!
    @IBOutlet weak var timeViewWidth: NSLayoutConstraint!
    @IBOutlet weak var ABOIDViewWidth: NSLayoutConstraint!
    @IBOutlet weak var searchTextFiled: UITextField!
    @IBOutlet var sortImageViewArray: [UIImageView]!
    @IBOutlet var filterViewArr: [UIView]!
    
    var ABOListModel = ATLAttendeesModel(type: .ABO)
    var customerListModel = ATLAttendeesModel(type: .Customer)
    var showType: IdentityType = .ABOIdentity
    var filterType: FilterType? {
        didSet(newValue) {
            let highlightedNumberColor = hexColor(0x002F5F)
            let highlightedTitleColor = rgba(r: 26, g: 26, b: 26, a: 1)
            let normalColor = rgba(r: 173, g: 173, b: 173, a: 1)
            for i in 0..<filterViewArr.count {
                if let value = filterType?.rawValue {
                    let filterView = filterViewArr[i]
                    let titleLabel = filterView.viewWithTag(1) as! UILabel
                    let numberLabel = filterView.viewWithTag(2) as! UILabel
                    if value - 1 == i {
                        titleLabel.textColor = highlightedTitleColor
                        numberLabel.textColor = highlightedNumberColor
                    } else {
                        titleLabel.textColor = normalColor
                        numberLabel.textColor = normalColor
                    }
                }
            }
        }
    }
    var beforeFilterType: FilterType = .All
    var aboResultList = [ATLAttendeesModel.ListModel]()
    var customerResultList = [ATLAttendeesModel.ListModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        contentView.layer.borderColor = hexColor(0xE3E3E3).cgColor
        changeIdentity(with: .ABOIdentity)
        configTableView()
        initLanguage()
        filterType = .All
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ABOListModel.load(isAppend: false) {
            [weak self] in
            self?.reloadTable(with: .ABOIdentity)
        }
        customerListModel.load(isAppend: false) {
            [weak self] in
            self?.reloadTable(with: .customerIdentity)
        }
        ATLEventDetailModel.loadEventDetail(ATLEventDetailModel.currentRegionCode, ATLEventDetailModel.currentEventID) {
            [weak self] (model: ATLEventDetailModel?, isSuccess: Bool, isSession:Bool) in
            
            if isSuccess {
                self?.totalNumberLabel.text = model?.ticketsTotal
                self?.admissionNumberLabel.text = model?.checkinTotal
                self?.noEntryNumberLabel.text = model?.uncheckinTotal
                self?.admissionRateProgressView.progress(with: Int(model!.checkinTotal!) ?? 0, total: Int(model!.ticketsTotal!) ?? 0, rate: model?.checkinRate)
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        ABOListModel.clearData()
        customerListModel.clearData()
        changeIdentity(with: .ABOIdentity)
        self.reloadTable(with: .all)
        self.totalNumberLabel.text = "--"
        self.admissionNumberLabel.text = "--"
        self.noEntryNumberLabel.text = "--"
        self.admissionRateProgressView.progress(with: 0, total: 0, rate: nil)
    }
    
    @IBAction func changeIdentityClick(_ sender: UIButton) {
        let type = IdentityType(rawValue: sender.tag)
        if showType != type {
            showType = type ?? IdentityType.ABOIdentity
            changeIdentity(with: type!)
        }
    }
    
    func changeIdentity(with type: IdentityType) {
        ABOHightLight.isHidden = type == .customerIdentity
        ABOLabel.textColor = (type == .ABOIdentity) ? hexColor(0x002F5F) : hexColor(0x929292)
        customerHightLight.isHidden = type == .ABOIdentity
        customerLabel.textColor = (type == .customerIdentity) ? hexColor(0x002F5F) : hexColor(0x929292)
        ABOListTableView.isHidden = type == .customerIdentity
        customerListTableView.isHidden = type == .ABOIdentity
        let contentViewWidth = screenWidth - 20.0 - 20.0
        if type == .customerIdentity {
            ABOIDLabel.isHidden = true
            nameViewLeft.constant = -(contentViewWidth / 3.0)
            let width = contentViewWidth / 2.0
            nameViewWidth.constant = width
            timeViewWidth.constant = width
        } else {
            ABOIDLabel.isHidden = false
            nameViewLeft.constant = 0
            let width = contentViewWidth / 3.0
            nameViewWidth.constant = width
            timeViewWidth.constant = width
            ABOIDViewWidth.constant = width
            
        }
        let index = showType == .ABOIdentity ? ABOListModel.currentSortIndex : customerListModel.currentSortIndex
        sortChangeUI(index: index)
    }
    
    func configTableView() {
        ABOListTableView.register(UINib.init(nibName: String(describing: ATLMemberListTableViewCell.self), bundle: nil), forCellReuseIdentifier: CellID)
        customerListTableView.register(UINib.init(nibName: String(describing: ATLMemberListTableViewCell.self), bundle: nil), forCellReuseIdentifier: CellID)
        ABOListTableView.es.addInfiniteScrolling {
            [weak self] in
            if let _self = self {
                let isAppend = _self.ABOListModel.count > 0
                _self.ABOListModel.load(isAppend: isAppend, {
                    [weak self] in
                    self?.ABOListTableView.es.stopLoadingMore()
                    self?.reloadTable(with: .ABOIdentity)
                })
            }
        }
        customerListTableView.es.addInfiniteScrolling {
            [weak self] in
            if let _self = self {
                let isAppend = _self.customerListModel.count > 0
                _self.customerListModel.load(isAppend: isAppend, {
                    [weak self] in
                    self?.customerListTableView.es.stopLoadingMore()
                    self?.reloadTable(with: .customerIdentity)
                })
            }
        }
    }
    
    func reloadTable(with type: IdentityType) {
        aboResultList = ABOListModel.attendees
        customerResultList = customerListModel.attendees
        if filterType != .All {
            aboResultList = aboResultList.filter { (model) -> Bool in
                return filterType == .attendance ? model.checkinstatus == 1 : model.checkinstatus == 0
            }
            customerResultList = customerResultList.filter({ (model) -> Bool in
                return filterType == .attendance ? model.checkinstatus == 1 : model.checkinstatus == 0
            })
        }
        switch type {
        case .ABOIdentity:
            ABOListTableView.reloadData()
        case .customerIdentity:
            customerListTableView.reloadData()
        case .all:
            ABOListTableView.reloadData()
            customerListTableView.reloadData()
        }
    }
    
    func initLanguage() {
        signUpLabel.setText(with: "sign up")
        admissionLabel.setText(with: "admission")
        noAdmissionLabel.setText(with: "no admission")
        admissionRateLabel.setText(with: "admission rate", "{value}：")
        customerLabel.setText(with: "customer")
        ABOIDLabel.setText(with: "ABO ID")
        NameLabel.setText(with: "Name")
        TimeLabel.setText(with: "Time")
        searchTextFiled.placeholder = SettingManager.value(for: "Search Bar Placeholder")
    }
    
    @IBAction func searchClick(_ sender: Any) {
        LoadingView.show()
        let searchStr = searchTextFiled.text ?? ""
        
        ABOListModel.searchStr = searchStr
        customerListModel.searchStr = searchStr
        ATLAttendeesModel.searchAll(searchStr: searchStr, aboListModel: ABOListModel, customerListModel: customerListModel) {
            [weak self] (haveType) in
            LoadingView.dismiss()
            if let _weakSlef = self {
                switch haveType {
                    case .ABO:
                        if _weakSlef.showType == .customerIdentity {
                            _weakSlef.showType = .ABOIdentity
                        }
                        _weakSlef.reloadTable(with: .ABOIdentity)
                    case .Customer:
                        if _weakSlef.showType == .ABOIdentity {
                            _weakSlef.showType = .customerIdentity
                        }
                        _weakSlef.reloadTable(with: .customerIdentity)
                    case .ALL:
                        if _weakSlef.showType == .ABOIdentity {
                            _weakSlef.reloadTable(with: .ABOIdentity)
                        } else {
                            _weakSlef.reloadTable(with: .customerIdentity)
                        }
                }
                _weakSlef.changeIdentity(with: _weakSlef.showType)
            }
        }
    }
    
    @IBAction func sortClick(_ sender: UIButton) {
        let index = sender.tag - 1
        LoadingView.show()
        let listModel : ATLAttendeesModel
        if showType == .ABOIdentity {
            listModel = ABOListModel
        } else {
            listModel = customerListModel
        }
        listModel.sortArrary[index] = !listModel.sortArrary[index]
        sortChangeUI(index: index)
        listModel.clearData()
        listModel.load(isAppend: false) {
            [weak self] in
            if self?.showType == .ABOIdentity {
                self?.reloadTable(with: .ABOIdentity)
            } else {
                self?.reloadTable(with: .customerIdentity)
            }
            LoadingView.dismiss()
        }
    }
    
    @IBAction func allFilterClick(_ sender: Any) {
        filterType = .All
        reloadTable(with: .all)
    }
    
    @IBAction func attendanceFilterClick(_ sender: Any) {
        filterType = .attendance
        reloadTable(with: showType)
    }
    
    @IBAction func unregisteredFilterClick(_ sender: Any) {
        filterType = .unregistered
        reloadTable(with: showType)
    }
    
    fileprivate func sortChangeUI(index: Int) {
        let listModel : ATLAttendeesModel
        if showType == .ABOIdentity {
            listModel = ABOListModel
        } else {
            listModel = customerListModel
        }
        
        let currentSortIndex = listModel.currentSortIndex
        for i in 0..<sortImageViewArray.count {
            sortImageViewArray[i].isHidden = i != index
        }
        if index != currentSortIndex {
            sortImageViewArray[index].isHidden = true
            listModel.currentSortIndex = index
            sortImageViewArray[index].isHidden = false
        }
        let sortImageView = sortImageViewArray[index]
        sortImageView.image = getImage(with: listModel.sortArrary[index])
    }
    
    fileprivate func getImage(with isDesc: Bool) -> UIImage {
        return (isDesc ? UIImage.init(named: "desc_sort") : UIImage.init(named: "asec_sort"))!
    }
    
    // MARK:UITableViewDataSource
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == ABOListTableView ? aboResultList.count : customerResultList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellID, for: indexPath) as! ATLMemberListTableViewCell
        if tableView == ABOListTableView {
            cell.setData(with: aboResultList[indexPath.row], "ABO")
        } else {
            cell.setData(with: customerResultList[indexPath.row], "CUS")
        }
        return cell
    }
    
    // MARK:UITableViewDelegate
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
}
