//
//  MemberListViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/23.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit
import AudioToolbox

class ATLCheckTicketsViewController: UIViewController {

    @IBOutlet weak var scanView: ATLScanQrCodeView!
    @IBOutlet weak var networkErrorLabel: UILabel!
    @IBOutlet weak var scanResultLabel: UILabel!
    @IBOutlet weak var resultView: UIView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var resultTipsLabel: UILabel!
    @IBOutlet weak var checkNumberLabel: UILabel!
    @IBOutlet weak var resultImageView: UIImageView!
    @IBOutlet weak var left: NSLayoutConstraint!
    @IBOutlet weak var ticketTypeLabel: UILabel!
    @IBOutlet weak var topCons: NSLayoutConstraint!
    @IBOutlet weak var ABOLabel: UILabel!
    @IBOutlet weak var KanjiLabel: UILabel!
    @IBOutlet weak var resultViewHeight: NSLayoutConstraint!
    @IBOutlet weak var kanjiNameTop: NSLayoutConstraint!
    @IBOutlet weak var AboInputLabel: UILabel!
    @IBOutlet weak var aboInputTop: NSLayoutConstraint!
    var task: (()->())?
    var canNetwork = true
    var isAlert = false
    var canScan = true
    
    fileprivate enum DisplayType {
        case waitScan, networkError, scanFailure, scanSuccess
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initScan()
        networkErrorLabel.setText(with: "Network error. Please try again after checking the network")
        displayChange(with: .waitScan, nil, checkNumber: nil, ticketType: nil, ABOID: nil, KanjiName: nil, ABOInput: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        canScan = true
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        canScan = false
        super.viewWillDisappear(animated)
    }
    
    fileprivate func initScan() {
        scanView.startScan {
            [weak self] in
            if self?.canScan ?? false {
                if !(self?.isAlert ?? false) {
                    self?.isAlert = false
                }
                if (SettingManager.getCurrentRegionName() != "India") {
                    if $0.count < 32 || $0.count > 64 || !$0.contains("#") {
                        self?.sacnResultAlert("Ticket not from Booking System，please check")
                        self?.displayChange(with: .waitScan, nil, checkNumber: nil, ticketType: nil, ABOID: nil, KanjiName: nil, ABOInput: nil)
                    }
                } else {
                    if $0.count < 10 || $0.count > 64 {
                        self?.sacnResultAlert("Ticket not from Booking System，please check")
                        self?.displayChange(with: .waitScan, nil, checkNumber: nil, ticketType: nil, ABOID: nil, KanjiName: nil, ABOInput: nil)
                    }
                }
                if self?.canNetwork ?? false {
                    self?.canNetwork = false
                    NetworkManager.checkIn($0, ATLEventDetailModel.currentEventID, {
                        [weak self] in
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
                            [weak self] in
                            if !(self?.isAlert ?? false) {
                                self?.canNetwork = true
                            }
                        }
                        let ticketCode = $0.jsonValue?["ticketCode"] as? String
                        let checkCount = $0.jsonValue?["checkCount"] as? Int ?? 0
                        let ticketType = $0.jsonValue?["ticketTypeName"] as? String
                        let isRepeatScanOpen = SettingManager.isOpenRepeatScan()
                        let aboID = $0.jsonValue?["ada"] as? String
                        let kanjiName = $0.jsonValue?["kanjiName"] as? String
                        let aboInput = $0.jsonValue?["aboInput"] as? String
                        let isABO = ($0.jsonValue?["isAbo"] as? Bool) ?? false
                        
                        if checkCount > 1 && isRepeatScanOpen {
                            self?.sacnResultAlert("Duplicated Scanning")
                        }
                        
                        if $0.isSuccess {
                            self?.displayChange(with: .scanSuccess, ticketCode ?? "", checkNumber: String(checkCount), ticketType: ticketType ?? "", ABOID: isABO ? aboID : nil, KanjiName: kanjiName, ABOInput: aboInput)
                        } else if $0.errorCode == -100 && SettingManager.getCurrentRegionName() != "India" {
                            self?.displayChange(with: .networkError, nil, checkNumber: nil, ticketType: nil, ABOID: nil, KanjiName: nil, ABOInput: nil)
                        } else {
                            self?.displayChange(with: .scanFailure, nil, checkNumber: nil, ticketType: nil, ABOID: nil, KanjiName: nil, ABOInput: nil)
                            self?.sacnResultAlert("Invalid Ticket")
                        }
                    })
                }
            }
        }
    }
    
    
    fileprivate func sacnResultAlert(_ title: String) {
        isAlert = true
        self.canNetwork = false
        let alert = UIAlertController.init(title: nil, message: SettingManager.value(for: title), preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction.init(title: SettingManager.value(for: "confirm"), style: UIAlertAction.Style.default) { [weak self] (action) in
            self?.isAlert = false
            self?.canNetwork = true
        }
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    fileprivate func displayChange(with displayType: DisplayType, _ ticketsNumber: String?, checkNumber: String?, ticketType: String?, ABOID: String?, KanjiName: String?, ABOInput: String?) {
        switch displayType {
        case .waitScan:
            self.wiatDisplay()
        case .networkError:
            self.networkErrorDisplay()
        case .scanFailure:
            self.scanFaildDisplay()
        case .scanSuccess:
            self.scanSuccessDisplay(ticketsNumber: ticketsNumber, checkNumber: checkNumber, ticketType: ticketType, ABOID: ABOID, KanjiName: KanjiName, ABOInput: ABOInput)
        }
        let label = UILabel.init()
        label.text = scanResultLabel.text
        label.sizeToFit()
        left.constant = (screenWidth - 20 - (label.frame.size.width + 42)) / 2.0
    }
    
    fileprivate func wiatDisplay() {
        scanResultLabel.backgroundColor = hexColor(0x929292)
        scanResultLabel.setText(with: "wait scan result")
        scanResultLabel.isHidden = false
        networkErrorLabel.isHidden = true
        resultView.backgroundColor = hexColor(0xF7F7F7)
        resultLabel.isHidden = true
        resultTipsLabel.setText(with: "The inspection result will be shown here")
        resultTipsLabel.textColor = hexColor(0x929292)
        checkNumberLabel.isHidden = true
        resultImageView.image = pngImage(with: "icon_Waiting")
        resultImageView.isHidden = true
        ticketTypeLabel.isHidden = true
        ABOLabel.isHidden = true
        KanjiLabel.isHidden = true
        AboInputLabel.isHidden = true
        resultViewHeight.constant = 110
        topCons.constant = 16
    }
    
    fileprivate func networkErrorDisplay() {
        scanResultLabel.backgroundColor = hexColor(0x929292)
        resultView.backgroundColor = hexColor(0xF7F7F7)
        scanResultLabel.isHidden = true
        networkErrorLabel.isHidden = false
        resultLabel.isHidden = true
        resultTipsLabel.setText(with: "Network Error")
        resultTipsLabel.textColor = hexColor(0x929292)
        resultTipsLabel.isHidden = false
        checkNumberLabel.isHidden = true
        resultImageView.image = pngImage(with: "icon_Waiting")
        resultImageView.isHidden = true
        ticketTypeLabel.isHidden = true
        ABOLabel.isHidden = true
        KanjiLabel.isHidden = true
        AboInputLabel.isHidden = true
        resultViewHeight.constant = 110
        topCons.constant = 16
        playFailSound()
    }
    
    fileprivate func scanFaildDisplay() {
        scanResultLabel.backgroundColor = hexColor(0x002F5F)
        scanResultLabel.setText(with: "scan success")
        scanResultLabel.isHidden = false
        networkErrorLabel.isHidden = true
        resultView.backgroundColor = rgba(r: 245, g: 34, b: 45, a: 0.08)
        resultLabel.setText(with: "Not this activity")
        resultLabel.textColor = hexColor(0xF5222D)
        resultLabel.isHidden = false
        resultTipsLabel.isHidden = true
        topCons.constant = 41;
        checkNumberLabel.isHidden = true
        resultImageView.image = pngImage(with: "icon_failure")
        resultImageView.isHidden = false;
        ticketTypeLabel.isHidden = true
        ABOLabel.isHidden = true
        KanjiLabel.isHidden = true
        AboInputLabel.isHidden = true
        resultViewHeight.constant = 110
        playFailSound()
    }
    
    fileprivate func scanSuccessDisplay(ticketsNumber: String?, checkNumber: String?, ticketType: String?, ABOID: String?, KanjiName: String?, ABOInput: String?) {
        var imageName = ""
        var bgColor = UIColor.white
        var resultColor = UIColor.white
        var resultText = ""
        if let number = Int(checkNumber!) {
            imageName = number > 1 ? "icon_error" : "icon_pass";
            bgColor = number > 1 ? rgba(r: 255, g: 107, b: 20, a: 0.08) : rgba(r: 93, g: 199, b: 50, a: 0.08)
            resultColor = number > 1 ? hexColor(0xFF6B14) : hexColor(0x5DC732)
            resultText = number > 1 ? "ticket again scan" : "through"
        }
        scanResultLabel.backgroundColor = hexColor(0x002F5F)
        scanResultLabel.setText(with: "scan success")
        scanResultLabel.isHidden = false
        networkErrorLabel.isHidden = true
        resultView.backgroundColor = bgColor
        resultLabel.setText(with: resultText)
        resultLabel.textColor = resultColor
        resultLabel.isHidden = false
        resultTipsLabel.setText(with: "ticket code", "{value}：\(ticketsNumber ?? "")")
        resultTipsLabel.textColor = hexColor(0x1A1A1A)
        resultTipsLabel.isHidden = false
        checkNumberLabel.isHidden = false
        checkNumberLabel.setText(with: "check number", "{value}：\(checkNumber ?? "")")
        resultImageView.image = pngImage(with: imageName)
        resultImageView.isHidden = false
        ticketTypeLabel.isHidden = false
        ticketTypeLabel.setText(with: "ticket type", "{value}：\(ticketType ?? "")")
        KanjiLabel.setText(with: "Kanji Name", "{value}：\(KanjiName ?? "")")
        ABOLabel.setText(with: "ABO ID", "{value}：\(ABOID ?? "")")
        AboInputLabel.setText(with: "ABO Input", "{value}：\(ABOInput ?? "")")
        ABOLabel.isHidden = false
        KanjiLabel.isHidden = false
        AboInputLabel.isHidden = false
        topCons.constant = 16
        if let _ = ABOID {
            resultViewHeight.constant = 178
            ABOLabel.isHidden = false
            kanjiNameTop.constant = 0
            aboInputTop.constant = 0
            if (SettingManager.getCurrentRegionName() == "Malaysia" || SettingManager.getCurrentRegionName() == "Singapore" || SettingManager.getCurrentRegionName() == "Brunei") {
                resultViewHeight.constant = 178
                AboInputLabel.isHidden = false
            } else {
                resultViewHeight.constant = 160
                AboInputLabel.isHidden = true
            }
        } else {
            resultViewHeight.constant = 140
            ABOLabel.isHidden = true
            AboInputLabel.isHidden = true
            kanjiNameTop.constant = -16
            aboInputTop.constant = -16
        }
        if Int(checkNumber!) ?? 0 > 1 {
            playRepeatScanSound()
        } else {
            playSuccessSound()
        }
    }
    
    fileprivate func playSuccessSound() {
        playSound(id: 1313)
    }
    
    fileprivate func playFailSound() {
        playSound(id: 1333)
    }
    
    
    fileprivate func playRepeatScanSound() {
        playSound(id: 1022)
    }
    
    func playSound(id: SystemSoundID) {
        MuteDetector.shared.detect { (isMute) in
            if !isMute {
                AudioServicesPlaySystemSound(id)
            } else {
                AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
            }
        }
    }
    
    deinit {
        print("dealloc")
    }
}

