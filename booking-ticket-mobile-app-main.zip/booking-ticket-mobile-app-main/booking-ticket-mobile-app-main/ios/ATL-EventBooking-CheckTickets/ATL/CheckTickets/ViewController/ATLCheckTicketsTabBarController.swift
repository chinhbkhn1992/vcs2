//
//  CheckTicketsViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/23.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

class ATLCheckTicketsTabBarController: UITabBarController, UITabBarControllerDelegate {
    
    var checkTicketsItem: UITabBarItem?
    var memberListItem: UITabBarItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initTabVC()
        configNav()
        initLanguage()
    }
    
    func initTabItem(with title: String, _ normalName: String, _ selectName: String) -> UITabBarItem {
        let item = UITabBarItem.init(title: title, image: pngImage(with: normalName), selectedImage: pngImage(with: selectName))
        return item
    }
    
    func initTabVC() {
        checkTicketsItem = initTabItem(with: "驗票", "scan_tab_normal", "scan_tab_select")
        memberListItem = initTabItem(with: "人員名單", "user_tab_noraml", "user_tab_select")
        
        let checkTicketsVC = ATLCheckTicketsViewController()
        checkTicketsVC.tabBarItem = checkTicketsItem
        let memberListVC = ATLMemberListViewController()
        memberListVC.tabBarItem = memberListItem
        self.viewControllers = [checkTicketsVC, memberListVC]
        self.delegate = self
        
    UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : hexColor(0x929292)], for: UIControl.State.normal)
    UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : hexColor(0x002F5F)], for: UIControl.State.selected)
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        if let _ = viewController as? ATLMemberListViewController {
            self.navigationItem.setText(with: "")
        } else {
            self.navigationItem.setText(with: "scan")
        }
    }
    
    func initLanguage() {
        checkTicketsItem?.setText(with: "check-in")
        memberListItem?.setText(with: "Personnel list")
        self.navigationItem.setText(with: "scan")
    }
}
