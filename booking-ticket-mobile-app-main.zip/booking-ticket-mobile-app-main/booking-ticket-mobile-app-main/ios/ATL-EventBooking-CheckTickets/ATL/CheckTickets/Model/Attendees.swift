//
//  Attendees.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/25.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import HandyJSON

class ATLAttendeesModel: HandyJSON {
    
    
    class ListModel: HandyJSON {
        var ada: String?
        var name: String?
        var phone: String?
        var checkinstatus: Int?
        var checkTime: String?
        var isAbo : Bool = false
        
        required init() {}
        
        func getCheckTime() -> String {
            var formatterStr = ""
            if (SettingManager.getCurrentRegionName() == "India") {
                formatterStr = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            } else {
                formatterStr = "yyyy-MM-dd'T'HH:mm:ss"
            }
            let formatter = DateFormatter()
            formatter.dateFormat = formatterStr
            let date = formatter.date(from: checkTime ?? "")
            
            let second = TimeZone.current.secondsFromGMT()
            
            if var _date = date {
                _date.addTimeInterval(TimeInterval.init(second))
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy/MM/dd HH:mm"
                return formatter.string(from: _date)
            }
            return " "
        }
    }
    
    enum SearchType : String {
        case ABO = "ABO", Customer = "CUS", ALL = "ALL"
    }
    
    // 排序true是desc， false是asc
    var sortArrary = [false, false, false]
    // 排序ada/name/checkTime
    var orderByArrary = ["ada", "name", "checkTime"]
    var currentSortIndex = 0
    var searchStr  = ""
    var currentpage: Int = 1 // 当前页
    var totalPerPage: Int = 15 // 每页笔数
    var totalPages: Int?
    var attendees: [ListModel] = []
    var type: SearchType? = .ABO
    var count: Int {
        return attendees.count
    }
    
    
    subscript(index: Int) -> ATLAttendeesModel.ListModel? {
        if attendees.count > 0 {
            return attendees[index]
        }
        return nil
    }
    
    func clearData() {
        self.currentpage = 1
        attendees.removeAll()
    }
    
    fileprivate func appendData(_ data: [ATLAttendeesModel.ListModel]?) {
        if data != nil {
            attendees += data!
        }
    }
    required init() {}
    required init(type: SearchType) {
        self.type = type
        if self.type == .ABO {
            currentSortIndex = 0
        } else {
            currentSortIndex = 1
        }
    }
}

extension ATLAttendeesModel {
    static func searchAll(searchStr: String, aboListModel: ATLAttendeesModel, customerListModel: ATLAttendeesModel, _ completion: @escaping (_ haveType: SearchType) -> Void) {
        NetworkManager.getAttendeeList(ATLEventDetailModel.currentEventID, "ALL", 1, 15, "ada", false, searchStr) { (response) in
            aboListModel.clearData()
            customerListModel.clearData()
            print(response.jsonValue ?? "getAttendeeList no response")
            let result = ATLAttendeesModel.deserialize(from: response.jsonValue)
            var aboList : [ListModel] = []
            var customerList : [ListModel] = []
            let list = result?.attendees
            if let _list = list {
                for model in _list {
                    if model.isAbo {
                        aboList.append(model)
                    } else {
                        customerList.append(model)
                    }
                }
            }
            aboListModel.attendees = aboList
            customerListModel.attendees = customerList
            var haveType : SearchType = .ABO
            
            if aboList.count > 0 && customerList.count > 0 {
                aboListModel.currentpage += 1
                customerListModel.currentpage += 1
                haveType = .ALL
            } else if (aboList.count > 0) {
                aboListModel.currentpage += 1
                haveType = .ABO
            } else if (customerList.count > 0){
                customerListModel.currentpage += 1
                haveType = .Customer
            }
            completion(haveType)
        }
    }
    
    func load(isAppend: Bool, _ completion: @escaping () -> Void) {
        if isAppend {
            if currentpage <= totalPages ?? 0 {
                self.getData {
                    [weak self] (model, isSuccess) in
                    if isSuccess {
                        self?.totalPages = model?.totalPages
                        self?.appendData(model?.attendees)
                        self?.currentpage += 1
                    }
                    completion()
                }
            } else {
                completion()
            }
        } else {
            self.getData {
                [weak self] (model, isSuccess) in
                if isSuccess {
                    self?.totalPages = model?.totalPages
                    self?.attendees = model?.attendees ?? []
                    self?.currentpage += 1
                }
                completion()
            }
        }
    }
    
    func getData(_ completion: @escaping (ATLAttendeesModel?, Bool) -> Void) {
        NetworkManager.getAttendeeList(ATLEventDetailModel.currentEventID, self.type!.rawValue, self.currentpage, self.totalPerPage, orderByArrary[currentSortIndex], sortArrary[currentSortIndex], searchStr) {
            (response) in
            let result = ATLAttendeesModel.deserialize(from: response.jsonValue)
            print(response.jsonValue ?? "getAttendeeList no response")
            completion(result, response.isSuccess)
        }
    }
}




