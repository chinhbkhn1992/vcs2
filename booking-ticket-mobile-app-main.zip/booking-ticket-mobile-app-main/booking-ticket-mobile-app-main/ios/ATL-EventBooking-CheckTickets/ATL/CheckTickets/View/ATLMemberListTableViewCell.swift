//
//  MemberListTableViewCell.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/24.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

class ATLMemberListTableViewCell: UITableViewCell {

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var ABOLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var ABOLableWidth: NSLayoutConstraint!
    @IBOutlet weak var timeLabelWidth: NSLayoutConstraint!
    @IBOutlet weak var nameLabelWidth: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(with model: ATLAttendeesModel.ListModel, _ type: String) {
        ABOLabel.text = type == "ABO" ? model.ada : self.getName(model.name ?? "")
        NameLabel.text = model.name
        timeLabel.text = model.getCheckTime()
        let contentViewWidth = screenWidth - 20.0 - 20.0
         if type != "ABO" {
               ABOLabel.isHidden = true
               ABOLableWidth.constant = -(contentViewWidth / 3.0)
               let width = contentViewWidth / 2.0
               nameLabelWidth.constant = width
               timeLabelWidth.constant = width
           } else {
               ABOLabel.isHidden = false
               nameLabelWidth.constant = 0
               let width = contentViewWidth / 3.0
               nameLabelWidth.constant = width
               timeLabelWidth.constant = width
               ABOLableWidth.constant = width
       }
    }
    
    func getName(_ name: String) -> String {
        var _name = name
        if name.count > 0 {
            if name.count == 2 {
                _name = String(name[name.startIndex]) + "*"
            } else if name.count == 3 {
                _name = String(name[name.startIndex]) + "*" + String(name[name.index(before: name.endIndex)])
            } else if name.count > 3 {
                _name = String(name[name.startIndex])
                for _ in 1..<name.count - 1 {
                    _name = _name + "*"
                }
                _name = _name + String(name[name.index(before: name.endIndex)])
            }
        }
        return _name
    }
}
