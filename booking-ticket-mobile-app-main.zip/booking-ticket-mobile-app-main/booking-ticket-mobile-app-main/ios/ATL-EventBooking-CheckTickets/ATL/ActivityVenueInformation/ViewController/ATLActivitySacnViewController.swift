//
//  ActivitySacnViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/22.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

class ATLActivitySacnViewController: UIViewController {

    @IBOutlet weak var scanView: ATLScanQrCodeView!
    @IBOutlet weak var resultLabel: UILabel!
    var scanSuccessComple: ((ATLEventDetailModel?, Bool, Bool) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configNav()
        startScan()
        initLanguage()
    }
    
    func startScan() {
        let canScan = scanView.startScan {
            [unowned self] in
            let regionCode = $0.components(separatedBy: "#;").first
            let eventID = $0.components(separatedBy: "#;").last
            self.scanView.stopScan()
            ATLEventDetailModel.loadEventDetail(regionCode ?? "", eventID ?? "", {
                [unowned self] in
                self.resultLabel.isHidden = false
                self.scanSuccessComple?($0, $1, $2)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    [unowned self] in
                    self.back()
                })
            })
        }
        if !canScan {
            print("不能扫描")
        }
    }
    
    override func back() {
        scanView.stopScan()
        self.navigationController?.popViewController(animated: true)
    }
    
    func initLanguage() {
        self.navigationItem.setText(with: "scan")
        resultLabel.setText(with: "Scan is successful, will jump back to the home page")
    }
    
    deinit {
        print("dealloc")
    }
}
