//
//  ActivityVenueInformationViewController.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/19.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit

fileprivate enum DisplayType {
    case defaultType, noQueryType, successType
}

class ATLActivityVenueInformationViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var versionLabel: UILabel!
    @IBOutlet weak var activityVenueTextField: UITextField!
    @IBOutlet weak var checkView: UIView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var contentViewTop: NSLayoutConstraint!
    @IBOutlet weak var contentViewBottom: NSLayoutConstraint!
    @IBOutlet weak var checkTicketButton: UIButton!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var noInfoLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var titleArr = Array<String>()
    var keyArr = Array<String>()
    var detailModel: ATLEventDetailModel?
    var isClear = false
    var isSession = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configTable()
        activityDisplay(with: .defaultType)
        configViewBordColor()
        configLanguage()
        tableView.estimatedRowHeight = 60
        NotificationCenter.default.addObserver(forName: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil, queue: OperationQueue.main) {
            [unowned self] (notification) in
            self.configLanguage()
            self.tableView.reloadData()
        }
        
        NotificationCenter.default.addObserver(forName: SettingManager.REGION_CHANGE_POST_NAME, object: nil, queue: OperationQueue.main) {
            [unowned self] (no) in
            self.configTable()
            self.tableView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if activityVenueTextField.text?.count ?? 0 > 0 {
            getNetworkData()
        }
    }

    // MARK:初始化多语言
    func configLanguage() {
        checkButton.setText(with: "query")
        noInfoLabel.setText(with: "Not query to the active information, please check the event ID")
        checkTicketButton.setText(with: "began to recount")
        activityVenueTextField.setText(with: "input activity ID or click on the scan")
        var appVersion = getCurrentVersion()
        if NetworkManager.isQA {
            appVersion = SettingManager.value(for: "test version") + appVersion
        }
        versionLabel.setText(with: "current version", "{value}：\(appVersion)")
    }
    
    // MARK:初始化Table
    func configTable() {
        //titleArr = eventTitleArr
        //keyArr = eventKeyArr
        
        switch SettingManager.getCurrentRegionName() {
        case "Japan":
            titleArr = ["activity serial number", "activity name", "long name", "date", "timeslot", "site", "address", "admission rate", "participants", "no admission number", "admission number"]
            keyArr = ["eventID", "eventName", "eventLongName", "date", "timeslot", "sessionVenueName", "address", "checkinRate", "ticketsTotal", "uncheckinTotal", "checkinTotal"]
        case "安利（中国）":
            //Sample for Taiwan
            titleArr = ["activity serial number", "activity name", "long name", "date", "timeslot", "site", "address", "admission rate", "participants", "no admission number", "admission number"]
            keyArr = ["eventID", "eventName", "eventLongName", "date", "timeslot", "sessionVenueName", "address", "checkinRate", "ticketsTotal", "uncheckinTotal", "checkinTotal"]
        case "Việt Nam":
            titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "participants", "no admission number", "admission rate"]
            keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "ticketsTotal", "uncheckinTotal", "checkinRate"]
        case "Malaysia":
            titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "language", "participants", "no admission number", "admission rate"]
            keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
        case "Singapore":
            titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "language", "participants", "no admission number", "admission rate"]
            keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
        case "Brunei":
            titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "language", "participants", "no admission number", "admission rate"]
            keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
        case "India":
            titleArr = ["activity serial number", "activity name", "date", "address", "language", "participants", "no admission number", "admission number", "admission rate"]
            keyArr = ["eventID", "eventName", "date", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinTotal", "checkinRate"]
        default:
            //Master
            titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "participants", "no admission number", "admission rate"]
            keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "checkinTotal", "uncheckinTotal", "checkinRate"]
        }
    }
    
    fileprivate func configViewBordColor() {
        checkView.layer.borderColor = hexColor(0xE3E3E3).cgColor
        contentView.layer.borderColor = hexColor(0xE3E3E3).cgColor
    }
    
    fileprivate func getNetworkData() {
        ATLEventDetailModel.loadEventDetail(SettingManager.getCurrentRegionCode(), self.activityVenueTextField.text ?? "") {
            [unowned self] in
            self.checkButton.isUserInteractionEnabled = true
            self.isSession = $2
            if $1 {
                self.setData(with: $0!)
                self.activityDisplay(with: .successType)
            } else {
                self.clearData()
                self.activityDisplay(with: .noQueryType)
            }
        }
    }
    
    // MARK:click点击
    
    @IBAction fileprivate func checkTicketClick(_ sender: UIButton) {
        let checkTicketsVC = ATLCheckTicketsTabBarController()
        navigationController?.pushViewController(checkTicketsVC, animated: true)
    }
    
    @IBAction fileprivate func checkActivityIDClick(_ sender: Any) {
        checkButton.isUserInteractionEnabled = false
        getNetworkData()
    }
    
    @IBAction fileprivate func scanActivityIDClick(_ sender: Any) {
        let activityScanVC = ATLActivitySacnViewController()
        navigationController?.pushViewController(activityScanVC, animated: true)
        activityScanVC.scanSuccessComple = {
            [unowned self] in
            self.isSession = $2
            if $1 {
                self.setData(with: $0!)
                self.activityDisplay(with: .successType)
            } else {
                self.clearData()
                self.activityDisplay(with: .noQueryType)
            }
        }
    }
    
    fileprivate func activityDisplay(with type: DisplayType) {
        switch type {
        case .defaultType:
            contentViewTop.constant = 10.0
            contentViewBottom.constant = 40.0
            checkTicketButton.isUserInteractionEnabled = false
            checkTicketButton.backgroundColor = hexColor(0x929292)
        case .noQueryType:
            contentViewTop.constant = 40.0
            contentViewBottom.constant = 40.0
            checkTicketButton.isUserInteractionEnabled = false
            checkTicketButton.backgroundColor = hexColor(0x929292)
        case .successType:
            contentViewTop.constant = 10.0
            contentViewBottom.constant = 40.0
            checkTicketButton.isUserInteractionEnabled = true
            checkTicketButton.backgroundColor = hexColor(0x002F5F)
        }
    }
    
    func setData(with model: ATLEventDetailModel) {
        activityVenueTextField.text = model.eventID
        detailModel = model
        if model.eventID?.contains("-") ?? false {
            //titleArr = eventTitleArr
            //keyArr = eventKeyArr
            
            switch SettingManager.getCurrentRegionName() {
            case "Japan":
                titleArr = ["activity serial number", "activity name", "long name", "date", "timeslot", "site", "address", "admission rate", "participants", "no admission number", "admission number"]
                keyArr = ["eventID", "eventName", "eventLongName", "date", "timeslot", "sessionVenueName", "address", "checkinRate", "ticketsTotal", "uncheckinTotal", "checkinTotal"]
            case "安利（中国）":
                //Sample for Taiwan
                titleArr = ["activity serial number", "activity name", "long name", "date", "timeslot", "site", "address", "admission rate", "participants", "no admission number", "admission number"]
                keyArr = ["eventID", "eventName", "eventLongName", "date", "timeslot", "sessionVenueName", "address", "checkinRate", "ticketsTotal", "uncheckinTotal", "checkinTotal"]
            case "Việt Nam":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "Malaysia":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "language", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "Singapore":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "language", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "Brunei":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "language", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "India":
                titleArr = ["activity serial number", "activity name", "date", "address", "language", "participants", "no admission number", "admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "date", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinTotal", "checkinRate"]
            default:
                //Master
                titleArr = ["activity serial number", "activity name", "applicant", "date", "timeslot", "site", "address", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "timeslot", "sessionVenueName", "address", "checkinTotal", "uncheckinTotal", "checkinRate"]
            }
        } else {
            //titleArr = sessionTitleArr
            //keyArr = sessionKeyArr
            
            switch SettingManager.getCurrentRegionName() {
            case "Japan":
                titleArr = ["activity serial number", "activity name", "long name", "date", "address", "admission rate", "participants", "no admission number", "admission number"]
                keyArr = ["eventID", "eventName", "eventLongName", "date", "address", "checkinRate", "ticketsTotal", "uncheckinTotal", "checkinTotal"]
            case "安利（中国）":
                //Sample for Taiwan
                titleArr = ["activity serial number", "activity name", "long name", "date", "address", "admission rate", "participants", "no admission number", "admission number"]
                keyArr = ["eventID", "eventName", "eventLongName", "date", "address", "checkinRate", "ticketsTotal", "uncheckinTotal", "checkinTotal"]
            case "Việt Nam":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "address", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "address", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "Malaysia":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "address", "language", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "Singapore":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "address", "language", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "Brunei":
                titleArr = ["activity serial number", "activity name", "applicant", "date", "address", "language", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinRate"]
            case "India":
                titleArr = ["activity serial number", "activity name", "date", "address", "language", "participants", "no admission number", "admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "date", "address", "language", "ticketsTotal", "uncheckinTotal", "checkinTotal", "checkinRate"]
            default:
                //Master
                titleArr = ["activity serial number", "activity name", "applicant", "date", "address", "participants", "no admission number", "admission rate"]
                keyArr = ["eventID", "eventName", "contactInfo", "date", "address", "checkinTotal", "uncheckinTotal", "checkinRate"]
            }
        }
        tableView.reloadData()
        isClear = false
    }
    
    func clearData() {
        activityVenueTextField.text = ""
        detailModel = nil
        isClear = true
        tableView.reloadData()
    }
    
    // MARK:tableView
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keyArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: ATLActivityVenueInformationViewTableViewCell?
        if let _cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ATLActivityVenueInformationViewTableViewCell.self)) as? ATLActivityVenueInformationViewTableViewCell {
            cell = _cell
        } else {
            if SettingManager.getCurrentRegionName() == "Japan"{
                cell = ATLActivityVenueInformationViewTableViewCell.loadFromNib(isAdmissionRate: indexPath.row == titleArr.count - 4)
            } else {
                cell = ATLActivityVenueInformationViewTableViewCell.loadFromNib(isAdmissionRate: indexPath.row == titleArr.count - 1)
            }

        }
        cell?.setTitle(titleArr[indexPath.row])
        if SettingManager.getCurrentRegionName() == "Japan" {
            if indexPath.row == titleArr.count - 4 {
                cell?.setAdmissionRate(total: Int(detailModel?.ticketsTotal ?? "") ?? 0, admission: Int(detailModel?.checkinTotal ?? "") ?? 0, rate: detailModel?.checkinRate ?? "")
            } else {
                let key = keyArr[indexPath.row]
                var content = ""
                if key == "date" {
                    content = detailModel?.getDate(with: isSession) ?? " "
                } else if key == "timeslot" {
                    content = detailModel?.getTimeSlot() ?? " "
                } else if key == "address"{
                    content = detailModel?.getAddress(with: isSession) ?? " "
                } else {
                    content = detailModel?[key] ?? " "
                }
                cell?.setContent(content)
            }
        } else {
            if indexPath.row == titleArr.count - 1 {
                cell?.setAdmissionRate(total: Int(detailModel?.ticketsTotal ?? "") ?? 0, admission: Int(detailModel?.checkinTotal ?? "") ?? 0, rate: detailModel?.checkinRate ?? "")
            } else {
                let key = keyArr[indexPath.row]
                var content = ""
                if key == "date" {
                    content = detailModel?.getDate(with: isSession) ?? " "
                } else if key == "timeslot" {
                    content = detailModel?.getTimeSlot() ?? " "
                } else if key == "address"{
                    content = detailModel?.getAddress(with: isSession) ?? " "
                } else {
                    content = detailModel?[key] ?? " "
                }
                cell?.setContent(content)
            }
        }
        return cell!
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: SettingManager.LANGUAGE_CHANGE_POST_NAME, object: nil)
        NotificationCenter.default.removeObserver(self, name: SettingManager.REGION_CHANGE_POST_NAME, object: nil)
    }
}



