//
//  EventDetailModel.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/8/6.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import HandyJSON

class ATLEventDetailModel: HandyJSON {
    static var currentEventID: String = ""
    static var currentRegionCode: String = ""
    var eventID: String?
    var eventCode: String?
    var eventName: String?
    var eventLongName: String?
    var address: String?
    var ticketsTotal: String?
    var checkinTotal: String?
    var uncheckinTotal: String?
    var checkinRate: String?
    var applicant: String?
    var contactInfo: String?
    var venue: String?
    var eventStartTime: String?
    var eventEndTime: String?
    var sessionDate: String?
    var sessionStartTimeSlot: String?
    var sessionEndTimeSlot: String?
    var eventVenueName: String?
    var eventAddress: String?
    var sessionCityName: String?
    var sessionProvinceName: String?
    var sessionDistrictName: String?
    var sessionVenue: String?
    var sessionVenueName: String?
    var sessionVenueAddr: String?
    var language: String?
    
    required init() {}
    
    func getAddress(with isSession: Bool) -> String {
        if SettingManager.getCurrentRegionName() == "Japan" || SettingManager.getCurrentRegionName() == "Malaysia" || SettingManager.getCurrentRegionName() == "Singapore" || SettingManager.getCurrentRegionName() == "Brunei" || SettingManager.getCurrentRegionName() == "India" {
            return eventAddress ?? " "
        } else {
            func getString(_ str: String?) -> String {
                if str?.count ?? 0 > 0 {
                    return " " + str!
                }
                return ""
            }
            var value = (sessionVenueAddr ?? "")
            value = value + getString(sessionDistrictName)
            value = value + getString(sessionCityName)
            value = value + getString(sessionProvinceName)
            return value
        }
    }
    
    func getDate(with isSession: Bool) -> String {
        if (isSession && SettingManager.getCurrentRegionName() != "India") {
            return changeDateToString(with: changeStringToDate(with: sessionDate ?? ""), formatterString: "yyyy/MM/dd")
        } else {
            let start = changeDateToString(with: changeStringToDate(with: eventStartTime ?? ""), formatterString: "yyyy/MM/dd")
            let end = changeDateToString(with: changeStringToDate(with: eventEndTime ?? ""), formatterString: "yyyy/MM/dd")
            return start + " - " + end
        }
    }
    
    func getTimeSlot() -> String {
        let start = changeDateToString(with: changeStringToDate(with: sessionStartTimeSlot ?? ""), formatterString: "HH:mm")
        let end = changeDateToString(with: changeStringToDate(with: sessionEndTimeSlot ?? ""), formatterString: "HH:mm")
        return start + "-" + end
    }
    
    func changeStringToDate(with dateString: String) -> Date? {
        let formatter = DateFormatter()
        if (SettingManager.getCurrentRegionName() == "India") {
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        }
        else {
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        }
        let date = formatter.date(from: dateString)
        return date
    }
    
    func changeDateToString(with date: Date?, formatterString: String) -> String {
        if var _date = date {
            let second = TimeZone.current.secondsFromGMT()
            
            _date.addTimeInterval(TimeInterval.init(second))
            let formatter = DateFormatter()
            formatter.dateFormat = formatterString
            return formatter.string(from: _date)
        }
        return ""
    }
}

extension ATLEventDetailModel {
    subscript(key: String) -> String? {
        let mirror = Mirror(reflecting: self)
        for (label, value) in mirror.children {
            if label == key {
                return value as? String
            }
        }
        return nil
    }
}

extension ATLEventDetailModel {
    static func loadEventDetail(_ regionCode: String, _ eventID: String, _ completion: @escaping (ATLEventDetailModel?, Bool, Bool) -> Void) {
        NetworkManager.checkinEventDetail(regionCode, eventID) {
            if $0.isSuccess {
                ATLEventDetailModel.currentRegionCode = regionCode
                ATLEventDetailModel.currentEventID = eventID
            }
            let eventModel = ATLEventDetailModel.deserialize(from: $0.jsonValue)
            print($0.jsonValue ?? "checkinEventDetail no response")
            completion(eventModel, $0.isSuccess, eventID.contains("-"))
        }
    }
}
