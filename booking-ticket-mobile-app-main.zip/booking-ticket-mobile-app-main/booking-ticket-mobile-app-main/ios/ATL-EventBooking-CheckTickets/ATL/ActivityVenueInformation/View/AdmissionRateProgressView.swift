//
//  AdmissionRateProgressView.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/22.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import UIKit
import SnapKit

class AdmissionRateProgressView: UIView {
    
    let admissionLayer = CAShapeLayer.init()
    let numberLabel = UILabel.init()
    var progressBlock: ((Int, Int, String?)->())?
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.initialize()
    }
    
    fileprivate func initialize() {
        self.backgroundColor = hexColor(0xF7F7F7)
        configSubView()
    }
    
    fileprivate func configSubView() {
        self.addSubview(numberLabel)
        numberLabel.font = UIFont.systemFont(ofSize: 15)
        numberLabel.textColor = hexColor(0x929292)
        numberLabel.snp.makeConstraints {
            $0.center.equalToSuperview()
            $0.height.equalTo(21)
        }
    }
    
    func progress(with admission: Int, total: Int, rate: String?) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.01) {
            [weak self] in
            if (total > 0) {
                if let weakSelf = self {
                    let progress = Float(admission) / Float(total)
                    let path = UIBezierPath.init(rect: CGRect(x: 0, y: 0, width: CGFloat(progress) * weakSelf.bounds.size.width, height: weakSelf.bounds.size.height))
                    weakSelf.admissionLayer.fillColor = hexColor(0xE8941A).cgColor
                    weakSelf.admissionLayer.path = path.cgPath
                    weakSelf.layer.insertSublayer(weakSelf.admissionLayer, below: weakSelf.numberLabel.layer)
                    weakSelf.numberLabel.isHidden = false
                    weakSelf.numberLabel.isHidden = total == 0
                    weakSelf.numberLabel.text = "\(rate ?? "")%[\(admission)/\(total)]"
                }
                
            }
        }
    }
    
    func clear() {
        numberLabel.isHidden = true
        admissionLayer.removeFromSuperlayer()
    }
}
