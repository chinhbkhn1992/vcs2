//
//  ATLActivityVenueInformationViewTableViewCell.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2020/6/16.
//  Copyright © 2020 莫至钊. All rights reserved.
//

import UIKit

class ATLActivityVenueInformationViewTableViewCell: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setTitle(_ title: String) {
        let titleLabel = self.viewWithTag(1) as! UILabel
        titleLabel.setText(with: title, "{value}：")
    }
    
    func setContent(_ content: String) {
        let contentLabel = self.viewWithTag(2) as? UILabel
        contentLabel?.text = content
    }
    
    func setAdmissionRate(total: Int, admission: Int, rate: String) {
        let admissionRateView = self.viewWithTag(2) as? AdmissionRateProgressView
        admissionRateView?.progress(with: admission, total: total, rate: rate)
    }
    
    static func loadFromNib(isAdmissionRate : Bool) -> ATLActivityVenueInformationViewTableViewCell {
        let cells = Bundle.main.loadNibNamed(String(describing: ATLActivityVenueInformationViewTableViewCell.self), owner: nil, options: nil) as! [ATLActivityVenueInformationViewTableViewCell]
        return isAdmissionRate ? cells.last! : cells.first!
    }
}
