//
//  Constant.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/19.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import UIKit

var screenWidth = UIScreen.main.bounds.size.width
var screenHeight = UIScreen.main.bounds.size.height


func hexColor(_ hexValue: Int) -> UIColor {
    let r = Float(((hexValue & 0xFF0000) >> 16)) / 255.0
    let g = Float((hexValue & 0xFF00) >> 8) / 255.0
    let b = Float((hexValue & 0xFF)) / 255.0
    return UIColor.init(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
}

func pngImage(with imageName: String) -> UIImage? {
    let image = UIImage(named: imageName)
    return image
}

func rgba(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat) -> UIColor {
    return UIColor.init(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: a)
}

func getWindow() -> UIWindow {
    return UIApplication.shared.delegate!.window!!
}

func getCurrentVersion() -> String {
    let infoDictionary = Bundle.main.infoDictionary!
    let majorVersion = infoDictionary["CFBundleShortVersionString"]//主程序版本号
    let appVersion = majorVersion as! String
    return appVersion
}

func getSystemVersion() -> String {
    return UIDevice.current.systemVersion
}

func getCurrentModel() -> String {
    return UIDevice.current.model
}

func stringToDate(with dateString: String, format: String) -> Date? {
    let dateFormat = DateFormatter()
    dateFormat.dateFormat = format
    return dateFormat.date(from: dateString)
}

func dateToString(with date: Date, format: String) -> String? {
    let dateFormat = DateFormatter()
    dateFormat.dateFormat = format
    return dateFormat.string(from: date)
}



