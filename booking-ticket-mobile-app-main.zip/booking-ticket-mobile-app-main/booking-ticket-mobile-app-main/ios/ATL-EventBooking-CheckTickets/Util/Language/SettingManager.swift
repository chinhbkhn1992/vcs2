//
//  LanguageManager.swift
//  多语言
//
//  Created by 莫至钊 on 2019/7/26.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation

let CurrentRegionNameKey = "CurrentRegionKey"
let CurrentLanguageNameKey = "CurrentLanguageKey"
let LocalLanguageKey = "LocalLanguageKey"
let LocalRegionCodeKey = "LocalRegionCodeKey"
let CurrentRepeatScanKey = "CurrentRepeatScanKey"
let CurrentFirstTimeFlag = "CurrentFirstTimeFlag"

/*******************************************/
let TWRegionName = "Japan"
let ChinaRegionName = "安利（中国）"
let VietnameRegionName = "Việt Nam"
let MalaysiaRegionName = "Malaysia"
let SingaporeRegionName = "Singapore"
let BruneiRegionName = "Brunei"
let MARegionName = "Amway"
let IndiaRegionName = "India"

/*******************************************/
let TWRegionCode = "ATL"
let ChinaRegionCode = "ACCL"

/*******************************************/
let TWLanguageName = "繁體中文"
let ChinaLanguageName = "简体中文"
let EnglishLanguageName = "English"
let JapanLanguageName = "日本語"
let VietnameseLanguageName = "Tiếng Việt"
let IndiaLanguageName = "हिन्दी"

/*******************************************/
let TWLanguageFileName = "zh-Hant"
let ChiaLanguageFileName = "zh-Hans"
let EnglishLanguageFileName = "en"
let JapnanLanguageFileName = "ja"
let VietnameseLanguageFileName = "vi"
let IndiaLanguageFileName = "ta"

/*******************************************/
let RepeatScanName = "Y"


class SettingManager {
    
    static var bundle: Bundle?
    static let LANGUAGE_CHANGE_POST_NAME: NSNotification.Name = NSNotification.Name(rawValue: "LANGUAGE_CHANGE_POST_NAME")
    static let REGION_CHANGE_POST_NAME: NSNotification.Name = NSNotification.Name("REGION_CHANGE_POST_NAME")
    
    static func regionAndLanguage() {
        
        let def = UserDefaults.standard
        let vietnam = def.stringArray(forKey: "vietnamKey") ?? [String]()
        let japan = def.stringArray(forKey: "japanKey") ?? [String]()
        let brunei = def.stringArray(forKey: "bruneiKey") ?? [String]()
        let singapore = def.stringArray(forKey: "singaporeKey") ?? [String]()
        let malaysia = def.stringArray(forKey: "malaysiaKey") ?? [String]()
        let india = def.stringArray(forKey: "indiaKey") ?? [String]()
        let others = def.stringArray(forKey: "othersKey") ?? [String]()
        let vietnamDefaultCode = def.array(forKey: "vietnamDefaultCodeKey") as? [Int] ?? [Int]()
        let japanDefaultCode = def.array(forKey: "japanDefaultCodeKey") as? [Int] ?? [Int]()
        let bruneiDefaultCode = def.array(forKey: "bruneiDefaultCodeKey") as? [Int] ?? [Int]()
        let singaporeDefaultCode = def.array(forKey: "singaporeDefaultCodeKey") as? [Int] ?? [Int]()
        let malaysiaDefaultCode = def.array(forKey: "malaysiaDefaultCodeKey") as? [Int] ?? [Int]()
        let indiaDefaultCode = def.array(forKey: "indiaDefaultCodeKey") as? [Int] ?? [Int]()
        let othersDefaultCode = def.array(forKey: "othersDefaultCodeKey") as? [Int] ?? [Int]()
        let region = def.stringArray(forKey: "regionKey") ?? [String]()
        let regionName = def.stringArray(forKey: "regionNameKey") ?? [String]()
        let applicationInfoRegion = def.stringArray(forKey: "applicationInfoRegionKey") ?? [String]()
        
        def.set(vietnam, forKey: "vietnamKey")
        def.set(japan, forKey: "japanKey")
        def.set(brunei, forKey: "bruneiKey")
        def.set(singapore, forKey: "singaporeKey")
        def.set(malaysia, forKey: "malaysiaKey")
        def.set(india, forKey: "indiaKey")
        def.set(others, forKey: "othersKey")
        def.set(vietnamDefaultCode, forKey: "vietnamDefaultCodeKey")
        def.set(japanDefaultCode, forKey: "japanDefaultCodeKey")
        def.set(bruneiDefaultCode, forKey: "bruneiDefaultCodeKey")
        def.set(singaporeDefaultCode, forKey: "singaporeDefaultCodeKey")
        def.set(malaysiaDefaultCode, forKey: "malaysiaDefaultCodeKey")
        def.set(indiaDefaultCode, forKey: "indiaDefaultCodeKey")
        def.set(othersDefaultCode, forKey: "othersDefaultCodeKey")
        def.set(region, forKey: "regionKey")
        def.set(regionName, forKey: "regionNameKey")
        def.set(applicationInfoRegion, forKey: "applicationInfoRegionKey")
        def.synchronize()
        
        //let getRegionLanguageSuccessComple: ((RegionLanguageModel?, Bool) -> Void)?
        RegionLanguageModel.getData({
            _,_ in
            //getRegionLanguageSuccessComple?($0, $1)
        })
        
        RegionNameModel.getData({
            _,_ in
            
        })
        
        let langStr = Locale.current.languageCode
        print("Device language: " + (langStr ?? ""))
        let regStr = Locale.current.regionCode
        print("Device region: " + (regStr ?? ""))
        
        let localRegionCodeKey : String
        let currentRegionName : String
        let localLanguage : String
        let currentLanguageName : String
        switch regStr {
        case "JP":
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? TWRegionCode
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? TWRegionName
            localLanguage = def.string(forKey: LocalLanguageKey) ?? JapnanLanguageFileName
            currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? JapanLanguageName
        case "VN":
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? TWRegionCode
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? VietnameRegionName
            switch langStr {
            case "en":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            case "vi":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? VietnameseLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? VietnameseLanguageName
            default:
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            }
        case "BN":
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? ""
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? BruneiRegionName
            switch langStr {
            case "en":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            case "zh":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? ChiaLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? ChinaLanguageName
            default:
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            }
        case "MY":
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? ""
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? MalaysiaRegionName
            switch langStr {
            case "en":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            case "zh":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? ChiaLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? ChinaLanguageName
            default:
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            }
        case "SG":
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? ""
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? SingaporeRegionName
            switch langStr {
            case "en":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            case "zh":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? ChiaLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? ChinaLanguageName
            default:
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            }
        case "IN":
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? ""
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? IndiaRegionName
            switch langStr {
            case "en":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            case "ta":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? IndiaLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? IndiaLanguageName
            default:
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            }
        default:
            switch langStr {
            case "en":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            case "zh":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? ChiaLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? ChinaLanguageName
            case "ja":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? JapnanLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? JapanLanguageName
            case "vi":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? VietnameseLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? VietnameseLanguageName
            case "ta":
                localLanguage = def.string(forKey: LocalLanguageKey) ?? IndiaLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? IndiaLanguageName
            default:
                localLanguage = def.string(forKey: LocalLanguageKey) ?? EnglishLanguageFileName
                currentLanguageName = def.string(forKey: CurrentLanguageNameKey) ?? EnglishLanguageName
            }
            localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? ""
            currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? ""

            //let localRegionCodeKey = def.string(forKey: LocalRegionCodeKey) ?? ""
            //let currentRegionName = def.string(forKey: CurrentRegionNameKey) ?? ""
        }
        
        let repeatScanName = def.string(forKey: CurrentRepeatScanKey) ?? RepeatScanName
        let firstTimeFlag = def.string(forKey: CurrentFirstTimeFlag) ?? ""
        
        def.set(localLanguage, forKey: LocalLanguageKey)
        def.set(localRegionCodeKey, forKey: LocalRegionCodeKey)
        def.set(currentLanguageName, forKey: CurrentLanguageNameKey)
        def.set(currentRegionName, forKey: CurrentRegionNameKey)
        def.set(repeatScanName, forKey: CurrentRepeatScanKey)
        def.set(firstTimeFlag, forKey: CurrentFirstTimeFlag)
        def.synchronize()
        let path = Bundle.main.path(forResource: localLanguage, ofType: "lproj")
        bundle = Bundle.init(path: path!)
    }
    
}

extension SettingManager {
    
    enum Language: String {
        case TWLanguage = "繁體中文", ChinaLanguage = "简体中文", EnglishLanguage = "English", JapanLanguage = "日本語", VietnameLanguage = "Tiếng Việt", IndiaLanguage = "தமிழ்"
        func getLanguageFileName() -> String {
            switch self.rawValue {
            case TWLanguageName:
                return TWLanguageFileName
            case ChinaLanguageName:
                return ChiaLanguageFileName
            case EnglishLanguageName:
                return EnglishLanguageFileName
            case JapanLanguageName:
                return JapnanLanguageFileName
            case VietnameseLanguageName:
                return VietnameseLanguageFileName
            case IndiaLanguageName:
                return IndiaLanguageFileName
            default:
                return ""
            }
        }
    }
    
    static func value(for key: String) -> String {
        return NSLocalizedString(key, tableName: "Language", bundle: SettingManager.bundle!, comment: "")
    }
    
    static func setLanguage(with language: Language) {
        let def = UserDefaults.standard
        let currentLanguage = def.value(forKey: LocalLanguageKey) as? String
        let newLanguage = language.getLanguageFileName()
        guard newLanguage != currentLanguage, currentLanguage != nil else {
            return
        }
        let path = Bundle.main.path(forResource: newLanguage, ofType: "lproj")
        assert(path != nil, "this language is nil")
        bundle = Bundle.init(path: path!)
        def.set(newLanguage, forKey: LocalLanguageKey)
        def.set(language.rawValue, forKey: CurrentLanguageNameKey)
        def.synchronize()
        NotificationCenter.default.post(name: LANGUAGE_CHANGE_POST_NAME, object: nil)
    }
    
    static func getCurrentLanguageName() -> String {
        return UserDefaults.standard.value(forKey: CurrentLanguageNameKey) as! String
    }
}

extension SettingManager {
    
    enum Region: String {
        case TW = "Japan", China = "安利（中国）", Vietname = "Việt Nam", Malaysia = "Malaysia", Singapore = "Singapore", Brunei = "Brunei", MA = "Amway", India = "India"
        func getRegionCode() -> String {
            switch self.rawValue {
            case TWRegionName:
                return TWRegionCode
            case ChinaRegionName:
                return ChinaRegionCode
            case MARegionName:
                return TWRegionCode
            default:
                return ""
            }
        }
    }
    
    static func setRegion(with region: Region) {
        let regionCode = region.getRegionCode()
        UserDefaults.standard.set(region.rawValue, forKey: CurrentRegionNameKey)
        UserDefaults.standard.set(regionCode, forKey: LocalRegionCodeKey)
        NotificationCenter.default.post(name: REGION_CHANGE_POST_NAME, object: nil)
    }
    
    static func getCurrentRegionCode() -> String {
        return UserDefaults.standard.value(forKey: LocalRegionCodeKey) as! String
    }
    
    static func getCurrentRegionName() -> String {
        return UserDefaults.standard.value(forKey: CurrentRegionNameKey) as! String
    }
}

extension SettingManager {
    enum RepeatScan: String {
        case open = "Y", close = "N"
    }
    
    static func getCurrentRepeatScanName() -> String {
        return SettingManager.value(for: UserDefaults.standard.string(forKey: CurrentRepeatScanKey)!)
    }
    
    static func setRepeatScan(with repeatScan: RepeatScan) {
        UserDefaults.standard.set(repeatScan.rawValue, forKey: CurrentRepeatScanKey)
    }
    
    static func isOpenRepeatScan() -> Bool {
        if let isOpen =  UserDefaults.standard.string(forKey: CurrentRepeatScanKey) {
            return isOpen != "Y"
        }
        return false
    }
}
