//
//  ConfigLanguage.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/7/29.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import UIKit

var rawValueKey = "rawValue"

protocol LanguageProtocol {
    var rawValue: String { get }
    // 使用{value}代表转换后语言的位置
    /* 例子：
     假如value是“大白”
     "我是一个{value}。。哈哈"
     结果是： "我是一个大白。。哈哈"
    */
    func setText(with rawValue: String, _ formatString: String)
}

fileprivate func getResult(with formatString: String, _ rawValue: String) -> String {
    let sepArr = formatString.components(separatedBy: "{value}")
    guard sepArr.count > 1 else {
        return SettingManager.value(for: rawValue)
    }
    let result = sepArr.joined(separator: SettingManager.value(for: rawValue))
    return result
}

extension UILabel: LanguageProtocol {
    var rawValue: String {
        return objc_getAssociatedObject(self, &rawValueKey) as! String
    }
    func setText(with rawValue: String, _ formatString: String = "") {
        objc_setAssociatedObject(self, &rawValueKey, rawValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        self.text = getResult(with: formatString, rawValue)
    }
}

extension UIButton: LanguageProtocol {
    var rawValue: String {
        return objc_getAssociatedObject(self, &rawValueKey) as! String
    }
    func setText(with rawValue: String, _ formatString: String="") {
        objc_setAssociatedObject(self, &rawValueKey, rawValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        self.setTitle(getResult(with: formatString, rawValue), for: UIControl.State.normal)
    }
}

extension UINavigationItem {
    var rawValue: String {
        return objc_getAssociatedObject(self, &rawValueKey) as! String
    }
    func setText(with rawValue: String, _ formatString: String="") {
        objc_setAssociatedObject(self, &rawValueKey, rawValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        self.title = getResult(with: formatString, rawValue)
    }
}

extension UITabBarItem {
    var rawValue: String {
        return objc_getAssociatedObject(self, &rawValueKey) as! String
    }
    func setText(with rawValue: String, _ formatString: String="") {
        objc_setAssociatedObject(self, &rawValueKey, rawValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        self.title = getResult(with: formatString, rawValue)
    }
}

extension UITextField {
    var rawValue: String {
        return objc_getAssociatedObject(self, &rawValueKey) as! String
    }
    func setText(with rawValue: String, _ formatString: String="") {
        objc_setAssociatedObject(self, &rawValueKey, rawValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        self.placeholder = getResult(with: formatString, rawValue)
    }
}




