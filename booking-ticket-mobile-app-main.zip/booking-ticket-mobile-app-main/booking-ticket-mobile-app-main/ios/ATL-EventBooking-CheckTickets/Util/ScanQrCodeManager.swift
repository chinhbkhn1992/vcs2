//
//  ScanQrCodeManager.swift
//  ATL-EventBooking-CheckTickets
//
//  Created by 莫至钊 on 2019/9/9.
//  Copyright © 2019 莫至钊. All rights reserved.
//

import Foundation
import AVFoundation

typealias ScanResultBlock = (String) -> Void

class ScanQrCodeManager: NSObject, AVCaptureMetadataOutputObjectsDelegate, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    //会话
    var session: AVCaptureSession?
    var videoOutput: AVCaptureVideoDataOutput?
    var scanResultBlock: ScanResultBlock?
    
    
    init?(scanResult: ScanResultBlock?) {
        super.init()
        if !self.initAV() {
           return nil
        }
        scanResultBlock = scanResult
    }
    
    // MARK:AV相关
    fileprivate func initAV() -> Bool {
        // 获取当前设备
        guard let device = AVCaptureDevice.default(for: AVMediaType.video) else { return false }
        
        // 创建输入流
        guard let deviceInput = try? AVCaptureDeviceInput.init(device: device) else {
            return false
        }
        // 创建输出流
        let metadataOutput = AVCaptureMetadataOutput.init()
        
        // 设置输出流回调
        metadataOutput.setMetadataObjectsDelegate(self as AVCaptureMetadataOutputObjectsDelegate, queue: DispatchQueue.main)
        
        // 创建会话
        session = AVCaptureSession.init()
        
        // 设置会话采集率
        session?.sessionPreset = AVCaptureSession.Preset.hd1920x1080
        
        // 判断当前会话是否可以添加输出流
        guard let _ = session?.canAddOutput(metadataOutput) else {
            return false
        }
        // 将输出流添加到会话中
        session?.addOutput(metadataOutput)
        
        // 创建摄像数据输出流并将其添加到会话对象上
        videoOutput = AVCaptureVideoDataOutput.init()
        videoOutput?.setSampleBufferDelegate(self as AVCaptureVideoDataOutputSampleBufferDelegate, queue: DispatchQueue.main)
        
        // 将图像输出流添加到会话中
        session?.addOutput(videoOutput!)
        
        // 判断当前会话是否可以添加输入流
        guard let _ = session?.canAddInput(deviceInput) else {
            return false
        }
        
        // 将输入流添加到会话中
        session?.addInput(deviceInput)
        
        //设置数据输出类型(如下设置为条形码和二维码兼容)，需要将数据输出添加到会话后，才能指定元数据类型，否则会报错
        metadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr, AVMetadataObject.ObjectType.ean13, AVMetadataObject.ObjectType.ean8, AVMetadataObject.ObjectType.code128]
        return true
    }
    
    func getVideoLayer() -> AVCaptureVideoPreviewLayer? {
        
        // 实例化预览对象, 用于显示会话对象
        let videoLayer = AVCaptureVideoPreviewLayer.init(session: session!)
        // 设置填充边界
        videoLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        return videoLayer
    }
    
    func startScan() {
        session?.startRunning()
    }
    
    func stopScan() {
        session?.stopRunning()
    }
    
    // 获取到二维码数据回调
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if metadataObjects.count > 0 {
            if let obj = metadataObjects[0] as? AVMetadataMachineReadableCodeObject {
                if let result = obj.stringValue {
                    scanResultBlock?(result)
                }
            }
        }
    }
}
